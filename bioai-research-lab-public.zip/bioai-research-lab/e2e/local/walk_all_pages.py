"""Browser checks against a running local-mode site (python3 run_local.py).

    python3 e2e/local/walk_all_pages.py [BASE_URL]

Requires Python Playwright with Chromium. Fails on any console error, page error or HTTP error.
"""
import os, sys, tempfile
import re, time
from playwright.sync_api import sync_playwright
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765"
OUT = tempfile.mkdtemp(prefix="bioai-shots-")
problems = []
def watch(page, label):
    page.on("console", lambda m: problems.append(f"[{label}] console.{m.type}: {m.text}") if m.type in ("error", "warning") else None)
    page.on("pageerror", lambda e: problems.append(f"[{label}] PAGE ERROR: {e}"))
    page.on("response", lambda r: problems.append(f"[{label}] HTTP {r.status} {r.request.method} {r.url}") if r.status >= 400 else None)

try:
  with sync_playwright() as p:
      b = p.chromium.launch()
      page = b.new_page(viewport={"width": 1366, "height": 900}); watch(page, "desktop")
      page.goto(BASE + "/"); page.wait_for_load_state("networkidle"); page.screenshot(path=os.path.join(OUT, "01_landing.png"), full_page=True)
      page.get_by_role("button", name="Explore the live demo").click()
      page.wait_for_url("**/dashboard"); page.wait_for_timeout(1500); page.screenshot(path=os.path.join(OUT, "02_dashboard.png"), full_page=True)
      page.get_by_role("link", name="Projects", exact=True).click(); page.wait_for_timeout(800); page.screenshot(path=os.path.join(OUT, "03_projects.png"), full_page=True)
      page.get_by_text("DEMO: BioAI workflow on synthetic data").click(); page.wait_for_timeout(1200)
      for i, tab in enumerate(["Overview", "Datasets", "Experiments", "New experiment", "Members", "Tasks & comments", "Audit history"]):
          page.get_by_role("tab", name=tab).click(); page.wait_for_timeout(700)
          page.screenshot(path=os.path.join(OUT, f"04_ws_{i}_{re.sub('[^a-z]','',tab.lower())}.png"), full_page=True)
      page.get_by_role("tab", name="Datasets").click(); page.wait_for_timeout(500)
      page.get_by_role("button", name="Preview v1").first.click(); page.wait_for_timeout(800)
      page.screenshot(path=os.path.join(OUT, "05_preview.png"), full_page=True)
      for exp in ["DEMO omics", "DEMO HRV"]:
          page.get_by_role("tab", name="Experiments").click(); page.wait_for_timeout(500)
          page.get_by_role("link", name=re.compile(exp)).click(); page.wait_for_timeout(1500)
          tabs = page.get_by_role("tab").all_inner_texts()
          for i, tab in enumerate(tabs):
              page.get_by_role("tab", name=tab, exact=True).click(); page.wait_for_timeout(900)
              if tab == "Report":
                  page.get_by_role("button", name="View").click(); page.wait_for_timeout(1500)
              if tab == "Copilot":
                  page.get_by_role("button", name="Ask").click(); page.wait_for_timeout(1500)
              page.screenshot(path=os.path.join(OUT, f"06_{exp.split()[1].lower()}_{i:02d}_{re.sub('[^a-z]','',tab.lower())}.png"), full_page=True)
          page.get_by_role("link", name="← Project").click(); page.wait_for_timeout(800)
      for name in ["Teams", "Settings", "Dashboard"]:
          page.get_by_role("link", name=name, exact=True).click(); page.wait_for_timeout(800)
          page.screenshot(path=os.path.join(OUT, f"07_{name.lower()}.png"), full_page=True)
      m = b.new_page(viewport={"width": 390, "height": 844}); watch(m, "mobile")
      m.goto(BASE + "/"); m.wait_for_load_state("networkidle"); m.screenshot(path=os.path.join(OUT, "08_mobile_landing.png"), full_page=True)
      m.get_by_role("button", name="Explore the live demo").click(); m.wait_for_url("**/dashboard"); m.wait_for_timeout(1200)
      m.screenshot(path=os.path.join(OUT, "09_mobile_dashboard.png"), full_page=True)
      b.close()
finally:
    print("\n".join(problems) if problems else f"NO console errors, page errors or failed requests (screenshots: {OUT})")
    sys.exit(1 if problems else 0)
