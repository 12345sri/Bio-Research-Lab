"""Browser checks against a running local-mode site (python3 run_local.py).

    python3 e2e/local/researcher_journey.py [BASE_URL]

Requires Python Playwright with Chromium. Fails on any console error, page error or HTTP error.
"""
import os, sys, tempfile
import time, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "backend"))
import io
from app.science.demo_data import biosignal_demo
FIXTURE = os.path.join(tempfile.mkdtemp(), "rr_fixture.csv")
_b = io.StringIO(); biosignal_demo(6).to_csv(_b, index=False); open(FIXTURE, "w").write(_b.getvalue())
from playwright.sync_api import sync_playwright
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8765"; PW = "Research-Lab-2026"; problems = []
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1280, "height": 900}, accept_downloads=True)
    pg.on("console", lambda m: problems.append(f"console.{m.type}: {m.text}") if m.type in ("error", "warning") else None)
    pg.on("pageerror", lambda e: problems.append(f"PAGE ERROR: {e}"))
    pg.on("response", lambda r: problems.append(f"HTTP {r.status} {r.url}") if r.status >= 400 else None)
    email = f"journey-{int(time.time())}@example.org"
    pg.goto(BASE + "/register")
    pg.get_by_label("Name (shown to collaborators)").fill("Journey Researcher")
    pg.get_by_label("Email").fill(email); pg.get_by_label("Password").fill(PW)
    pg.get_by_role("button", name="Create account").click()
    pg.get_by_role("link", name="verify my email").click()
    pg.get_by_text("Your email is verified").wait_for(); print("1 registered + verified")
    pg.goto(BASE + "/login"); pg.get_by_label("Email").fill(email); pg.get_by_label("Password").fill(PW)
    pg.get_by_role("button", name="Sign in", exact=True).click()
    pg.get_by_text("Welcome, Journey Researcher").wait_for(); print("2 signed in, dashboard shown")
    pg.goto(BASE + "/projects"); pg.get_by_role("button", name="New project").click()
    pg.get_by_label("Project name").fill(f"Journey HRV study {int(time.time())}")
    pg.get_by_label("Research question").fill("Does HRV differ between normal and exam days (demonstration data)?")
    pg.get_by_role("button", name="Create project").click()
    pg.get_by_role("tab", name="Datasets").wait_for(); print("3 project created")
    pg.get_by_role("tab", name="Datasets").click()
    pg.get_by_label("Name", exact=True).fill("RR intervals")
    pg.locator('input[name="file"]').first.set_input_files(FIXTURE)
    pg.get_by_role("button", name="Upload", exact=True).click()
    pg.get_by_text("rr_fixture.csv").first.wait_for(); print("4 dataset uploaded and validated")
    pg.get_by_role("tab", name="New experiment").click()
    pg.get_by_label("Experiment name").fill("Journey HRV comparison")
    pg.get_by_label(re.compile("RR interval dataset")).select_option(index=1)
    pg.get_by_role("button", name="Create and run").click()
    pg.get_by_text("SUCCEEDED").wait_for(timeout=180000); print("5 analysis ran on the background worker")
    pg.get_by_role("tab", name="Statistics").click(); pg.get_by_text(re.compile("rmssd_ms")).first.wait_for()
    pg.get_by_role("tab", name="Sessions & QC").click(); pg.get_by_text(re.compile(r"^P-")).first.wait_for()
    assert pg.get_by_text(re.compile("student_")).count() == 0; print("6 results shown; participants pseudonymised")
    pg.get_by_role("tab", name="Report").click()
    with pg.expect_download() as d: pg.get_by_role("button", name="PDF").click()
    assert open(d.value.path(), "rb").read(4) == b"%PDF"; print("7 PDF report downloaded")
    pg.get_by_role("tab", name="Copilot").click(); pg.get_by_role("button", name="Ask").click()
    pg.get_by_text("Evidence the copilot may use").wait_for(); print("8 copilot evidence shown")
    pg.get_by_role("tab", name="Reproducibility").click()
    pg.get_by_text(re.compile("config_hash")).first.wait_for()
    pg.get_by_text(re.compile("random_seed")).first.wait_for(); print("9 reproducibility record shown (seed, config hash, versions)")
    pg.get_by_role("button", name="Clone for re-run").click()
    pg.get_by_text(re.compile(r"\(re-run\)")).first.wait_for(); print("10 experiment cloned for exact re-run")
    b.close()
print("\n".join(problems) if problems else "JOURNEY: NO console errors, page errors or failed requests")
sys.exit(1 if problems else 0)
