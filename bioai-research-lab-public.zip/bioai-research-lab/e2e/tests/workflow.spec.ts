import { expect, test } from "@playwright/test";
import * as fs from "fs";
import * as path from "path";

// Runs against the real application started with docker compose (frontend + API + worker + DB + storage).
const API = process.env.API_URL || "http://localhost:8000/api/v1";
const PW = "Research-Lab-2026";
const fixtures = path.join(__dirname, "..", "fixtures");

test("register, verify, create project, upload, run on the worker, view results, download report", async ({ page }) => {
  const email = `e2e-${Date.now()}@example.org`;

  await page.goto("/register");
  await page.getByLabel("Name (shown to collaborators)").fill("E2E Researcher");
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(PW);
  await page.getByRole("button", { name: "Create account" }).click();
  await page.getByRole("link", { name: "verify my email" }).click();
  await expect(page.getByText("Your email is verified")).toBeVisible();

  await page.goto("/login");
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(PW);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page.getByText("Welcome, E2E Researcher")).toBeVisible();

  await page.goto("/projects");
  await page.getByRole("button", { name: "New project" }).click();
  await page.getByLabel("Project name").fill(`E2E HRV ${Date.now()}`);
  await page.getByLabel("Research question").fill("Does HRV differ between normal and exam days (demonstration data)?");
  await page.getByRole("button", { name: "Create project" }).click();
  await expect(page.getByRole("tab", { name: "Datasets" })).toBeVisible();

  await page.getByRole("tab", { name: "Datasets" }).click();
  await page.getByLabel("Name", { exact: true }).fill("Demo RR intervals");
  await page.locator('input[name="file"]').first().setInputFiles(path.join(fixtures, "demo_rr.csv"));
  await page.getByRole("button", { name: "Upload", exact: true }).click();
  await expect(page.getByText("demo_rr.csv")).toBeVisible();

  await page.getByRole("tab", { name: "New experiment" }).click();
  await page.getByLabel("Experiment name").fill("E2E HRV comparison");
  await page.getByLabel(/RR interval dataset/).selectOption({ index: 1 });
  await page.getByRole("button", { name: "Create and run" }).click();

  // The background worker processes it; the page polls until done.
  await expect(page.getByText("SUCCEEDED")).toBeVisible({ timeout: 5 * 60 * 1000 });
  await expect(page.getByText("DEMONSTRATION DATA").first()).toBeVisible().catch(() => {});
  await page.getByRole("tab", { name: "Statistics" }).click();
  await expect(page.getByText(/rmssd_ms/).first()).toBeVisible();
  await page.getByRole("tab", { name: "Sessions & QC" }).click();
  await expect(page.getByText(/^P-/).first()).toBeVisible();          // pseudonymised codes only
  await expect(page.getByText(/student_/)).toHaveCount(0);            // raw identifiers never shown

  await page.getByRole("tab", { name: "Report" }).click();
  const [dl] = await Promise.all([page.waitForEvent("download"), page.getByRole("button", { name: "PDF" }).click()]);
  const file = await dl.path();
  expect(fs.readFileSync(file!).subarray(0, 4).toString()).toBe("%PDF");
});

test("demo project: omics results with ML, explanations, network, pathways and external validation", async ({ page, request }) => {
  const email = process.env.DEMO_USER_EMAIL!, password = process.env.DEMO_USER_PASSWORD!;
  test.skip(!email, "DEMO_USER_EMAIL not set");
  await page.goto("/login");
  await page.getByLabel("Email").fill(email);
  await page.getByLabel("Password").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
  await page.goto("/projects");
  await page.getByText("DEMO: BioAI workflow on synthetic data").click();
  await page.getByRole("tab", { name: "Experiments" }).click();
  await page.getByRole("link", { name: /DEMO omics/ }).click();
  await expect(page.getByText("SUCCEEDED")).toBeVisible();
  await expect(page.getByText("DEMONSTRATION DATA: synthetic values")).toBeVisible();
  for (const tab of ["Machine learning", "Explainability", "Network", "Pathways", "Validation"]) {
    await page.getByRole("tab", { name: tab }).click();
    await expect(page.locator("table").first()).toBeVisible();
  }
  await page.getByRole("tab", { name: "Validation" }).click();
  await expect(page.getByText("EXTERNAL_VALIDATION")).toBeVisible();
  await page.getByRole("tab", { name: "Explainability" }).click();
  await expect(page.getByText(/SHAP/).first()).toBeVisible();
  await page.getByRole("tab", { name: "Copilot" }).click();
  await page.getByRole("button", { name: "Ask" }).click();
  await expect(page.getByText("Evidence the copilot may use")).toBeVisible();
});
