import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./tests",
  timeout: 10 * 60 * 1000,
  expect: { timeout: 30_000 },
  reporter: [["list"], ["html", { outputFolder: "report", open: "never" }]],
  use: { baseURL: process.env.APP_URL || "http://localhost:3000", trace: "retain-on-failure", acceptDownloads: true },
});
