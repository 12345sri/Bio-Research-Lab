"""Celery tasks."""
import uuid

from app.db.session import session_factory
from app.services.experiments import execute
from app.workers.celery_app import celery_app


@celery_app.task(name="experiments.run")
def run_experiment(experiment_id: str) -> str:
    db = session_factory()()
    try:
        execute(db, uuid.UUID(experiment_id))
    finally:
        db.close()
    return experiment_id


def dispatch(experiment_id: uuid.UUID, inline: bool) -> str | None:
    """Queue the experiment; RUN_TASKS_INLINE=true runs it in-process (tests only)."""
    if inline:
        run_experiment(str(experiment_id))
        return None
    return run_experiment.delay(str(experiment_id)).id
