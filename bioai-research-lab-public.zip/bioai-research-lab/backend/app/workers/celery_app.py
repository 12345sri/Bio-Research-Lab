"""Background worker. Heavy analyses run here, never inside a web request."""
import os

from celery import Celery

celery_app = Celery("bioai", broker=os.environ.get("REDIS_URL", "redis://redis:6379/0"),
                    backend=os.environ.get("REDIS_URL", "redis://redis:6379/0"), include=["app.workers.tasks"])
celery_app.conf.update(task_track_started=True, task_acks_late=True, worker_prefetch_multiplier=1,
                       task_time_limit=60 * 60, task_soft_time_limit=55 * 60)
