"""Import every model so Base.metadata is complete for Alembic and tests."""
from app.models.audit import AuditLog
from app.models.biosignal import BiosignalSession, HrvResult
from app.models.data import Dataset, DatasetVersion
from app.models.experiment import (Experiment, ExperimentResult, Feature, Model, ModelRun, Report, StatisticsResult,
                                   ValidationRun)
from app.models.omics import GeneNetwork, GeneResult, OmicsDataset, Pathway
from app.models.org import Organization, Role, Team, TeamMember, User, UserToken
from app.models.project import Comment, Consent, Project, ProjectMember, Task
from app.models.publication import Publication

REQUIRED_TABLES = frozenset({
    "users", "organizations", "roles", "projects", "project_members", "datasets", "dataset_versions",
    "experiments", "experiment_results", "models", "model_runs", "features", "statistics_results",
    "biosignal_sessions", "hrv_results", "omics_datasets", "gene_results", "gene_networks", "pathways",
    "validation_runs", "reports", "publications", "teams", "tasks", "comments", "audit_logs", "consents",
})
SUPPORTING_TABLES = frozenset({"team_members", "user_tokens"})

__all__ = [
    "AuditLog", "BiosignalSession", "HrvResult", "Dataset", "DatasetVersion", "Experiment", "ExperimentResult",
    "Feature", "Model", "ModelRun", "Report", "StatisticsResult", "ValidationRun", "GeneNetwork", "GeneResult",
    "OmicsDataset", "Pathway", "Organization", "Role", "Team", "TeamMember", "User", "Comment", "Consent",
    "Project", "ProjectMember", "Task", "Publication", "UserToken", "REQUIRED_TABLES", "SUPPORTING_TABLES",
]
