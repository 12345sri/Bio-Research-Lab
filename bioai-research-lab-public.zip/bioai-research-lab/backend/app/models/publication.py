"""Publications. Status is explicit; an unpublished paper can never display as published."""
import uuid

from sqlalchemy import CheckConstraint, ForeignKey, Index, Integer, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, Timestamps, UUIDPk
from app.models.enums import PublicationStatus, pg_enum


class Publication(UUIDPk, Timestamps, Base):
    __tablename__ = "publications"
    organization_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    project_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="SET NULL"))
    dataset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("datasets.id", ondelete="SET NULL"))
    title: Mapped[str] = mapped_column(Text, nullable=False)
    authors: Mapped[list] = mapped_column(JSONB, default=list, server_default="[]", nullable=False)
    journal: Mapped[str | None] = mapped_column(String(300))
    doi: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[PublicationStatus] = mapped_column(pg_enum(PublicationStatus, "publication_status"), nullable=False)
    year: Mapped[int | None] = mapped_column(Integer)
    abstract: Mapped[str | None] = mapped_column(Text)
    code_repository_url: Mapped[str | None] = mapped_column(String(500))
    created_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    __table_args__ = (
        Index("uq_publications_doi", "doi", unique=True, postgresql_where=text("doi IS NOT NULL")),
        CheckConstraint("year IS NULL OR (year >= 1900 AND year <= 2200)", name="year_range"),
        CheckConstraint("status <> 'PUBLISHED' OR (year IS NOT NULL AND journal IS NOT NULL)", name="published_has_venue"),
        CheckConstraint("doi IS NULL OR doi ~ '^10\\.[0-9]{4,9}/\\S+$'", name="doi_format"),
        CheckConstraint("jsonb_typeof(authors) = 'array'", name="authors_is_list"),
    )
