"""Projects, membership, consent, tasks and comments."""
import uuid
from datetime import date, datetime

from sqlalchemy import (Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, String, Text,
                        UniqueConstraint)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, CreatedAt, Timestamps, UUIDPk
from app.models.enums import (CommentTarget, ConsentStatus, Contribution, Platform, Privacy, ProjectRole,
                              ProjectStatus, TaskStatus, pg_enum, values)


class Project(UUIDPk, Timestamps, Base):
    __tablename__ = "projects"
    organization_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    research_question: Mapped[str] = mapped_column(Text, nullable=False)
    hypothesis: Mapped[str | None] = mapped_column(Text)
    research_area: Mapped[str | None] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text)
    platform: Mapped[Platform] = mapped_column(pg_enum(Platform, "platform"), nullable=False)
    principal_researcher_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    team_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("teams.id", ondelete="SET NULL"))
    privacy: Mapped[Privacy] = mapped_column(pg_enum(Privacy, "privacy"), nullable=False, server_default=Privacy.INTERNAL.value)
    status: Mapped[ProjectStatus] = mapped_column(
        pg_enum(ProjectStatus, "project_status"), nullable=False, server_default=ProjectStatus.IDEA.value, index=True
    )
    start_date: Mapped[date | None] = mapped_column(Date)
    target_completion_date: Mapped[date | None] = mapped_column(Date)
    created_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    members: Mapped[list["ProjectMember"]] = relationship(back_populates="project", cascade="all, delete-orphan", passive_deletes=True)

    __table_args__ = (
        UniqueConstraint("organization_id", "name"),
        CheckConstraint("target_completion_date IS NULL OR start_date IS NULL OR target_completion_date >= start_date",
                        name="dates_ordered"),
    )


class ProjectMember(CreatedAt, Base):
    __tablename__ = "project_members"
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True, index=True
    )
    project_role: Mapped[ProjectRole] = mapped_column(pg_enum(ProjectRole, "project_role"), nullable=False)
    # Contributions are recorded, never converted into authorship automatically.
    contributions: Mapped[list[str]] = mapped_column(
        ARRAY(String(40)), default=list, server_default="{}", nullable=False
    )
    added_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    project: Mapped[Project] = relationship(back_populates="members")
    __table_args__ = (
        CheckConstraint(
            "contributions <@ ARRAY[" + ", ".join(f"'{v}'" for v in values(Contribution)) + "]::varchar[]",
            name="contributions_valid",
        ),
    )


class Consent(UUIDPk, Timestamps, Base):
    """Consent metadata keyed by a pseudonymous participant code. No names or contact details."""
    __tablename__ = "consents"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    participant_code: Mapped[str] = mapped_column(String(64), nullable=False)
    consent_version: Mapped[str] = mapped_column(String(40), nullable=False)
    status: Mapped[ConsentStatus] = mapped_column(pg_enum(ConsentStatus, "consent_status"), nullable=False)
    scope: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    ethics_reference: Mapped[str | None] = mapped_column(String(200))
    granted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    withdrawn_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    recorded_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    __table_args__ = (
        UniqueConstraint("project_id", "participant_code", "consent_version"),
        CheckConstraint("status <> 'WITHDRAWN' OR withdrawn_at IS NOT NULL", name="withdrawn_has_date"),
        CheckConstraint("status <> 'GRANTED' OR granted_at IS NOT NULL", name="granted_has_date"),
    )


class Task(UUIDPk, Timestamps, Base):
    __tablename__ = "tasks"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    status: Mapped[TaskStatus] = mapped_column(pg_enum(TaskStatus, "task_status"), nullable=False, server_default=TaskStatus.TODO.value)
    contribution_category: Mapped[Contribution | None] = mapped_column(pg_enum(Contribution, "contribution"))
    assignee_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), index=True)
    created_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    due_date: Mapped[date | None] = mapped_column(Date)


class Comment(UUIDPk, Timestamps, Base):
    __tablename__ = "comments"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    author_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    target_type: Mapped[CommentTarget] = mapped_column(pg_enum(CommentTarget, "comment_target"), nullable=False)
    target_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    parent_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("comments.id", ondelete="CASCADE"))
    body: Mapped[str] = mapped_column(Text, nullable=False)
    resolved: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    __table_args__ = (
        Index("ix_comments_target", "target_type", "target_id"),
        CheckConstraint("length(trim(body)) > 0", name="body_not_blank"),
    )
