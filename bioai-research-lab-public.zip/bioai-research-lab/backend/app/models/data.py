"""Datasets and immutable dataset versions. Files live in object storage, not PostgreSQL."""
import uuid
from datetime import datetime

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, CreatedAt, Timestamps, UUIDPk
from app.models.enums import FileType, Platform, Privacy, RecordStatus, ValidationStatus, pg_enum


class Dataset(UUIDPk, Timestamps, Base):
    __tablename__ = "datasets"
    # RESTRICT: a project holding data cannot be hard-deleted; archive it instead.
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    domain: Mapped[Platform] = mapped_column(pg_enum(Platform, "dataset_domain"), nullable=False)
    privacy: Mapped[Privacy] = mapped_column(pg_enum(Privacy, "privacy"), nullable=False)
    status: Mapped[RecordStatus] = mapped_column(
        pg_enum(RecordStatus, "record_status"), nullable=False, server_default=RecordStatus.ACTIVE.value
    )
    is_synthetic: Mapped[bool] = mapped_column(default=False, server_default="false", nullable=False)
    created_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    versions: Mapped[list["DatasetVersion"]] = relationship(
        back_populates="dataset", cascade="all, delete-orphan", passive_deletes=True, order_by="DatasetVersion.version"
    )
    __table_args__ = (
        UniqueConstraint("project_id", "name"),
        CheckConstraint("status <> 'DELETED' OR deleted_at IS NOT NULL", name="deleted_has_date"),
        CheckConstraint("status <> 'ARCHIVED' OR archived_at IS NOT NULL", name="archived_has_date"),
    )


class DatasetVersion(UUIDPk, CreatedAt, Base):
    __tablename__ = "dataset_versions"
    dataset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    storage_key: Mapped[str] = mapped_column(String(512), unique=True, nullable=False)
    original_filename: Mapped[str | None] = mapped_column(String(255))
    file_type: Mapped[FileType] = mapped_column(pg_enum(FileType, "file_type"), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    n_rows: Mapped[int | None] = mapped_column(Integer)
    n_columns: Mapped[int | None] = mapped_column(Integer)
    column_schema: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    validation_status: Mapped[ValidationStatus] = mapped_column(
        pg_enum(ValidationStatus, "validation_status"), nullable=False, server_default=ValidationStatus.PENDING.value
    )
    validation_report: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    change_note: Mapped[str | None] = mapped_column(Text)
    uploaded_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))

    dataset: Mapped[Dataset] = relationship(back_populates="versions")
    __table_args__ = (
        UniqueConstraint("dataset_id", "version"),
        CheckConstraint("version >= 1", name="version_positive"),
        CheckConstraint("size_bytes >= 0", name="size_nonnegative"),
        CheckConstraint("n_rows IS NULL OR n_rows >= 0", name="rows_nonnegative"),
        CheckConstraint("n_columns IS NULL OR n_columns >= 0", name="columns_nonnegative"),
        CheckConstraint("sha256 ~ '^[0-9a-f]{64}$'", name="sha256_hex"),
    )
