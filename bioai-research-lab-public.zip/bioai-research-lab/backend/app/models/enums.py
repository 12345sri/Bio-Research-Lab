"""Controlled vocabularies.

Stored as VARCHAR with a named CHECK constraint (native_enum=False). This avoids shared
PostgreSQL ENUM types, which break Alembic when one type is used by several tables and
are hard to extend. The database still rejects any value outside the vocabulary.
"""
import enum

from sqlalchemy import Enum as SAEnum


def pg_enum(py_enum: type[enum.Enum], name: str) -> SAEnum:
    return SAEnum(
        py_enum,
        name=name,
        native_enum=False,
        create_constraint=True,
        length=40,
        values_callable=lambda e: [m.value for m in e],
        validate_strings=True,
    )


def values(py_enum: type[enum.Enum]) -> list[str]:
    return [m.value for m in py_enum]


class RoleName(str, enum.Enum):
    ADMIN = "ADMIN"; FOUNDER = "FOUNDER"; CO_FOUNDER = "CO_FOUNDER"; RESEARCH_LEAD = "RESEARCH_LEAD"
    RESEARCHER = "RESEARCHER"; BIOINFORMATICIAN = "BIOINFORMATICIAN"; DATA_SCIENTIST = "DATA_SCIENTIST"
    BIOMEDICAL_RESEARCHER = "BIOMEDICAL_RESEARCHER"; DEVELOPER = "DEVELOPER"; VIEWER = "VIEWER"


class ProjectStatus(str, enum.Enum):
    IDEA = "IDEA"; PLANNING = "PLANNING"; DATA_COLLECTION = "DATA_COLLECTION"; ANALYSIS = "ANALYSIS"
    VALIDATION = "VALIDATION"; MANUSCRIPT = "MANUSCRIPT"; SUBMITTED = "SUBMITTED"; PUBLISHED = "PUBLISHED"
    ARCHIVED = "ARCHIVED"


class ProjectRole(str, enum.Enum):
    OWNER = "OWNER"; LEAD = "LEAD"; CONTRIBUTOR = "CONTRIBUTOR"; REVIEWER = "REVIEWER"; VIEWER = "VIEWER"


class Platform(str, enum.Enum):
    BIOSIGNAL = "BIOSIGNAL"; BIOOMICS = "BIOOMICS"; GENERAL = "GENERAL"


class Privacy(str, enum.Enum):
    PUBLIC = "PUBLIC"; INTERNAL = "INTERNAL"; CONFIDENTIAL = "CONFIDENTIAL"; RESTRICTED_HUMAN_DATA = "RESTRICTED_HUMAN_DATA"


class RecordStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"; ARCHIVED = "ARCHIVED"; DELETED = "DELETED"


class FileType(str, enum.Enum):
    CSV = "CSV"; TSV = "TSV"; TXT = "TXT"


class ValidationStatus(str, enum.Enum):
    PENDING = "PENDING"; PASSED = "PASSED"; PASSED_WITH_WARNINGS = "PASSED_WITH_WARNINGS"; FAILED = "FAILED"


class ExperimentStatus(str, enum.Enum):
    DRAFT = "DRAFT"; QUEUED = "QUEUED"; RUNNING = "RUNNING"; SUCCEEDED = "SUCCEEDED"; FAILED = "FAILED"; CANCELLED = "CANCELLED"


class EvidenceLabel(str, enum.Enum):
    DATA = "DATA"; STATISTICS = "STATISTICS"; MODEL = "MODEL"; EXPLANATION = "EXPLANATION"
    LITERATURE = "LITERATURE"; INTERPRETATION = "INTERPRETATION"; HYPOTHESIS = "HYPOTHESIS"


class Algorithm(str, enum.Enum):
    LOGISTIC_REGRESSION = "LOGISTIC_REGRESSION"; SVM = "SVM"; RANDOM_FOREST = "RANDOM_FOREST"; XGBOOST = "XGBOOST"; OTHER = "OTHER"


class SplitStrategy(str, enum.Enum):
    ROW = "ROW"; STRATIFIED_ROW = "STRATIFIED_ROW"; PARTICIPANT = "PARTICIPANT"; TIME = "TIME"


class Resampling(str, enum.Enum):
    NONE = "NONE"; CLASS_WEIGHT = "CLASS_WEIGHT"; SMOTE = "SMOTE"


class ResamplingScope(str, enum.Enum):
    NOT_APPLICABLE = "NOT_APPLICABLE"; TRAINING_FOLDS_ONLY = "TRAINING_FOLDS_ONLY"


class FeatureType(str, enum.Enum):
    HRV_METRIC = "HRV_METRIC"; GENE = "GENE"; CLINICAL = "CLINICAL"; QUESTIONNAIRE = "QUESTIONNAIRE"; OTHER = "OTHER"


class ImportanceMethod(str, enum.Enum):
    SHAP = "SHAP"; PERMUTATION = "PERMUTATION"; COEFFICIENT = "COEFFICIENT"; IMPURITY = "IMPURITY"


class SignalType(str, enum.Enum):
    ECG = "ECG"; RR_INTERVAL = "RR_INTERVAL"; PPG = "PPG"; HEART_RATE = "HEART_RATE"


class QualityScore(str, enum.Enum):
    GOOD = "GOOD"; MODERATE = "MODERATE"; POOR = "POOR"


class OmicsLayer(str, enum.Enum):
    RNA_EXPRESSION = "RNA_EXPRESSION"; MUTATION = "MUTATION"; METHYLATION = "METHYLATION"
    PROTEOMICS = "PROTEOMICS"; CLINICAL = "CLINICAL"


class Orientation(str, enum.Enum):
    GENES_AS_ROWS = "GENES_AS_ROWS"; SAMPLES_AS_ROWS = "SAMPLES_AS_ROWS"


class SelectionStage(str, enum.Enum):
    ORIGINAL = "ORIGINAL"; FILTERED = "FILTERED"; FINAL = "FINAL"


class EdgeType(str, enum.Enum):
    CORRELATION = "CORRELATION"; KNOWN_INTERACTION = "KNOWN_INTERACTION"
    PREDICTED_INTERACTION = "PREDICTED_INTERACTION"; REGULATORY = "REGULATORY"


class PathwayDatabase(str, enum.Enum):
    GO = "GO"; KEGG = "KEGG"; REACTOME = "REACTOME"


class ValidationType(str, enum.Enum):
    INTERNAL_CV = "INTERNAL_CV"; INTERNAL_HOLDOUT = "INTERNAL_HOLDOUT"; EXTERNAL = "EXTERNAL"


class ReportStatus(str, enum.Enum):
    DRAFT = "DRAFT"; IN_REVIEW = "IN_REVIEW"; APPROVED = "APPROVED"


class PublicationStatus(str, enum.Enum):
    IDEA = "IDEA"; IN_PREPARATION = "IN_PREPARATION"; PREPRINT = "PREPRINT"; SUBMITTED = "SUBMITTED"
    UNDER_REVIEW = "UNDER_REVIEW"; ACCEPTED = "ACCEPTED"; PUBLISHED = "PUBLISHED"


class TaskStatus(str, enum.Enum):
    TODO = "TODO"; IN_PROGRESS = "IN_PROGRESS"; IN_REVIEW = "IN_REVIEW"; DONE = "DONE"


class Contribution(str, enum.Enum):
    CONCEPTUALIZATION = "CONCEPTUALIZATION"; DATA_COLLECTION = "DATA_COLLECTION"; DATA_CURATION = "DATA_CURATION"
    SOFTWARE = "SOFTWARE"; METHODOLOGY = "METHODOLOGY"; ANALYSIS = "ANALYSIS"; VISUALIZATION = "VISUALIZATION"
    SUPERVISION = "SUPERVISION"; WRITING = "WRITING"


class Discipline(str, enum.Enum):
    BIOMEDICAL_SCIENCE = "BIOMEDICAL_SCIENCE"; BIOINFORMATICS = "BIOINFORMATICS"; AI_ML = "AI_ML"
    STATISTICS = "STATISTICS"; SOFTWARE_ENGINEERING = "SOFTWARE_ENGINEERING"


class CommentTarget(str, enum.Enum):
    PROJECT = "PROJECT"; DATASET = "DATASET"; EXPERIMENT = "EXPERIMENT"; REPORT = "REPORT"; TASK = "TASK"; PUBLICATION = "PUBLICATION"


class ConsentStatus(str, enum.Enum):
    GRANTED = "GRANTED"; WITHDRAWN = "WITHDRAWN"; EXPIRED = "EXPIRED"
