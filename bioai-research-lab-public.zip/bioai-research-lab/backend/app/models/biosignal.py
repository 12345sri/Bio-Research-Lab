"""BioSignal AI: recording sessions and HRV results."""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, CreatedAt, Timestamps, UUIDPk
from app.models.enums import QualityScore, SignalType, pg_enum


class BiosignalSession(UUIDPk, Timestamps, Base):
    """One participant recording. Participant identified only by a pseudonymous code."""
    __tablename__ = "biosignal_sessions"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    dataset_version_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dataset_versions.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    consent_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("consents.id", ondelete="RESTRICT"))
    participant_code: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    session_code: Mapped[str] = mapped_column(String(64), nullable=False)
    signal_type: Mapped[SignalType] = mapped_column(pg_enum(SignalType, "signal_type"), nullable=False)
    signal_type_validated: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    sampling_rate_hz: Mapped[float | None] = mapped_column(Float)
    unit: Mapped[str | None] = mapped_column(String(20))
    condition: Mapped[str | None] = mapped_column(String(80), index=True)
    time_point: Mapped[str | None] = mapped_column(String(80))
    recorded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    quality_score: Mapped[QualityScore | None] = mapped_column(pg_enum(QualityScore, "quality_score"))
    n_total: Mapped[int | None] = mapped_column(Integer)
    n_valid: Mapped[int | None] = mapped_column(Integer)
    n_excluded: Mapped[int | None] = mapped_column(Integer)
    exclusion_reasons: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    __table_args__ = (
        UniqueConstraint("dataset_version_id", "participant_code", "session_code"),
        CheckConstraint("sampling_rate_hz IS NULL OR sampling_rate_hz > 0", name="sampling_rate_positive"),
        CheckConstraint("signal_type NOT IN ('ECG', 'PPG') OR sampling_rate_hz IS NOT NULL", name="waveform_has_rate"),
        # Nothing is silently removed: every observation is either valid or excluded with a reason.
        CheckConstraint(
            "n_total IS NULL OR (n_valid IS NOT NULL AND n_excluded IS NOT NULL AND n_valid + n_excluded = n_total "
            "AND n_valid >= 0 AND n_excluded >= 0)",
            name="observations_accounted",
        ),
    )


class HrvResult(UUIDPk, CreatedAt, Base):
    __tablename__ = "hrv_results"
    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("biosignal_sessions.id", ondelete="CASCADE"), nullable=False, index=True
    )
    experiment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    window_start_s: Mapped[float] = mapped_column(Float, nullable=False, server_default="0")
    window_length_s: Mapped[float] = mapped_column(Float, nullable=False)
    n_beats: Mapped[int] = mapped_column(Integer, nullable=False)
    mean_rr_ms: Mapped[float | None] = mapped_column(Float)
    mean_hr_bpm: Mapped[float | None] = mapped_column(Float)
    sdnn_ms: Mapped[float | None] = mapped_column(Float)
    rmssd_ms: Mapped[float | None] = mapped_column(Float)
    frequency_domain_valid: Mapped[bool] = mapped_column(Boolean, nullable=False)
    frequency_domain_note: Mapped[str | None] = mapped_column(Text)
    lf_power_ms2: Mapped[float | None] = mapped_column(Float)
    hf_power_ms2: Mapped[float | None] = mapped_column(Float)
    lf_hf_ratio: Mapped[float | None] = mapped_column(Float)
    baseline_deviation: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    __table_args__ = (
        UniqueConstraint("session_id", "experiment_id", "window_start_s"),
        CheckConstraint("window_length_s > 0", name="window_positive"),
        CheckConstraint("n_beats >= 0", name="beats_nonnegative"),
        # Frequency-domain values may only be stored when the recording supports them.
        CheckConstraint(
            "frequency_domain_valid OR (lf_power_ms2 IS NULL AND hf_power_ms2 IS NULL AND lf_hf_ratio IS NULL)",
            name="freq_domain_only_when_valid",
        ),
        CheckConstraint("frequency_domain_valid OR frequency_domain_note IS NOT NULL", name="freq_invalid_explained"),
        CheckConstraint("sdnn_ms IS NULL OR sdnn_ms >= 0", name="sdnn_nonnegative"),
        CheckConstraint("rmssd_ms IS NULL OR rmssd_ms >= 0", name="rmssd_nonnegative"),
    )
