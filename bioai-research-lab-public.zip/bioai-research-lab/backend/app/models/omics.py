"""BioOmics AI: omics datasets, gene-level results, gene networks and pathway enrichment."""
import uuid

from sqlalchemy import Boolean, CheckConstraint, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, CreatedAt, Timestamps, UUIDPk
from app.models.enums import EdgeType, EvidenceLabel, OmicsLayer, Orientation, PathwayDatabase, SelectionStage, pg_enum


class OmicsDataset(UUIDPk, Timestamps, Base):
    __tablename__ = "omics_datasets"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    dataset_version_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dataset_versions.id", ondelete="RESTRICT"), nullable=False, unique=True
    )
    metadata_dataset_version_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dataset_versions.id", ondelete="RESTRICT")
    )
    omics_layer: Mapped[OmicsLayer] = mapped_column(pg_enum(OmicsLayer, "omics_layer"), nullable=False)
    orientation: Mapped[Orientation | None] = mapped_column(pg_enum(Orientation, "orientation"))
    orientation_confirmed: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    n_features: Mapped[int | None] = mapped_column(Integer)
    n_samples: Mapped[int | None] = mapped_column(Integer)
    normalization: Mapped[str | None] = mapped_column(String(80))
    qc_report: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    __table_args__ = (
        CheckConstraint("NOT orientation_confirmed OR orientation IS NOT NULL", name="confirmed_has_orientation"),
        CheckConstraint("metadata_dataset_version_id IS NULL OR metadata_dataset_version_id <> dataset_version_id",
                        name="metadata_is_separate"),
    )


class GeneResult(UUIDPk, CreatedAt, Base):
    __tablename__ = "gene_results"
    experiment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    omics_dataset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("omics_datasets.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    gene_symbol: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    gene_id: Mapped[str | None] = mapped_column(String(64))
    selection_stage: Mapped[SelectionStage] = mapped_column(pg_enum(SelectionStage, "selection_stage"), nullable=False)
    excluded_reason: Mapped[str | None] = mapped_column(Text)
    log2_fold_change: Mapped[float | None] = mapped_column(Float)
    p_value: Mapped[float | None] = mapped_column(Float)
    p_adjusted: Mapped[float | None] = mapped_column(Float)
    evidence_label: Mapped[EvidenceLabel] = mapped_column(pg_enum(EvidenceLabel, "evidence_label"), nullable=False)
    __table_args__ = (
        UniqueConstraint("experiment_id", "gene_symbol", "selection_stage"),
        CheckConstraint("p_value IS NULL OR (p_value >= 0 AND p_value <= 1)", name="p_range"),
        CheckConstraint("p_adjusted IS NULL OR (p_adjusted >= 0 AND p_adjusted <= 1)", name="padj_range"),
    )


class GeneNetwork(UUIDPk, CreatedAt, Base):
    __tablename__ = "gene_networks"
    experiment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    # Every network declares what its edges mean. Correlation is never called regulation.
    edge_type: Mapped[EdgeType] = mapped_column(pg_enum(EdgeType, "edge_type"), nullable=False)
    method: Mapped[str] = mapped_column(String(60), nullable=False)
    threshold: Mapped[float | None] = mapped_column(Float)
    edge_source: Mapped[str | None] = mapped_column(String(200))
    n_nodes: Mapped[int] = mapped_column(Integer, nullable=False)
    n_edges: Mapped[int] = mapped_column(Integer, nullable=False)
    centrality: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    hub_genes: Mapped[list[str]] = mapped_column(ARRAY(String(64)), default=list, server_default="{}", nullable=False)
    graph_artifact_key: Mapped[str | None] = mapped_column(String(512))
    __table_args__ = (
        CheckConstraint("n_nodes >= 0 AND n_edges >= 0", name="counts_nonnegative"),
        CheckConstraint("edge_type <> 'CORRELATION' OR threshold IS NOT NULL", name="correlation_has_threshold"),
        CheckConstraint("edge_type IN ('CORRELATION') OR edge_source IS NOT NULL", name="curated_edges_cite_source"),
    )


class Pathway(UUIDPk, CreatedAt, Base):
    __tablename__ = "pathways"
    experiment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    database: Mapped[PathwayDatabase] = mapped_column(pg_enum(PathwayDatabase, "pathway_database"), nullable=False)
    database_release: Mapped[str | None] = mapped_column(String(60))
    pathway_id: Mapped[str] = mapped_column(String(80), nullable=False)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    genes: Mapped[list[str]] = mapped_column(ARRAY(String(64)), default=list, server_default="{}", nullable=False)
    gene_count: Mapped[int] = mapped_column(Integer, nullable=False)
    background_size: Mapped[int] = mapped_column(Integer, nullable=False)
    statistic: Mapped[float | None] = mapped_column(Float)
    p_value: Mapped[float] = mapped_column(Float, nullable=False)
    p_adjusted: Mapped[float] = mapped_column(Float, nullable=False)
    correction_method: Mapped[str] = mapped_column(String(60), nullable=False)
    __table_args__ = (
        UniqueConstraint("experiment_id", "database", "pathway_id"),
        CheckConstraint("p_value >= 0 AND p_value <= 1", name="p_range"),
        CheckConstraint("p_adjusted >= 0 AND p_adjusted <= 1", name="padj_range"),
        CheckConstraint("gene_count = cardinality(genes)", name="gene_count_matches"),
        CheckConstraint("background_size >= gene_count", name="background_covers_genes"),
    )
