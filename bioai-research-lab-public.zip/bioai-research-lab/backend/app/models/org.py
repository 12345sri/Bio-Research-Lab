"""Organizations, roles, users and teams."""
import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Index, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, CreatedAt, Timestamps, UUIDPk
from app.models.enums import Discipline, RoleName, pg_enum


class Organization(UUIDPk, Timestamps, Base):
    __tablename__ = "organizations"
    name: Mapped[str] = mapped_column(String(200), unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    mission: Mapped[str | None] = mapped_column(Text)


class Role(UUIDPk, CreatedAt, Base):
    __tablename__ = "roles"
    name: Mapped[RoleName] = mapped_column(pg_enum(RoleName, "role_name"), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    # Founder, Co-Founder and Admin hold organization-wide permissions; others are project-scoped.
    organization_level: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    permissions: Mapped[list] = mapped_column(JSONB, default=list, server_default="[]", nullable=False)


class User(UUIDPk, Timestamps, Base):
    __tablename__ = "users"
    # Minimal personal data by design: no phone, address or government ID fields.
    email: Mapped[str] = mapped_column(String(320), nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[str | None] = mapped_column(String(200))
    organization_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="SET NULL"), index=True
    )
    role_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("roles.id", ondelete="RESTRICT"), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true", nullable=False)
    email_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    role: Mapped[Role] = relationship(lazy="joined")
    organization: Mapped[Organization | None] = relationship()

    __table_args__ = (Index("uq_users_email_lower", func.lower(email), unique=True),)


class Team(UUIDPk, Timestamps, Base):
    __tablename__ = "teams"
    organization_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    discipline: Mapped[Discipline | None] = mapped_column(pg_enum(Discipline, "discipline"))
    description: Mapped[str | None] = mapped_column(Text)
    members: Mapped[list["TeamMember"]] = relationship(back_populates="team", cascade="all, delete-orphan", passive_deletes=True)
    __table_args__ = (UniqueConstraint("organization_id", "name"),)


class TeamMember(CreatedAt, Base):
    """Association table required to link users to teams."""
    __tablename__ = "team_members"
    team_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("teams.id", ondelete="CASCADE"), primary_key=True)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True, index=True
    )
    team: Mapped[Team] = relationship(back_populates="members")


class UserToken(UUIDPk, CreatedAt, Base):
    """One-time tokens (email verification, password reset). Only the SHA-256 hash is stored."""
    __tablename__ = "user_tokens"
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    purpose: Mapped[str] = mapped_column(String(30), nullable=False)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint("purpose IN ('VERIFY_EMAIL', 'RESET_PASSWORD')", name="purpose_valid"),
    )
