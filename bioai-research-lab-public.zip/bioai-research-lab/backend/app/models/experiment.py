"""Experiments, results, models, model runs, features, statistics, validation and reports."""
import uuid
from datetime import datetime

from sqlalchemy import (Boolean, CheckConstraint, DateTime, Float, ForeignKey, Index, Integer, String, Text,
                        UniqueConstraint)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, CreatedAt, Timestamps, UUIDPk
from app.models.enums import (Algorithm, EvidenceLabel, ExperimentStatus, FeatureType, ImportanceMethod, Platform,
                              ReportStatus, Resampling, ResamplingScope, SplitStrategy, ValidationType, pg_enum)


class Experiment(UUIDPk, Timestamps, Base):
    """Every analysis is an experiment. Stores everything needed to re-run it."""
    __tablename__ = "experiments"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    # RESTRICT: a dataset version used by an experiment cannot be deleted (reproducibility).
    dataset_version_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dataset_versions.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    researcher_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    parent_experiment_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="SET NULL")
    )
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    platform: Mapped[Platform] = mapped_column(pg_enum(Platform, "platform"), nullable=False)
    analysis_type: Mapped[str] = mapped_column(String(80), nullable=False)
    status: Mapped[ExperimentStatus] = mapped_column(
        pg_enum(ExperimentStatus, "experiment_status"), nullable=False, server_default=ExperimentStatus.DRAFT.value, index=True
    )
    preprocessing: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    feature_selection: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    parameters: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    random_seed: Mapped[int] = mapped_column(Integer, nullable=False)
    code_version: Mapped[str] = mapped_column(String(80), nullable=False)
    software_versions: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    job_id: Mapped[str | None] = mapped_column(String(120), index=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    error_message: Mapped[str | None] = mapped_column(Text)

    results: Mapped[list["ExperimentResult"]] = relationship(back_populates="experiment", cascade="all, delete-orphan", passive_deletes=True)
    __table_args__ = (
        CheckConstraint("finished_at IS NULL OR started_at IS NULL OR finished_at >= started_at", name="times_ordered"),
        CheckConstraint("status <> 'FAILED' OR error_message IS NOT NULL", name="failed_has_error"),
        CheckConstraint("parent_experiment_id IS NULL OR parent_experiment_id <> id", name="not_own_parent"),
    )


class ExperimentResult(UUIDPk, CreatedAt, Base):
    __tablename__ = "experiment_results"
    experiment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    result_type: Mapped[str] = mapped_column(String(80), nullable=False)
    evidence_label: Mapped[EvidenceLabel] = mapped_column(pg_enum(EvidenceLabel, "evidence_label"), nullable=False)
    payload: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    artifact_key: Mapped[str | None] = mapped_column(String(512))
    experiment: Mapped[Experiment] = relationship(back_populates="results")


class Model(UUIDPk, Timestamps, Base):
    __tablename__ = "models"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    algorithm: Mapped[Algorithm] = mapped_column(pg_enum(Algorithm, "algorithm"), nullable=False)
    task: Mapped[str] = mapped_column(String(60), nullable=False, server_default="binary_classification")
    description: Mapped[str | None] = mapped_column(Text)
    created_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    __table_args__ = (UniqueConstraint("project_id", "name"),)


class ModelRun(UUIDPk, CreatedAt, Base):
    __tablename__ = "model_runs"
    model_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("models.id", ondelete="CASCADE"), nullable=False, index=True
    )
    experiment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    hyperparameters: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    split_strategy: Mapped[SplitStrategy] = mapped_column(pg_enum(SplitStrategy, "split_strategy"), nullable=False)
    n_folds: Mapped[int | None] = mapped_column(Integer)
    random_seed: Mapped[int] = mapped_column(Integer, nullable=False)
    resampling: Mapped[Resampling] = mapped_column(pg_enum(Resampling, "resampling"), nullable=False)
    resampling_scope: Mapped[ResamplingScope] = mapped_column(pg_enum(ResamplingScope, "resampling_scope"), nullable=False)
    class_distribution: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    metrics: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    artifact_key: Mapped[str | None] = mapped_column(String(512))
    __table_args__ = (
        # SMOTE may only ever be recorded as applied inside training folds.
        CheckConstraint(
            "(resampling = 'SMOTE' AND resampling_scope = 'TRAINING_FOLDS_ONLY') "
            "OR (resampling <> 'SMOTE')",
            name="smote_training_only",
        ),
        CheckConstraint("n_folds IS NULL OR n_folds >= 2", name="folds_min_two"),
    )


class Feature(UUIDPk, CreatedAt, Base):
    """Model feature importance. Describes the model, not biological importance."""
    __tablename__ = "features"
    model_run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("model_runs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    feature_type: Mapped[FeatureType] = mapped_column(pg_enum(FeatureType, "feature_type"), nullable=False)
    importance_method: Mapped[ImportanceMethod] = mapped_column(pg_enum(ImportanceMethod, "importance_method"), nullable=False)
    importance: Mapped[float] = mapped_column(Float, nullable=False)
    direction: Mapped[str | None] = mapped_column(String(20))
    rank: Mapped[int | None] = mapped_column(Integer)
    evidence_label: Mapped[EvidenceLabel] = mapped_column(
        pg_enum(EvidenceLabel, "evidence_label"), nullable=False, server_default=EvidenceLabel.EXPLANATION.value
    )
    __table_args__ = (
        UniqueConstraint("model_run_id", "name", "importance_method"),
        CheckConstraint("evidence_label = 'EXPLANATION'", name="importance_is_explanation"),
        CheckConstraint("rank IS NULL OR rank >= 1", name="rank_positive"),
    )


class StatisticsResult(UUIDPk, CreatedAt, Base):
    __tablename__ = "statistics_results"
    experiment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="CASCADE"), nullable=False, index=True
    )
    test_name: Mapped[str] = mapped_column(String(120), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    variable: Mapped[str] = mapped_column(String(200), nullable=False)
    groups: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    n: Mapped[int] = mapped_column(Integer, nullable=False)
    statistic: Mapped[float | None] = mapped_column(Float)
    p_value: Mapped[float | None] = mapped_column(Float)
    p_adjusted: Mapped[float | None] = mapped_column(Float)
    correction_method: Mapped[str | None] = mapped_column(String(60))
    effect_size: Mapped[float | None] = mapped_column(Float)
    effect_size_type: Mapped[str | None] = mapped_column(String(60))
    ci_low: Mapped[float | None] = mapped_column(Float)
    ci_high: Mapped[float | None] = mapped_column(Float)
    ci_level: Mapped[float | None] = mapped_column(Float)
    assumptions: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    researcher_override: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false", nullable=False)
    override_reason: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (
        CheckConstraint("n >= 1", name="n_positive"),
        CheckConstraint("p_value IS NULL OR (p_value >= 0 AND p_value <= 1)", name="p_range"),
        CheckConstraint("p_adjusted IS NULL OR (p_adjusted >= 0 AND p_adjusted <= 1)", name="padj_range"),
        CheckConstraint("p_adjusted IS NULL OR correction_method IS NOT NULL", name="padj_has_method"),
        CheckConstraint("ci_low IS NULL OR ci_high IS NULL OR ci_low <= ci_high", name="ci_ordered"),
        CheckConstraint("ci_level IS NULL OR (ci_level > 0 AND ci_level < 1)", name="ci_level_range"),
        CheckConstraint("NOT researcher_override OR override_reason IS NOT NULL", name="override_has_reason"),
    )


class ValidationRun(UUIDPk, CreatedAt, Base):
    __tablename__ = "validation_runs"
    model_run_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("model_runs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    validation_type: Mapped[ValidationType] = mapped_column(pg_enum(ValidationType, "validation_type"), nullable=False)
    train_dataset_version_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dataset_versions.id", ondelete="RESTRICT"), nullable=False
    )
    validation_dataset_version_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("dataset_versions.id", ondelete="RESTRICT")
    )
    metrics: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    calibration: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    feature_consistency: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    pathway_consistency: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (
        # External validation must use a different dataset version. Independence of the
        # underlying dataset (not just version) is enforced in the service layer.
        CheckConstraint(
            "validation_type <> 'EXTERNAL' OR (validation_dataset_version_id IS NOT NULL "
            "AND validation_dataset_version_id <> train_dataset_version_id)",
            name="external_is_independent",
        ),
    )


class Report(UUIDPk, Timestamps, Base):
    __tablename__ = "reports"
    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    experiment_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("experiments.id", ondelete="SET NULL"), index=True
    )
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    status: Mapped[ReportStatus] = mapped_column(pg_enum(ReportStatus, "report_status"), nullable=False, server_default=ReportStatus.DRAFT.value)
    sections: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    exports: Mapped[dict] = mapped_column(JSONB, default=dict, server_default="{}", nullable=False)
    created_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    approved_by_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint("status <> 'APPROVED' OR (approved_by_id IS NOT NULL AND approved_at IS NOT NULL)",
                        name="approved_has_approver"),
    )


Index("ix_experiment_results_type", ExperimentResult.experiment_id, ExperimentResult.result_type)
