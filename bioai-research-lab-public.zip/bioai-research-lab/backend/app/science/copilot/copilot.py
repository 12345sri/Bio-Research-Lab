"""Research Copilot: evidence-grounded assistance.

Three layers, so the assistant cannot silently invent results:
1. evidence(): the only facts the copilot may use, each with an evidence label and an ID.
2. review(): deterministic checks for missing validation, leakage risk, weak models and small samples.
3. answer(): calls a language model (optional) and then verify() rejects answers containing unlabelled
   claims or numbers that do not occur in the evidence.
"""
from __future__ import annotations

import json
import os
import re
import urllib.request

from app.science.common import EVIDENCE_LABELS

NUM = re.compile(r"(?<![\w.])-?\d+(?:\.\d+)?(?:e-?\d+)?")
FORBIDDEN = [r"\bdiagnos", r"\bproves?\b", r"\bcauses?\b", r"\bcure", r"\btreatment recommendation"]


def evidence(result: dict) -> list[dict]:
    ev = [{"id": f"E{i + 1}", **f} for i, f in enumerate(result.get("findings", []))]
    for r in review(result):
        ev.append({"id": f"R{len(ev) + 1}", "evidence_label": "INTERPRETATION", "statement": r["message"], "data": {}})
    return ev


def review(result: dict) -> list[dict]:
    issues = []
    ml = result.get("ml")
    if result.get("platform") == "BIOOMICS" and not result.get("external_validation"):
        issues.append({"code": "NO_EXTERNAL_VALIDATION", "severity": "high",
                       "message": "No external validation: performance may not generalise beyond this dataset."})
    if ml:
        for algo, r in ml["models"].items():
            for w in r["test"]["warnings"]:
                issues.append({"code": "MODEL_WARNING", "severity": "high", "message": f"{algo}: {w}"})
            if r["resampling"]["final"].get("scope") != "TRAINING_FOLDS_ONLY":
                issues.append({"code": "LEAKAGE_RISK", "severity": "critical",
                               "message": f"{algo}: resampling not confined to training folds."})
        for n in ml["comparison"]["notes"]:
            issues.append({"code": "MODELS_INDISTINGUISHABLE", "severity": "info", "message": n})
        d = ml["split"]["distribution"]["test"]
        if min(d.values()) < 10:
            issues.append({"code": "SMALL_TEST_CLASS", "severity": "medium",
                           "message": f"Test set has only {min(d.values())} samples in one class; metrics are unstable."})
        if ml.get("unavailable_models"):
            issues.append({"code": "MODEL_UNAVAILABLE", "severity": "info",
                           "message": "Not run in this environment: " + ", ".join(ml["unavailable_models"])})
    ses = result.get("sessions")
    if isinstance(ses, list):  # results reloaded from the database are lists of records
        import pandas as pd
        ses = pd.DataFrame(ses) if ses else None
    if ses is not None and "participant_code" in ses:
        n = ses.participant_code.nunique()
        if n < 20:
            issues.append({"code": "SMALL_SAMPLE", "severity": "medium",
                           "message": f"Only {n} participants; statistical power is limited and estimates are imprecise."})
        bad = ses[ses.quality_score == "POOR"]
        if len(bad):
            issues.append({"code": "POOR_QUALITY", "severity": "medium",
                           "message": f"{len(bad)} session(s) rated POOR by quality control."})
    exps = result.get("explanations") or (ml or {}).get("explanations") or {}
    if any(not e.get("shap_available") for e in exps.values()):
        issues.append({"code": "SHAP_UNAVAILABLE", "severity": "info",
                       "message": "SHAP not computed for some models (library not installed); permutation importance used."})
    return issues


def verify(answer: str, ev: list[dict]) -> dict:
    """Reject unlabelled claims, numbers absent from the evidence, and prohibited clinical/causal language."""
    known = set()
    for e in ev:
        for n in NUM.findall(json.dumps(e, default=str)):
            try:
                v = float(n)
            except ValueError:
                continue
            known |= {n, f"{v:g}", f"{v:.2f}", f"{v:.3f}", f"{v:.3g}", f"{v:.2g}", str(round(v))}
    problems = []
    for line in [l.strip() for l in answer.splitlines() if l.strip()]:
        m = re.match(r"^\[?(" + "|".join(EVIDENCE_LABELS) + r")\]?[:\s]", line)
        if not m:
            problems.append(f"Unlabelled statement: {line[:80]}")
            continue
        for n in NUM.findall(line):
            if n not in known and re.sub(r"\.?0+$", "", n) not in known and not re.fullmatch(r"E?\d{1,2}", n):
                problems.append(f"Number not found in evidence: {n}")
        if m.group(1) != "HYPOTHESIS":
            for pat in FORBIDDEN:
                if re.search(pat, line, re.I):
                    problems.append(f"Prohibited claim ({pat.strip(chr(92) + 'b')}) outside HYPOTHESIS: {line[:80]}")
    return {"grounded": not problems, "problems": problems}


PROMPT = """You are the Research Copilot of BioAI Research Lab, a research tool (not a medical device).
Answer ONLY from the evidence items below. Never invent numbers, results or citations.
Start every line with one label in brackets: [DATA], [STATISTICS], [MODEL], [EXPLANATION], [INTERPRETATION] or [HYPOTHESIS],
and cite evidence IDs like (E3). Never diagnose, never recommend treatment, never state that an association proves causation.
If the evidence does not answer the question, say so under [INTERPRETATION].

EVIDENCE:
{evidence}

QUESTION: {question}"""


def anthropic_llm(prompt: str) -> str:  # pragma: no cover - network call, verified only with a real key
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise RuntimeError("ANTHROPIC_API_KEY not configured; the copilot's language-model answers are disabled")
    body = json.dumps({"model": os.environ.get("COPILOT_MODEL", "claude-sonnet-4-5"), "max_tokens": 900,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
        "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.loads(r.read())
    return "".join(b.get("text", "") for b in data.get("content", []))


def answer(question: str, result: dict, llm=anthropic_llm) -> dict:
    ev = evidence(result)
    text = llm(PROMPT.format(evidence="\n".join(f"{e['id']} [{e['evidence_label']}] {e['statement']}" for e in ev),
                             question=question))
    check = verify(text, ev)
    return {"answer": text if check["grounded"] else None, "raw_answer": text, "verification": check,
            "evidence_ids": [e["id"] for e in ev],
            "status": "GROUNDED" if check["grounded"] else "REJECTED_UNGROUNDED"}
