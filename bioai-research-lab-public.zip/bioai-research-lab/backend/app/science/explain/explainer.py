"""Model explanations. These describe how a MODEL uses features; they are not biological importance.

- Logistic regression: exact interventional SHAP values for a linear model
  (phi_j = w_j * (x_j - E[x_j]) in log-odds, background = training data before resampling).
- Tree models / SVM: SHAP via the `shap` library when installed. If it is not installed the engine says
  so and reports permutation importance instead, clearly labelled as a different method.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

from app.science.common import finding
from app.science.ml.metrics import binary_metrics

LABEL = "MODEL FEATURE IMPORTANCE"
CAVEAT = "Model feature importance describes the model's use of features; it does not establish biological importance or causality."


def linear_shap(pipe, X: pd.DataFrame) -> dict:
    Xs = pipe.transform(X)
    w = pipe.model_.coef_.ravel()
    mu = pipe.background_.mean(axis=0)
    phi = (Xs - mu) * w
    base = float(pipe.model_.intercept_[0] + mu @ w)
    return {"values": phi, "base_value": base, "units": "log-odds", "method": "exact linear SHAP (interventional)",
            "features": pipe.features_, "X_scaled": Xs}


def library_shap(pipe, X: pd.DataFrame, seed: int, max_background: int = 50) -> dict | None:
    try:
        import shap
    except ImportError:
        return None
    Xs = pipe.transform(X)
    rng = np.random.default_rng(seed)
    bg = pipe.background_[rng.choice(len(pipe.background_), min(max_background, len(pipe.background_)), replace=False)]
    if pipe.algorithm in ("RANDOM_FOREST", "XGBOOST"):
        ex = shap.TreeExplainer(pipe.model_, bg, model_output="probability" if pipe.algorithm == "XGBOOST" else "raw")
        sv = ex.shap_values(Xs)
        sv = sv[1] if isinstance(sv, list) else (sv[..., 1] if np.ndim(sv) == 3 else sv)
        base = np.ravel(ex.expected_value)[-1]
        method = "TreeExplainer"
    else:
        ex = shap.KernelExplainer(lambda z: pipe.model_.predict_proba(z)[:, 1], bg)
        sv = ex.shap_values(Xs, nsamples=100, silent=True)
        base, method = ex.expected_value, "KernelExplainer"
    return {"values": np.asarray(sv), "base_value": float(base), "units": "model output", "method": f"shap {method}",
            "features": pipe.features_, "X_scaled": Xs}


def permutation_importance(pipe, X: pd.DataFrame, y01, n_repeats: int = 10, seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    base = binary_metrics(y01, pipe.predict_proba(X), curves=False)["roc_auc"]
    rows = []
    for f in pipe.features_:
        drops = []
        for _ in range(n_repeats):
            Xp = X.copy()
            Xp[f] = rng.permutation(Xp[f].to_numpy())
            drops.append(base - binary_metrics(y01, pipe.predict_proba(Xp), curves=False)["roc_auc"])
        rows.append({"feature": f, "importance": float(np.mean(drops)), "sd": float(np.std(drops))})
    rows.sort(key=lambda r: -r["importance"])
    return {"method": "permutation importance (ROC-AUC drop)", "n_repeats": n_repeats, "baseline_roc_auc": base,
            "ranking": rows, "label": LABEL, "caveat": CAVEAT}


def summarise(sh: dict, top_k: int = 20) -> dict:
    phi, Xs, feats = sh["values"], sh["X_scaled"], sh["features"]
    mean_abs = np.abs(phi).mean(axis=0)
    direction = []
    for j in range(phi.shape[1]):
        r = stats.spearmanr(Xs[:, j], phi[:, j]).statistic if np.ptp(Xs[:, j]) > 0 else 0.0
        direction.append("higher value raises prediction" if r > 0.1 else
                         "higher value lowers prediction" if r < -0.1 else "mixed")
    order = np.argsort(-mean_abs)
    ranking = [{"rank": i + 1, "feature": feats[j], "mean_abs_shap": float(mean_abs[j]), "direction": direction[j]}
               for i, j in enumerate(order[:top_k])]
    return {"method": sh["method"], "units": sh["units"], "base_value": sh["base_value"], "ranking": ranking,
            "label": LABEL, "caveat": CAVEAT,
            "statement": finding("EXPLANATION", f"Top features by mean |SHAP|: "
                                 + ", ".join(r["feature"] for r in ranking[:5]) + ". " + CAVEAT)}


def local_explanation(sh: dict, row: int, sample_id: str, top_k: int = 10) -> dict:
    phi = sh["values"][row]
    order = np.argsort(-np.abs(phi))[:top_k]
    return {"sample_id": sample_id, "base_value": sh["base_value"], "units": sh["units"],
            "output": float(sh["base_value"] + phi.sum()),
            "contributions": [{"feature": sh["features"][j], "shap": float(phi[j]),
                               "direction": "raises" if phi[j] > 0 else "lowers"} for j in order],
            "label": LABEL, "evidence_label": "EXPLANATION"}


def explain(pipe, X: pd.DataFrame, y01, seed: int) -> dict:
    sh = linear_shap(pipe, X) if pipe.algorithm == "LOGISTIC_REGRESSION" else library_shap(pipe, X, seed)
    if sh is None:
        return {"shap_available": False,
                "shap_unavailable_reason": "The shap library is not installed; SHAP was not computed for this model.",
                "permutation": permutation_importance(pipe, X, y01, seed=seed), "evidence_label": "EXPLANATION"}
    return {"shap_available": True, "global": summarise(sh),
            "local_examples": [local_explanation(sh, i, str(X.index[i])) for i in range(min(3, len(X)))],
            "_raw": sh, "evidence_label": "EXPLANATION"}


def ranking_consistency(rank_a: list[str], rank_b: list[str], top_k: int = 10) -> dict:
    common = [f for f in rank_a if f in rank_b]
    rho = stats.spearmanr([rank_a.index(f) for f in common], [rank_b.index(f) for f in common]).statistic \
        if len(common) > 2 else None
    overlap = len(set(rank_a[:top_k]) & set(rank_b[:top_k]))
    return {"spearman_rank_correlation": None if rho is None else float(rho), f"top_{top_k}_overlap": overlap}
