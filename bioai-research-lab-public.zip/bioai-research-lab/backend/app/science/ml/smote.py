"""SMOTE (Chawla et al., 2002) implemented for use strictly inside training data.

The function receives only training-fold data by construction: the ML engine calls it after the
split, inside each fold. It is never applied to validation, test or external data.
"""
from __future__ import annotations

import numpy as np

from app.science.common import ScienceError


def smote(X: np.ndarray, y: np.ndarray, k: int = 5, seed: int = 0) -> tuple[np.ndarray, np.ndarray, dict]:
    X = np.asarray(X, dtype=float)
    y = np.asarray(y)
    classes, counts = np.unique(y, return_counts=True)
    if classes.size != 2:
        raise ScienceError("SMOTE implementation supports binary outcomes")
    minority = classes[np.argmin(counts)]
    n_min, n_maj = counts.min(), counts.max()
    before = {str(c): int(n) for c, n in zip(classes, counts)}
    if n_min == n_maj:
        return X, y, {"before": before, "after": before, "synthetic": 0}
    Xm = X[y == minority]
    if Xm.shape[0] < 2:
        raise ScienceError("SMOTE needs at least 2 minority samples in the training data")
    k_eff = min(k, Xm.shape[0] - 1)
    d = ((Xm[:, None, :] - Xm[None, :, :]) ** 2).sum(-1)
    np.fill_diagonal(d, np.inf)
    nn = np.argsort(d, axis=1)[:, :k_eff]
    rng = np.random.default_rng(seed)
    n_new = n_maj - n_min
    base = rng.integers(0, Xm.shape[0], n_new)
    neigh = nn[base, rng.integers(0, k_eff, n_new)]
    gap = rng.random((n_new, 1))
    synth = Xm[base] + gap * (Xm[neigh] - Xm[base])
    Xr = np.vstack([X, synth])
    yr = np.concatenate([y, np.full(n_new, minority)])
    after = {str(c): int((yr == c).sum()) for c in classes}
    return Xr, yr, {"before": before, "after": after, "synthetic": int(n_new), "k_neighbors": int(k_eff)}
