"""Leak-free model training, cross-validation and evaluation.

Rules enforced here (see docs/scientific-rules.md):
- The test set is split off first and used once, after all choices are made on training data.
- Imputation, feature selection, scaling and SMOTE are fitted inside each training fold only.
- Repeated measures are split by group (participant), never by row.
- Models are compared on several metrics; no model is declared a biological "winner".
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from app.science.common import ScienceError, finding
from app.science.ml.metrics import binary_metrics
from app.science.ml.smote import smote

ALGORITHMS = ("LOGISTIC_REGRESSION", "SVM", "RANDOM_FOREST", "XGBOOST")


class ModelUnavailable(ScienceError):
    pass


def make_estimator(algorithm: str, params: dict, seed: int, balanced: bool):
    cw = "balanced" if balanced else None
    p = dict(params or {})
    if algorithm == "LOGISTIC_REGRESSION":
        return LogisticRegression(max_iter=5000, random_state=seed, class_weight=cw, **p)
    if algorithm == "SVM":
        return SVC(probability=True, random_state=seed, class_weight=cw, **p)
    if algorithm == "RANDOM_FOREST":
        p.setdefault("n_estimators", 300)
        return RandomForestClassifier(random_state=seed, class_weight=cw, n_jobs=1, **p)
    if algorithm == "XGBOOST":
        try:
            from xgboost import XGBClassifier
        except ImportError as e:
            raise ModelUnavailable("XGBoost is not installed in this environment") from e
        p.setdefault("n_estimators", 300)
        p.setdefault("max_depth", 3)
        p.setdefault("learning_rate", 0.05)
        return XGBClassifier(random_state=seed, eval_metric="logloss", n_jobs=1, **p)
    raise ScienceError(f"Unknown algorithm {algorithm}")


class FoldPipeline:
    """All fitted preprocessing lives here and is fitted on training data only."""

    def __init__(self, algorithm: str, config: dict, seed: int):
        self.algorithm, self.config, self.seed = algorithm, config, seed

    def fit(self, X: pd.DataFrame, y: np.ndarray):
        c = self.config
        self.input_features_ = list(X.columns)
        self.imputer_ = SimpleImputer(strategy="median").fit(X)
        Xi = pd.DataFrame(self.imputer_.transform(X), columns=X.columns, index=X.index)
        cols = list(X.columns)
        if c.get("variance_top_k") and c["variance_top_k"] < len(cols):
            cols = list(Xi.var().sort_values(ascending=False).index[: c["variance_top_k"]])
        if c.get("select_k_best") and c["select_k_best"] < len(cols):
            sel = SelectKBest(f_classif, k=c["select_k_best"]).fit(Xi[cols], y)
            cols = [f for f, keep in zip(cols, sel.get_support()) if keep]
        self.features_ = cols
        self.scaler_ = StandardScaler().fit(Xi[cols])
        Xs = self.scaler_.transform(Xi[cols])
        self.background_ = Xs.copy()  # training data before resampling (explanations, SHAP background)
        self.resampling_ = {"method": c.get("resampling", "NONE"), "scope": "TRAINING_FOLDS_ONLY"}
        yt = np.asarray(y)
        if c.get("resampling") == "SMOTE":
            Xs, yt, info = smote(Xs, yt, k=c.get("smote_k", 5), seed=self.seed)
            self.resampling_.update(info)
        self.model_ = make_estimator(self.algorithm, c.get("params", {}).get(self.algorithm, {}), self.seed,
                                     balanced=c.get("resampling") == "CLASS_WEIGHT")
        self.model_.fit(Xs, yt)
        return self

    def transform(self, X: pd.DataFrame) -> np.ndarray:
        missing = [f for f in self.input_features_ if f not in X.columns]
        if missing:
            raise ScienceError(f"{len(missing)} training features absent from new data, e.g. {missing[:5]}")
        Xi = pd.DataFrame(self.imputer_.transform(X[self.input_features_]), columns=self.input_features_)
        return self.scaler_.transform(Xi[self.features_])

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        return self.model_.predict_proba(self.transform(X))[:, 1]


def _encode(y: pd.Series, positive) -> np.ndarray:
    labels = sorted(pd.unique(y.dropna()).tolist(), key=str)
    if len(labels) != 2:
        raise ScienceError(f"Binary outcome required; found {labels}")
    if positive not in labels:
        raise ScienceError(f"Positive class {positive!r} not among {labels}")
    return (y == positive).astype(int).to_numpy()


def _splitter(n_folds, seed, grouped):
    return (StratifiedGroupKFold if grouped else StratifiedKFold)(n_splits=n_folds, shuffle=True, random_state=seed)


def split_train_test(X, y, groups, test_size, seed):
    idx = np.arange(len(y))
    if groups is None:
        tr, te = train_test_split(idx, test_size=test_size, stratify=y, random_state=seed)
    else:
        k = max(2, int(round(1 / test_size)))
        tr, te = next(_splitter(k, seed, True).split(X, y, groups))
        if set(np.asarray(groups)[tr]) & set(np.asarray(groups)[te]):
            raise ScienceError("Group leakage between train and test")  # defensive; should be impossible
    return tr, te


def train_and_evaluate(X: pd.DataFrame, y_raw: pd.Series, config: dict, groups=None) -> dict:
    """Split, cross-validate every requested algorithm on training data, then evaluate once on test."""
    seed = int(config.get("random_seed", 42))
    positive = config["positive_class"]
    y = _encode(pd.Series(y_raw, index=X.index), positive)
    n_folds = int(config.get("cv_folds", 5))
    g = None if groups is None else np.asarray(groups)
    if X.index.duplicated().any():
        raise ScienceError("Duplicate sample IDs in feature matrix")
    tr, te = split_train_test(X, y, g, float(config.get("test_size", 0.2)), seed)
    if set(X.index[tr]) & set(X.index[te]):
        raise ScienceError("Sample appears in both training and test data")
    Xtr, Xte, ytr, yte = X.iloc[tr], X.iloc[te], y[tr], y[te]
    if min(np.bincount(ytr, minlength=2)) < n_folds:
        raise ScienceError("Too few minority samples in training data for the requested CV folds")

    split = {"strategy": "PARTICIPANT" if g is not None else "STRATIFIED_ROW", "test_size": config.get("test_size", 0.2),
             "train_ids": list(X.index[tr]), "test_ids": list(X.index[te]),
             "distribution": {"original": _dist(y), "training": _dist(ytr), "test": _dist(yte)},
             "roles": {"TRAINING_DATA": len(tr), "INTERNAL_VALIDATION": f"{n_folds}-fold CV within training data",
                       "TEST_DATA": len(te), "EXTERNAL_VALIDATION": "separate dataset (not used here)"}}
    results, fitted, unavailable = {}, {}, {}
    for algo in config.get("algorithms", ["LOGISTIC_REGRESSION", "RANDOM_FOREST"]):
        try:
            make_estimator(algo, {}, seed, False)
        except ModelUnavailable as e:
            unavailable[algo] = str(e)
            continue
        folds, resampled = [], []
        gtr = None if g is None else g[tr]
        for f_tr, f_va in _splitter(n_folds, seed, g is not None).split(Xtr, ytr, gtr):
            pipe = FoldPipeline(algo, config, seed).fit(Xtr.iloc[f_tr], ytr[f_tr])
            folds.append(binary_metrics(ytr[f_va], pipe.predict_proba(Xtr.iloc[f_va]), curves=False))
            resampled.append(pipe.resampling_)
        final = FoldPipeline(algo, config, seed).fit(Xtr, ytr)
        test = binary_metrics(yte, final.predict_proba(Xte))
        fitted[algo] = final
        results[algo] = {"cv": _summarise(folds), "cv_folds": folds, "test": test,
                         "resampling": {"per_fold": resampled, "final": final.resampling_},
                         "selected_features": final.features_,
                         "evidence_label": "MODEL"}
    if not results:
        raise ScienceError(f"No requested algorithm is available: {unavailable}")
    return {"split": split, "models": results, "unavailable_models": unavailable,
            "comparison": compare(results), "positive_class": positive,
            "_fitted": fitted, "_train_index": list(X.index[tr])}


def _dist(y) -> dict:
    return {"positive": int(np.sum(y == 1)), "negative": int(np.sum(y == 0))}


def _summarise(folds):
    out = {}
    for k in ("roc_auc", "pr_auc", "balanced_accuracy", "accuracy", "f1", "recall", "specificity", "brier"):
        vals = [f[k] for f in folds if f.get(k) is not None]
        out[k] = {"mean": float(np.mean(vals)), "sd": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0} if vals else None
    return out


def compare(results: dict) -> dict:
    rows = sorted(results.items(), key=lambda kv: -(kv[1]["cv"]["roc_auc"] or {"mean": 0})["mean"])
    table = [{"algorithm": a, "cv_roc_auc_mean": r["cv"]["roc_auc"]["mean"], "cv_roc_auc_sd": r["cv"]["roc_auc"]["sd"],
              "cv_balanced_accuracy_mean": r["cv"]["balanced_accuracy"]["mean"],
              "test_roc_auc": r["test"]["roc_auc"], "test_pr_auc": r["test"]["pr_auc"],
              "test_balanced_accuracy": r["test"]["balanced_accuracy"], "warnings": r["test"]["warnings"]}
             for a, r in rows]
    notes = []
    if len(table) > 1:
        a, b = table[0], table[1]
        if abs(a["cv_roc_auc_mean"] - b["cv_roc_auc_mean"]) < (a["cv_roc_auc_sd"] + b["cv_roc_auc_sd"]):
            notes.append(f"{a['algorithm']} and {b['algorithm']} are not distinguishable given cross-validation variability.")
    return {"table": table, "notes": notes,
            "statement": finding("MODEL", "Models are ranked by cross-validated ROC-AUC on training data. "
                                 "Ranking describes predictive performance on this dataset only, "
                                 "not biological relevance.")}
