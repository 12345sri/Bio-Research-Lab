"""Binary classification metrics with baseline and degeneracy warnings."""
from __future__ import annotations

import numpy as np
from sklearn.calibration import calibration_curve
from sklearn.metrics import (average_precision_score, brier_score_loss, confusion_matrix, precision_recall_curve,
                             roc_auc_score, roc_curve)


def binary_metrics(y, p, threshold: float = 0.5, curves: bool = True) -> dict:
    y = np.asarray(y).astype(int)
    p = np.asarray(p, dtype=float)
    pred = (p >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    both = len(np.unique(y)) == 2
    sens = tp / (tp + fn) if tp + fn else None
    spec = tn / (tn + fp) if tn + fp else None
    prec = tp / (tp + fp) if tp + fp else None
    prevalence = float(y.mean())
    baseline = max(prevalence, 1 - prevalence)
    acc = float((tp + tn) / len(y))
    m = {
        "n": int(len(y)), "prevalence": prevalence, "threshold": threshold,
        "accuracy": acc, "majority_class_baseline_accuracy": baseline,
        "balanced_accuracy": float(np.mean([v for v in (sens, spec) if v is not None])),
        "precision": prec, "recall": sens, "specificity": spec,
        "f1": (2 * prec * sens / (prec + sens)) if prec and sens else 0.0,
        "roc_auc": float(roc_auc_score(y, p)) if both else None,
        "pr_auc": float(average_precision_score(y, p)) if both else None,
        "brier": float(brier_score_loss(y, p)),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }
    w = []
    if acc <= baseline + 0.02:
        w.append("Accuracy does not meaningfully exceed the majority-class baseline.")
    if sens is not None and spec is not None and (sens >= 0.99 and spec <= 0.05 or spec >= 0.99 and sens <= 0.05):
        w.append("Model predicts almost every sample as one class.")
    if m["roc_auc"] is not None and m["roc_auc"] < 0.6:
        w.append("ROC-AUC below 0.6 indicates weak discrimination.")
    m["warnings"] = w
    if curves and both:
        fpr, tpr, _ = roc_curve(y, p)
        pr, rc, _ = precision_recall_curve(y, p)
        bins = min(5, max(2, len(y) // 10))
        frac, meanp = calibration_curve(y, p, n_bins=bins, strategy="quantile")
        m["roc_curve"] = {"fpr": fpr.tolist(), "tpr": tpr.tolist()}
        m["pr_curve"] = {"precision": pr.tolist(), "recall": rc.tolist()}
        m["calibration"] = {"mean_predicted": meanp.tolist(), "observed_fraction": frac.tolist(), "bins": bins}
    return m
