"""Over-representation analysis (hypergeometric test) with Benjamini-Hochberg correction.

Gene sets are supplied by the researcher (GMT or CSV) so that licensing of pathway databases
(e.g. KEGG) is respected. The background must be the set of genes actually measured.
"""
from __future__ import annotations

import pandas as pd
from scipy import stats

from app.science.common import ScienceError, finding
from app.science.stats.tests import bh_adjust


def parse_gmt(text: str) -> dict[str, dict]:
    sets = {}
    for line in text.strip().splitlines():
        parts = line.rstrip("\n").split("\t")
        if len(parts) < 3:
            raise ScienceError(f"Malformed GMT line: {line[:60]}")
        sets[parts[0]] = {"name": parts[1] or parts[0], "genes": {g.strip().upper() for g in parts[2:] if g.strip()}}
    return sets


def enrich(query, background, gene_sets: dict[str, dict], database: str, release: str | None = None,
           min_size: int = 5, max_size: int = 500, alpha: float = 0.05) -> dict:
    q = {g.upper() for g in query}
    bg = {g.upper() for g in background}
    if not q:
        raise ScienceError("Empty query gene list")
    if not q <= bg:
        raise ScienceError(f"{len(q - bg)} query genes are not in the background")
    N, n = len(bg), len(q)
    rows, skipped = [], 0
    for sid, s in gene_sets.items():
        members = s["genes"] & bg
        K = len(members)
        if K < min_size or K > max_size:
            skipped += 1
            continue
        hits = sorted(members & q)
        k = len(hits)
        p = float(stats.hypergeom.sf(k - 1, N, K, n)) if k else 1.0
        rows.append({"pathway_id": sid, "name": s["name"], "genes": hits, "gene_count": k, "set_size": K,
                     "expected": n * K / N, "fold_enrichment": (k / n) / (K / N) if K else None, "p_value": p})
    df = pd.DataFrame(rows)
    if df.empty:
        raise ScienceError("No gene set within the size limits overlaps the background")
    df["p_adjusted"] = bh_adjust(df.p_value)
    df["correction_method"] = "Benjamini-Hochberg"
    df["significant"] = df.p_adjusted < alpha
    df = df.sort_values(["p_adjusted", "p_value"]).reset_index(drop=True)
    sig = df[df.significant]
    return {"database": database, "database_release": release, "test": "one-sided hypergeometric (over-representation)",
            "background_size": N, "query_size": n, "sets_tested": len(df), "sets_skipped_size": skipped,
            "alpha": alpha, "table": df,
            "statement": finding("STATISTICS", f"{len(sig)} of {len(df)} gene sets over-represented at "
                                 f"BH-adjusted p < {alpha}. Enrichment indicates overlap with annotated sets, "
                                 "not mechanism.")}
