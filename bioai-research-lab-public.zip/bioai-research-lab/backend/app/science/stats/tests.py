"""Statistical tests with full methodological transparency.

Every result reports: test, reason for choosing it, n, statistic, p, effect size, CI and assumptions.
The researcher may override the automatic choice; the override is recorded with its reason.
"""
from __future__ import annotations

import numpy as np
from scipy import stats

from app.science.common import ScienceError


def describe(x) -> dict:
    a = np.asarray(x, dtype=float)
    a = a[np.isfinite(a)]
    if a.size == 0:
        raise ScienceError("No finite values")
    q1, med, q3 = np.percentile(a, [25, 50, 75])
    return {"n": int(a.size), "mean": float(a.mean()), "sd": float(a.std(ddof=1)) if a.size > 1 else None,
            "median": float(med), "q1": float(q1), "q3": float(q3), "min": float(a.min()), "max": float(a.max())}


def normality(x, alpha: float = 0.05) -> dict:
    a = np.asarray(x, dtype=float)
    a = a[np.isfinite(a)]
    if a.size < 3:
        return {"test": "Shapiro-Wilk", "applicable": False, "reason": "n < 3"}
    if np.ptp(a) == 0:
        return {"test": "Shapiro-Wilk", "applicable": False, "reason": "no variance"}
    w, p = stats.shapiro(a)
    return {"test": "Shapiro-Wilk", "applicable": True, "W": float(w), "p": float(p), "normal": bool(p >= alpha)}


def bh_adjust(pvalues) -> np.ndarray:
    """Benjamini-Hochberg false discovery rate adjustment (monotone, capped at 1)."""
    p = np.asarray(pvalues, dtype=float)
    n = p.size
    if n == 0:
        return p
    order = np.argsort(p)
    ranked = p[order] * n / np.arange(1, n + 1)
    adj = np.minimum.accumulate(ranked[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.minimum(adj, 1.0)
    return out


def _bootstrap_ci(values, func, n_boot, level, seed):
    rng = np.random.default_rng(seed)
    v = np.asarray(values)
    boots = np.array([func(v[rng.integers(0, v.size, v.size)]) for _ in range(n_boot)])
    a = (1 - level) / 2
    return float(np.quantile(boots, a)), float(np.quantile(boots, 1 - a))


def compare_paired(a, b, method: str = "auto", alpha: float = 0.05, ci_level: float = 0.95,
                   n_boot: int = 2000, seed: int = 0, override_reason: str | None = None) -> dict:
    """Compare two paired conditions (b - a), e.g. normal day vs exam day in the same participants."""
    x, y = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if x.shape != y.shape:
        raise ScienceError("Paired comparison requires equal-length, aligned samples")
    keep = np.isfinite(x) & np.isfinite(y)
    x, y = x[keep], y[keep]
    d = y - x
    n = int(d.size)
    if n < 3:
        raise ScienceError("Paired comparison needs at least 3 complete pairs")
    norm = normality(d, alpha)
    if method == "auto":
        method = "paired_t" if norm.get("normal", False) else "wilcoxon"
        reason = ("differences consistent with normality (Shapiro-Wilk p >= alpha)" if method == "paired_t"
                  else "differences not shown to be normal or normality untestable; non-parametric test used")
    else:
        if not override_reason:
            raise ScienceError("Overriding the automatic test choice requires a reason")
        reason = f"researcher override: {override_reason}"
    if method == "paired_t":
        res = stats.ttest_rel(y, x)
        sd = d.std(ddof=1)
        eff = float(d.mean() / sd) if sd > 0 else None
        tcrit = stats.t.ppf(1 - (1 - ci_level) / 2, n - 1)
        se = sd / np.sqrt(n)
        out = {"test": "Paired t-test", "statistic": float(res.statistic), "p_value": float(res.pvalue),
               "effect_size": eff, "effect_size_type": "Cohen's dz",
               "estimate": float(d.mean()), "estimate_type": "mean difference (b - a)",
               "ci_low": float(d.mean() - tcrit * se), "ci_high": float(d.mean() + tcrit * se),
               "assumptions": {"normality_of_differences": norm, "independent_pairs": "assumed by design"}}
    elif method == "wilcoxon":
        nz = d[d != 0]
        if nz.size == 0:
            raise ScienceError("All paired differences are zero")
        res = stats.wilcoxon(y, x, zero_method="wilcox")
        ranks = stats.rankdata(np.abs(nz))
        rbc = float((ranks[nz > 0].sum() - ranks[nz < 0].sum()) / ranks.sum())
        lo, hi = _bootstrap_ci(d, np.median, n_boot, ci_level, seed)
        out = {"test": "Wilcoxon signed-rank test", "statistic": float(res.statistic), "p_value": float(res.pvalue),
               "effect_size": rbc, "effect_size_type": "matched-pairs rank-biserial correlation",
               "estimate": float(np.median(d)), "estimate_type": "median difference (b - a)",
               "ci_low": lo, "ci_high": hi, "ci_method": f"percentile bootstrap, {n_boot} resamples, seed {seed}",
               "assumptions": {"symmetric_differences": "assumed", "zero_differences_dropped": int((d == 0).sum())}}
    else:
        raise ScienceError(f"Unknown paired method: {method}")
    return {**out, "reason": reason, "n": n, "ci_level": ci_level, "alpha": alpha,
            "researcher_override": override_reason is not None, "override_reason": override_reason,
            "descriptives": {"a": describe(x), "b": describe(y)}}


def compare_independent(a, b, method: str = "auto", alpha: float = 0.05, ci_level: float = 0.95,
                        override_reason: str | None = None) -> dict:
    x = np.asarray(a, dtype=float); x = x[np.isfinite(x)]
    y = np.asarray(b, dtype=float); y = y[np.isfinite(y)]
    if min(x.size, y.size) < 3:
        raise ScienceError("Each group needs at least 3 observations")
    nx, ny = normality(x, alpha), normality(y, alpha)
    if method == "auto":
        method = "welch" if nx.get("normal") and ny.get("normal") else "mann_whitney"
        reason = ("both groups consistent with normality; Welch t-test (no equal-variance assumption)"
                  if method == "welch" else "normality not supported in at least one group; non-parametric test")
    else:
        if not override_reason:
            raise ScienceError("Overriding the automatic test choice requires a reason")
        reason = f"researcher override: {override_reason}"
    if method == "welch":
        res = stats.ttest_ind(y, x, equal_var=False)
        sp = np.sqrt(((x.size - 1) * x.var(ddof=1) + (y.size - 1) * y.var(ddof=1)) / (x.size + y.size - 2))
        g = (y.mean() - x.mean()) / sp * (1 - 3 / (4 * (x.size + y.size) - 9)) if sp > 0 else None
        ci = res.confidence_interval(ci_level)
        out = {"test": "Welch t-test", "statistic": float(res.statistic), "p_value": float(res.pvalue),
               "effect_size": None if g is None else float(g), "effect_size_type": "Hedges' g",
               "estimate": float(y.mean() - x.mean()), "estimate_type": "mean difference (b - a)",
               "ci_low": float(ci.low), "ci_high": float(ci.high),
               "assumptions": {"normality": {"a": nx, "b": ny}, "equal_variance": "not assumed"}}
    elif method == "mann_whitney":
        res = stats.mannwhitneyu(y, x, alternative="two-sided")
        rbc = float(2 * res.statistic / (x.size * y.size) - 1)
        out = {"test": "Mann-Whitney U test", "statistic": float(res.statistic), "p_value": float(res.pvalue),
               "effect_size": rbc, "effect_size_type": "rank-biserial correlation",
               "estimate": float(np.median(y) - np.median(x)), "estimate_type": "difference in medians (b - a)",
               "ci_low": None, "ci_high": None,
               "assumptions": {"independent_observations": "assumed by design", "normality": {"a": nx, "b": ny}}}
    else:
        raise ScienceError(f"Unknown independent method: {method}")
    return {**out, "reason": reason, "n": int(x.size + y.size), "n_a": int(x.size), "n_b": int(y.size),
            "ci_level": ci_level, "alpha": alpha, "researcher_override": override_reason is not None,
            "override_reason": override_reason, "descriptives": {"a": describe(x), "b": describe(y)}}


def correlation(x, y, method: str = "spearman") -> dict:
    a, b = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    k = np.isfinite(a) & np.isfinite(b)
    if k.sum() < 3:
        raise ScienceError("Correlation needs at least 3 complete pairs")
    fn = {"spearman": stats.spearmanr, "pearson": stats.pearsonr}[method]
    r, p = fn(a[k], b[k])
    return {"test": f"{method.title()} correlation", "r": float(r), "p_value": float(p), "n": int(k.sum()),
            "note": "Correlation does not establish causation."}
