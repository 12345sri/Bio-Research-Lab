"""End-to-end analysis pipelines. These are what the background worker runs for an experiment.

Inputs are data frames plus a JSON-serialisable configuration; outputs are JSON-serialisable results
(with private objects under keys starting with "_") and full provenance for reproduction.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from app.science.biosignal.hrv import frequency_domain, time_domain, windows
from app.science.biosignal.pseudonymize import pseudonymize
from app.science.biosignal.qc import qc_rr
from app.science.common import DISCLAIMER, ScienceError, data_hash, finding, provenance
from app.science.explain.explainer import explain, ranking_consistency
from app.science.ml.engine import train_and_evaluate
from app.science.network.networks import correlation_network
from app.science.omics.preprocess import differential_expression, integrate_layers, orient, preprocess, qc
from app.science.pathway.enrichment import enrich, parse_gmt
from app.science.stats.tests import bh_adjust, compare_paired
from app.science.validation.external import validate_external

HRV_METRICS = ("mean_hr_bpm", "min_hr_bpm", "max_hr_bpm", "sdnn_ms", "rmssd_ms", "lf_hf_ratio")


def run_biosignal(df: pd.DataFrame, config: dict, pseudonym_key: str) -> dict:
    """RR-interval workflow: pseudonymise, QC, HRV, paired condition comparison, optional ML on windows."""
    need = {"participant_id", "session_id", "condition", "rr_ms"}
    if not need <= set(df.columns):
        raise ScienceError(f"Missing columns: {sorted(need - set(df.columns))}")
    qc_cfg = config.get("qc", {})
    freq_cfg = config.get("frequency", {})
    df = df.copy()
    df["participant_code"] = [pseudonymize(p, pseudonym_key) for p in df.participant_id]
    df = df.drop(columns=["participant_id"])  # raw identifiers never leave this function

    sessions, window_rows = [], []
    for (code, sess, cond), g in df.groupby(["participant_code", "session_id", "condition"], sort=True):
        q = qc_rr(g.rr_ms.to_numpy(), **qc_cfg)
        td = time_domain(q["values_ms"], q["valid_mask"])
        fd = frequency_domain(q["values_ms"], q["valid_mask"], **freq_cfg)
        sessions.append({"participant_code": code, "session_id": sess, "condition": cond,
                         "quality_score": q["quality_score"], "n_total": q["n_total"], "n_valid": q["n_valid"],
                         "n_excluded": q["n_excluded"], "exclusion_reasons": q["exclusion_reasons"],
                         **td, **{k: v for k, v in fd.items() if k != "spectrum"}, "evidence_label": "DATA"})
        if config.get("window_s"):
            for a, b in windows(q["values_ms"], config["window_s"]):
                m = q["valid_mask"][a:b]
                if m.sum() >= 20:
                    w = time_domain(q["values_ms"][a:b], m)
                    window_rows.append({"participant_code": code, "condition": cond,
                                        **{k: w[k] for k in ("mean_hr_bpm", "sdnn_ms", "rmssd_ms", "pnn50_pct")}})
    ses = pd.DataFrame(sessions)

    comparisons = []
    a_cond, b_cond = config.get("compare", ["NORMAL_DAY", "EXAM_DAY"])
    wide = ses.pivot_table(index="participant_code", columns="condition", values=list(HRV_METRICS), aggfunc="first")
    for metric in HRV_METRICS:
        if (metric, a_cond) not in wide or (metric, b_cond) not in wide:
            continue
        pair = wide[[(metric, a_cond), (metric, b_cond)]].dropna()
        if len(pair) < 3:
            comparisons.append({"metric": metric, "skipped": f"only {len(pair)} complete pairs"})
            continue
        res = compare_paired(pair.iloc[:, 0], pair.iloc[:, 1], seed=config.get("random_seed", 0),
                             method=config.get("paired_method", "auto"),
                             override_reason=config.get("paired_override_reason"))
        comparisons.append({"metric": metric, "condition_a": a_cond, "condition_b": b_cond, **res})
    tested = [c for c in comparisons if "p_value" in c]
    for c, padj in zip(tested, bh_adjust([c["p_value"] for c in tested])):
        c["p_adjusted"] = float(padj)
        c["correction_method"] = "Benjamini-Hochberg across HRV metrics"
        c["evidence_label"] = "STATISTICS"

    ml = None
    if config.get("ml") and window_rows:
        wdf = pd.DataFrame(window_rows)
        wdf.index = [f"W{i:05d}" for i in range(len(wdf))]
        feats = wdf[["mean_hr_bpm", "sdnn_ms", "rmssd_ms", "pnn50_pct"]]
        ml_cfg = {**config["ml"], "random_seed": config.get("random_seed", 0)}
        ml = train_and_evaluate(feats, wdf.condition, ml_cfg, groups=wdf.participant_code.to_numpy())
        fitted = ml.pop("_fitted")
        te = ml["split"]["test_ids"]
        y01 = (wdf.loc[te, "condition"] == ml_cfg["positive_class"]).astype(int).to_numpy()
        ml["explanations"] = {a: _strip(explain(p, feats.loc[te], y01, ml_cfg["random_seed"])) for a, p in fitted.items()}

    freq_invalid = ses[~ses.frequency_domain_valid]
    findings = [
        finding("DATA", f"{len(ses)} sessions from {ses.participant_code.nunique()} pseudonymised participants; "
                f"{int(ses.n_excluded.sum())} of {int(ses.n_total.sum())} beats excluded by quality control."),
    ]
    if len(freq_invalid):
        findings.append(finding("DATA", f"Frequency-domain HRV not computed for {len(freq_invalid)} session(s): "
                                + "; ".join(sorted(set(freq_invalid.frequency_domain_note)))))
    for c in tested:
        findings.append(finding("STATISTICS",
                                f"{c['metric']}: {c['test']}, n={c['n']}, {c['estimate_type']} {c['estimate']:.3g} "
                                f"({c['ci_level']:.0%} CI {_fmt(c['ci_low'])} to {_fmt(c['ci_high'])}), "
                                f"{c['effect_size_type']} {_fmt(c['effect_size'])}, p={c['p_value']:.3g}, "
                                f"BH-adjusted p={c['p_adjusted']:.3g}."))
    return {"platform": "BIOSIGNAL", "sessions": ses, "comparisons": comparisons, "ml": ml, "findings": findings,
            "disclaimer": DISCLAIMER,
            "provenance": provenance(config, config.get("random_seed"),
                                     ["pseudonymise participant IDs (HMAC-SHA256)", "RR quality control",
                                      "time-domain HRV", "frequency-domain HRV where valid",
                                      "paired condition comparison with BH correction"]
                                     + (["participant-grouped ML on windows", "explanations"] if ml else []),
                                     {"rr_data": data_hash(df.drop(columns=["participant_code"]))})}


def run_omics(expr: pd.DataFrame, meta: pd.DataFrame, config: dict, gmt_text: str | None = None,
              external: tuple[pd.DataFrame, pd.DataFrame] | None = None,
              extra_layers: dict[str, pd.DataFrame] | None = None) -> dict:
    seed = int(config.get("random_seed", 42))
    grp, pos, neg = config["group_column"], config["positive_class"], config["negative_class"]
    meta = meta.set_index(meta[config.get("sample_column", "sample_id")].astype(str))
    x_raw, orient_info = orient(expr, meta.index, config.get("orientation"))
    qc_report = qc(x_raw)
    x, prep_log = preprocess(x_raw, **config.get("preprocess", {}))
    shared = [s for s in x.index if s in meta.index]
    dropped = sorted(set(x.index) - set(shared))
    x = x.loc[shared]
    y = meta.loc[shared, grp]

    de = differential_expression(x, y, neg, pos, alpha=config.get("alpha", 0.05))
    ml_x = x
    integration = None
    if extra_layers:
        # Integrated model is a separate analysis; external validation uses the expression model,
        # whose features can be matched by name in an independent expression dataset.
        ix, integration = integrate_layers({"expr": x, **extra_layers})
        iml = train_and_evaluate(ix, meta.loc[ix.index, grp], {**config["ml"], "positive_class": pos, "random_seed": seed})
        iml.pop("_fitted"); iml.pop("_train_index")
        integration["ml"] = iml
    ml = train_and_evaluate(ml_x, y, {**config["ml"], "positive_class": pos, "random_seed": seed})
    fitted = ml.pop("_fitted")
    train_idx = ml.pop("_train_index")
    te = ml["split"]["test_ids"]
    y01_te = (y.loc[te] == pos).astype(int).to_numpy()
    explanations = {a: explain(p, ml_x.loc[te], y01_te, seed) for a, p in fitted.items()}

    top = de[de.significant].feature.tolist()[: config.get("network_max_genes", 40)] or de.feature.tolist()[:20]
    net = correlation_network(x, top, **config.get("network", {}))
    pathway = None
    if gmt_text:
        sig = de[de.significant].feature.tolist()
        if sig:
            pathway = enrich(sig, x.columns, parse_gmt(gmt_text), database=config.get("gene_set_database", "USER_GMT"),
                             release=config.get("gene_set_release"), **config.get("pathway", {}))

    ext = None
    if external is not None:
        ex_expr, ex_meta = external
        ex_meta = ex_meta.set_index(ex_meta[config.get("sample_column", "sample_id")].astype(str))
        ex_x, _ = orient(ex_expr, ex_meta.index, config.get("external_orientation"))
        if config.get("preprocess", {}).get("log2_transform"):
            ex_x = np.log2(ex_x + 1)
        cols = [c for c in ml_x.columns if c in ex_x.columns]
        ex_x = ex_x.reindex(columns=ml_x.columns)  # absent features become NaN, imputed by the frozen pipeline
        ext = validate_external(fitted, ml_x.loc[train_idx], ex_x.loc[[s for s in ex_x.index if s in ex_meta.index]],
                                ex_meta[grp], pos, train_dataset_id=config.get("dataset_id"),
                                ext_dataset_id=config.get("external_dataset_id"))
        ext["feature_coverage"] = {"present": len(cols), "expected": ml_x.shape[1]}
        for a, p in fitted.items():
            ey = (ex_meta.loc[ex_x.index, grp] == pos).astype(int).to_numpy()
            e_ext = explain(p, ex_x, ey, seed)
            e_int = explanations[a]
            if e_ext.get("shap_available") and e_int.get("shap_available"):
                ext["models"][a]["feature_consistency"] = ranking_consistency(
                    [r["feature"] for r in e_int["global"]["ranking"]], [r["feature"] for r in e_ext["global"]["ranking"]])

    findings = [finding("DATA", f"{x.shape[0]} samples and {prep_log['original_features']} features; "
                        f"{x.shape[1]} features retained after label-free preprocessing."),
                finding("STATISTICS", f"{int(de.significant.sum())} features differ between {pos} and {neg} at "
                        f"BH-adjusted p < {config.get('alpha', 0.05)}."),
                ml["comparison"]["statement"], net["statement"]]
    for a, r in ml["models"].items():
        t = r["test"]
        findings.append(finding("MODEL", f"{a}: test ROC-AUC {_fmt(t['roc_auc'])}, PR-AUC {_fmt(t['pr_auc'])}, "
                                f"balanced accuracy {_fmt(t['balanced_accuracy'])} (n={t['n']})."
                                + (" Warnings: " + " ".join(t["warnings"]) if t["warnings"] else "")))
    for a, e in explanations.items():
        if e.get("shap_available"):
            findings.append(e["global"]["statement"])
    if pathway:
        findings.append(pathway["statement"])
    if ext:
        for a, r in ext["models"].items():
            findings.append(finding("MODEL", f"External validation {a}: ROC-AUC {_fmt(r['roc_auc'])}, "
                                    f"balanced accuracy {_fmt(r['balanced_accuracy'])} (n={r['n']})."))
    findings.append(finding("HYPOTHESIS", "Features ranked highly by both differential analysis and model "
                            "explanation are candidates for further study. Independent replication and experimental "
                            "work would be required to establish any biological role."))

    return {"platform": "BIOOMICS", "orientation": orient_info, "qc": qc_report, "preprocessing": prep_log,
            "samples_without_metadata": dropped, "differential_expression": de, "integration": integration,
            "ml": ml, "explanations": {a: _strip(e) for a, e in explanations.items()},
            "network": _strip(net), "pathway": pathway, "external_validation": ext,
            "findings": findings, "disclaimer": DISCLAIMER,
            "_fitted": fitted, "_explanations_raw": explanations, "_network_graph": net["_graph"],
            "provenance": provenance(config, seed,
                                     ["orient matrix", "QC report", "label-free preprocessing",
                                      "differential expression with BH", "train/test split",
                                      "cross-validation with in-fold imputation, selection, scaling, resampling",
                                      "test evaluation", "explanations", "correlation network", "pathway enrichment",
                                      "external validation of frozen models"],
                                     {"expression": data_hash(expr), "metadata": data_hash(meta)})}


def _strip(d: dict) -> dict:
    return {k: v for k, v in d.items() if not k.startswith("_")}


def _fmt(v):
    return "n/a" if v is None else f"{v:.3g}"
