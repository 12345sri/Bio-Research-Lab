"""ECG R-peak detection (Pan-Tompkins-style) with validation that the signal behaves like an ECG."""
from __future__ import annotations

import numpy as np
from scipy import signal

from app.science.common import ScienceError


def detect_r_peaks(ecg, fs: float) -> dict:
    x = np.asarray(ecg, dtype=float)
    if fs is None or fs < 100:
        raise ScienceError("ECG sampling rate must be at least 100 Hz for R-peak detection")
    if x.size < fs * 10:
        raise ScienceError("ECG recording shorter than 10 s")
    if np.isnan(x).mean() > 0.01:
        raise ScienceError("More than 1% of ECG samples are missing")
    x = np.nan_to_num(x, nan=np.nanmedian(x))
    b, a = signal.butter(2, [5 / (fs / 2), 15 / (fs / 2)], btype="band")
    filt = signal.filtfilt(b, a, x)
    energy = np.convolve(np.gradient(filt) ** 2, np.ones(int(0.15 * fs)) / int(0.15 * fs), mode="same")
    peaks, _ = signal.find_peaks(energy, height=0.3 * np.percentile(energy, 99), distance=int(0.25 * fs))
    # Refine each detection to the largest absolute filtered deflection within +/- 75 ms.
    w = int(0.075 * fs)
    refined = []
    for p in peaks:
        lo, hi = max(0, p - w), min(len(filt), p + w)
        refined.append(lo + int(np.argmax(np.abs(filt[lo:hi]))))
    refined = np.unique(refined)
    if refined.size < 10:
        raise ScienceError("Fewer than 10 beats detected; signal does not look like an ECG")
    rr = np.diff(refined) / fs * 1000.0
    hr = 60000.0 / np.median(rr)
    irregular = float(np.mean(np.abs(np.diff(rr)) / rr[:-1] > 0.3))
    plausible = 30 <= hr <= 220 and irregular < 0.3
    if not plausible:
        raise ScienceError(f"Signal failed ECG plausibility checks (median HR {hr:.0f} bpm, "
                           f"{irregular:.0%} irregular intervals); confirm signal type")
    return {"r_peak_samples": refined, "rr_ms": rr, "median_hr_bpm": hr,
            "irregular_fraction": irregular, "signal_type_validated": True, "sampling_rate_hz": fs}
