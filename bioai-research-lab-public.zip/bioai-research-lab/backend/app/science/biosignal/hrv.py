"""Time- and frequency-domain HRV. Frequency measures are computed only when technically valid.

Band definitions follow the 1996 Task Force of the ESC and NASPE HRV standard
(LF 0.04-0.15 Hz, HF 0.15-0.40 Hz; short-term recordings of about 5 minutes recommended).
"""
from __future__ import annotations

import numpy as np
from scipy import interpolate, signal

from app.science.common import ScienceError

LF = (0.04, 0.15)
HF = (0.15, 0.40)


def time_domain(values_ms, valid_mask) -> dict:
    v = np.asarray(values_ms, dtype=float)
    m = np.asarray(valid_mask, dtype=bool)
    rr = v[m]
    if rr.size < 3:
        raise ScienceError("Fewer than 3 valid RR intervals")
    # Successive differences only between adjacent beats that are both valid.
    pairs = m[1:] & m[:-1]
    d = np.diff(v)[pairs]
    hr = 60000.0 / rr
    return {
        "n_beats": int(rr.size),
        "mean_rr_ms": float(rr.mean()),
        "mean_hr_bpm": float(60000.0 / rr.mean()),
        "min_hr_bpm": float(hr.min()),
        "max_hr_bpm": float(hr.max()),
        "sdnn_ms": float(rr.std(ddof=1)),
        "rmssd_ms": float(np.sqrt(np.mean(d ** 2))) if d.size else None,
        "pnn50_pct": float(100 * np.mean(np.abs(d) > 50)) if d.size else None,
        "n_successive_pairs": int(d.size),
        "hr_note": "Min/max HR are instantaneous beat-to-beat values from valid beats.",
    }


def frequency_domain(values_ms, valid_mask, min_duration_s: float = 120.0,
                     max_excluded_fraction: float = 0.05, fs_interp: float = 4.0) -> dict:
    v = np.asarray(values_ms, dtype=float)
    m = np.asarray(valid_mask, dtype=bool)
    duration = float(np.nansum(np.where(m, v, np.nan))) / 1000.0
    excl = 1 - m.mean()
    reasons = []
    if duration < min_duration_s:
        reasons.append(f"valid recording {duration:.0f} s is shorter than the {min_duration_s:.0f} s minimum")
    if excl > max_excluded_fraction:
        reasons.append(f"{excl:.1%} of beats excluded (limit {max_excluded_fraction:.0%})")
    if m.sum() < 30:
        reasons.append("fewer than 30 valid beats")
    base = {"frequency_domain_valid": False, "lf_power_ms2": None, "hf_power_ms2": None, "lf_hf_ratio": None,
            "duration_s": duration, "method": "cubic interpolation 4 Hz, linear detrend, Welch PSD",
            "bands_hz": {"LF": LF, "HF": HF}}
    if reasons:
        return {**base, "frequency_domain_note": "; ".join(reasons)}

    # Replace the few excluded beats by interpolation from valid neighbours (recorded in the note).
    idx = np.arange(v.size)
    filled = v.copy()
    filled[~m] = np.interp(idx[~m], idx[m], v[m])
    t = np.cumsum(filled) / 1000.0
    t -= t[0]
    grid = np.arange(0, t[-1], 1 / fs_interp)
    y = signal.detrend(interpolate.CubicSpline(t, filled)(grid))
    nperseg = min(256, y.size)
    f, pxx = signal.welch(y, fs=fs_interp, nperseg=nperseg, noverlap=nperseg // 2)

    def band(lo, hi):
        sel = (f >= lo) & (f < hi)
        return float(np.trapezoid(pxx[sel], f[sel])) if sel.sum() > 1 else 0.0

    lf, hf = band(*LF), band(*HF)
    return {**base, "frequency_domain_valid": True, "lf_power_ms2": lf, "hf_power_ms2": hf,
            "lf_hf_ratio": lf / hf if hf > 0 else None,
            "frequency_domain_note": f"{int((~m).sum())} excluded beat(s) interpolated before spectral analysis",
            "spectrum": {"f_hz": f[f <= 0.5], "psd_ms2_per_hz": pxx[f <= 0.5]}}


def windows(values_ms, window_s: float):
    """Split a series into consecutive windows of about window_s seconds (index ranges)."""
    v = np.nan_to_num(np.asarray(values_ms, dtype=float), nan=0.0)
    t = np.cumsum(v) / 1000.0
    out, start = [], 0
    for i in range(len(v)):
        if t[i] - (t[start - 1] if start else 0) >= window_s:
            out.append((start, i + 1))
            start = i + 1
    return out
