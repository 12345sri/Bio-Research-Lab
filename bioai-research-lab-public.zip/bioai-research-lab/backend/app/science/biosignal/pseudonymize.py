"""Keyed pseudonymisation of participant identifiers (HMAC-SHA256).

The same identifier and key always give the same code, so sessions link up; without the key the
code cannot be reversed or recomputed. The raw identifier is never stored.
"""
import hashlib
import hmac

from app.science.common import ScienceError


def pseudonymize(identifier: str, key: str, prefix: str = "P") -> str:
    if not key or len(key) < 16:
        raise ScienceError("Pseudonymisation key must be at least 16 characters")
    if identifier is None or str(identifier).strip() == "":
        raise ScienceError("Empty participant identifier")
    digest = hmac.new(key.encode(), str(identifier).strip().encode(), hashlib.sha256).hexdigest()
    return f"{prefix}-{digest[:12]}"
