"""Quality control for RR-interval series. Every observation is classified; nothing is silently removed."""
from __future__ import annotations

import numpy as np

from app.science.common import ScienceError


def qc_rr(rr_ms, min_rr: float = 300.0, max_rr: float = 2000.0, max_rel_change: float = 0.2,
          local_window: int = 5) -> dict:
    """Classify each RR value as valid or excluded with a reason.

    Reasons: missing, out_of_range (physiologically implausible), artifact (change of more than
    max_rel_change relative to the median of the preceding valid beats; ectopic/missed beats).
    """
    raw = list(rr_ms)
    n = len(raw)
    if n == 0:
        raise ScienceError("No RR observations supplied")
    values = np.full(n, np.nan)
    reasons: list[str | None] = [None] * n
    for i, v in enumerate(raw):
        try:
            f = float(v)
        except (TypeError, ValueError):
            reasons[i] = "non_numeric"
            continue
        if not np.isfinite(f):
            reasons[i] = "missing"
            continue
        values[i] = f
        if f < min_rr or f > max_rr:
            reasons[i] = "out_of_range"

    recent: list[float] = []
    for i in range(n):
        if reasons[i] is not None:
            continue
        if len(recent) >= 3:
            ref = float(np.median(recent[-local_window:]))
            if abs(values[i] - ref) / ref > max_rel_change:
                reasons[i] = "artifact"
                continue
        recent.append(values[i])

    valid = np.array([r is None for r in reasons])
    counts: dict[str, int] = {}
    for r in reasons:
        if r:
            counts[r] = counts.get(r, 0) + 1
    n_valid = int(valid.sum())
    frac_excl = 1 - n_valid / n
    gaps = int(np.sum(np.diff(np.concatenate([[1], valid.astype(int)])) == -1))
    if n_valid < 30 or frac_excl > 0.20:
        score = "POOR"
    elif frac_excl > 0.05:
        score = "MODERATE"
    else:
        score = "GOOD"
    return {
        "values_ms": values,
        "valid_mask": valid,
        "reasons": reasons,
        "n_total": n,
        "n_valid": n_valid,
        "n_excluded": n - n_valid,
        "exclusion_reasons": counts,
        "excluded_fraction": frac_excl,
        "n_gaps": gaps,
        "quality_score": score,
        "rules": {"min_rr_ms": min_rr, "max_rr_ms": max_rr, "max_relative_change": max_rel_change},
    }
