"""Expression data loading, orientation, QC, preprocessing, differential expression and integration.

Label-dependent or data-fitted steps used for machine learning (imputation, scaling, variance and
univariate selection) are deliberately NOT here: they run inside training folds in app.science.ml.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from app.science.common import ScienceError
from app.science.stats.tests import bh_adjust


class AmbiguousOrientation(ScienceError):
    """Orientation could not be inferred; the researcher must confirm it."""


def orient(expr: pd.DataFrame, sample_ids, orientation: str | None = None) -> tuple[pd.DataFrame, dict]:
    """Return a samples x features matrix. Infers orientation from sample IDs unless given."""
    ids = set(map(str, sample_ids))
    cols, rows = set(map(str, expr.columns)), set(map(str, expr.index))
    col_hit, row_hit = len(ids & cols), len(ids & rows)
    if orientation is None:
        if col_hit and not row_hit:
            orientation = "GENES_AS_ROWS"
        elif row_hit and not col_hit:
            orientation = "SAMPLES_AS_ROWS"
        else:
            raise AmbiguousOrientation(
                f"Cannot infer orientation (sample IDs match {col_hit} columns and {row_hit} rows); "
                "please confirm GENES_AS_ROWS or SAMPLES_AS_ROWS")
        confirmed = False
    else:
        confirmed = True
    if orientation == "GENES_AS_ROWS":
        m = expr.T.copy()
    elif orientation == "SAMPLES_AS_ROWS":
        m = expr.copy()
    else:
        raise ScienceError(f"Unknown orientation {orientation}")
    m.index = m.index.map(str)
    m.columns = m.columns.map(str)
    return m, {"orientation": orientation, "orientation_confirmed": confirmed,
               "matched_sample_ids": max(col_hit, row_hit)}


def qc(m: pd.DataFrame) -> dict:
    """QC report for a samples x features matrix. Reports issues; removes nothing."""
    numeric = m.apply(pd.to_numeric, errors="coerce")
    non_numeric = int(numeric.isna().sum().sum() - m.isna().sum().sum())
    miss_feat = numeric.isna().mean(axis=0)
    miss_samp = numeric.isna().mean(axis=1)
    var = numeric.var(axis=0, skipna=True)
    corr = numeric.fillna(numeric.median()).T.corr() if numeric.shape[0] > 2 else None
    outliers = []
    if corr is not None:
        mean_corr = (corr.sum() - 1) / (corr.shape[0] - 1)
        z = (mean_corr - mean_corr.median()) / (1.4826 * (mean_corr - mean_corr.median()).abs().median() + 1e-12)
        outliers = list(z[z < -3.5].index)
    return {
        "n_samples": int(m.shape[0]), "n_features": int(m.shape[1]),
        "non_numeric_values": non_numeric,
        "missing_fraction_total": float(numeric.isna().mean().mean()),
        "features_with_missing": int((miss_feat > 0).sum()),
        "samples_with_missing": int((miss_samp > 0).sum()),
        "duplicate_features": sorted(set(m.columns[m.columns.duplicated()])),
        "duplicate_samples": sorted(set(m.index[m.index.duplicated()])),
        "zero_variance_features": int((var.fillna(0) == 0).sum()),
        "negative_values": int((numeric < 0).sum().sum()),
        "outlier_samples_candidate": outliers,
        "outlier_rule": "median inter-sample correlation robust z < -3.5 (flagged for inspection, not removed)",
        "value_range": [float(np.nanmin(numeric.values)), float(np.nanmax(numeric.values))],
    }


def preprocess(m: pd.DataFrame, max_missing: float = 0.2, log2_transform: bool = False,
               drop_zero_variance: bool = True, duplicate_policy: str = "mean") -> tuple[pd.DataFrame, dict]:
    """Label-free preprocessing. Every removed feature is listed with its reason."""
    log: dict = {"original_features": int(m.shape[1]), "removed": {}}
    x = m.apply(pd.to_numeric, errors="coerce")
    if x.index.duplicated().any():
        raise ScienceError(f"Duplicate sample IDs: {sorted(set(x.index[x.index.duplicated()]))[:10]}")
    if x.columns.duplicated().any():
        dups = sorted(set(x.columns[x.columns.duplicated()]))
        if duplicate_policy != "mean":
            raise ScienceError(f"Duplicate features {dups[:10]}; choose a duplicate policy")
        x = x.T.groupby(level=0).mean().T
        log["duplicates_averaged"] = dups
    miss = x.isna().mean()
    drop = list(miss[miss > max_missing].index)
    log["removed"]["missing_above_threshold"] = drop
    x = x.drop(columns=drop)
    if log2_transform:
        if (x < 0).any().any():
            raise ScienceError("log2 transform requested but negative values are present")
        x = np.log2(x + 1)
        log["transform"] = "log2(x + 1)"
    if drop_zero_variance:
        zv = list(x.columns[x.var(skipna=True).fillna(0) == 0])
        log["removed"]["zero_variance"] = zv
        x = x.drop(columns=zv)
    log["filtered_features"] = int(x.shape[1])
    log["remaining_missing_values"] = int(x.isna().sum().sum())
    log["note"] = "Remaining missing values are imputed inside training folds during machine learning."
    return x, log


def differential_expression(x: pd.DataFrame, groups: pd.Series, group_a, group_b, test: str = "welch",
                            log_scale: bool = True, alpha: float = 0.05) -> pd.DataFrame:
    """Per-feature two-group comparison with log2 fold change and BH-adjusted p-values (b vs a)."""
    from scipy import stats
    g = groups.reindex(x.index)
    a, b = x[g == group_a], x[g == group_b]
    if min(len(a), len(b)) < 3:
        raise ScienceError("Each group needs at least 3 samples for differential analysis")
    if test == "welch":
        p = stats.ttest_ind(b, a, equal_var=False, nan_policy="omit").pvalue
    elif test == "mann_whitney":
        p = np.array([stats.mannwhitneyu(b[c].dropna(), a[c].dropna()).pvalue for c in x.columns])
    else:
        raise ScienceError(f"Unknown test {test}")
    p = np.asarray(p, dtype=float)
    lfc = (b.mean() - a.mean()) if log_scale else np.log2((b.mean() + 1e-9) / (a.mean() + 1e-9))
    res = pd.DataFrame({"feature": x.columns, "mean_a": a.mean().values, "mean_b": b.mean().values,
                        "log2_fold_change": np.asarray(lfc), "p_value": p})
    ok = np.isfinite(res.p_value)
    res.loc[ok, "p_adjusted"] = bh_adjust(res.loc[ok, "p_value"])
    res["significant"] = res.p_adjusted < alpha
    res["test"] = {"welch": "Welch t-test", "mann_whitney": "Mann-Whitney U"}[test]
    res["correction"] = "Benjamini-Hochberg"
    return res.sort_values(["p_adjusted", "log2_fold_change"], key=lambda s: s.abs() if s.name == "log2_fold_change" else s,
                           ascending=[True, False]).reset_index(drop=True)


def integrate_layers(layers: dict[str, pd.DataFrame]) -> tuple[pd.DataFrame, dict]:
    """Early (concatenation) integration of omics layers on shared samples. Dropped samples are reported."""
    if len(layers) < 2:
        raise ScienceError("Integration requires at least two layers")
    common = set.intersection(*(set(df.index) for df in layers.values()))
    if len(common) < 6:
        raise ScienceError(f"Only {len(common)} samples shared across layers")
    order = sorted(common)
    parts, report = [], {}
    for name, df in layers.items():
        report[name] = {"samples": int(df.shape[0]), "features": int(df.shape[1]),
                        "samples_not_shared": sorted(set(df.index) - common)}
        parts.append(df.loc[order].add_prefix(f"{name}::"))
    return pd.concat(parts, axis=1), {"method": "early integration (feature concatenation)",
                                      "shared_samples": len(order), "layers": report,
                                      "note": "Per-feature scaling is fitted inside training folds."}
