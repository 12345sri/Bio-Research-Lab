"""Gene networks. Every network declares what its edges mean; correlation is never called regulation."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd
from scipy import stats

from app.science.common import ScienceError, finding
from app.science.stats.tests import bh_adjust

EDGE_TYPES = ("CORRELATION", "KNOWN_INTERACTION", "PREDICTED_INTERACTION", "REGULATORY")


def correlation_network(x: pd.DataFrame, features: list[str] | None = None, method: str = "spearman",
                        threshold: float = 0.7, alpha: float = 0.05, hub_quantile: float = 0.9) -> dict:
    """Undirected co-expression network: edge if |r| >= threshold and BH-adjusted p < alpha."""
    if not 0 < threshold < 1:
        raise ScienceError("Correlation threshold must be between 0 and 1")
    if features is not None and len(features) == 0:
        raise ScienceError("Empty feature list supplied for network construction")
    m = x[features] if features is not None else x
    if m.shape[1] < 3 or m.shape[0] < 5:
        raise ScienceError("Need at least 3 features and 5 samples")
    arr = m.to_numpy(dtype=float)
    if method == "spearman":
        r, p = stats.spearmanr(arr, nan_policy="omit")
    elif method == "pearson":
        r = np.corrcoef(arr, rowvar=False)
        n = arr.shape[0]
        t = r * np.sqrt((n - 2) / np.clip(1 - r ** 2, 1e-12, None))
        p = 2 * stats.t.sf(np.abs(t), n - 2)
    else:
        raise ScienceError(f"Unknown method {method}")
    r, p = np.atleast_2d(r), np.atleast_2d(p)
    iu = np.triu_indices(m.shape[1], 1)
    padj = bh_adjust(p[iu])
    names = list(m.columns)
    g = nx.Graph()
    g.add_nodes_from(names)
    for (i, j), rij, pa in zip(zip(*iu), r[iu], padj):
        if abs(rij) >= threshold and pa < alpha:
            g.add_edge(names[i], names[j], weight=float(rij), p_adjusted=float(pa), edge_type="CORRELATION")
    return describe(g, edge_type="CORRELATION", params={"method": method, "threshold": threshold, "alpha": alpha,
                                                         "correction": "Benjamini-Hochberg"}, hub_quantile=hub_quantile)


def edge_list_network(edges: pd.DataFrame, edge_type: str, source: str, hub_quantile: float = 0.9) -> dict:
    """Network from user-supplied interactions (e.g. curated PPI). The source must be cited."""
    if edge_type not in EDGE_TYPES or edge_type == "CORRELATION":
        raise ScienceError("Use correlation_network for correlation edges")
    if not source:
        raise ScienceError("Curated or predicted interactions must cite their source")
    if not {"source_node", "target_node"} <= set(edges.columns):
        raise ScienceError("Edge list needs columns source_node, target_node")
    g = nx.Graph()
    for row in edges.itertuples():
        g.add_edge(str(row.source_node), str(row.target_node), edge_type=edge_type)
    return describe(g, edge_type, {"source": source}, hub_quantile)


def describe(g: nx.Graph, edge_type: str, params: dict, hub_quantile: float = 0.9) -> dict:
    deg = dict(g.degree())
    btw = nx.betweenness_centrality(g) if g.number_of_edges() else {n: 0.0 for n in g}
    eig_note = None
    if g.number_of_edges() == 0:
        eig = {n: 0.0 for n in g}
    elif not nx.is_connected(g):
        # Eigenvector centrality is not well defined across disconnected components.
        eig = {n: None for n in g}
        eig_note = (f"Eigenvector centrality not computed: the network has "
                    f"{nx.number_connected_components(g)} disconnected components.")
    else:
        try:
            eig = nx.eigenvector_centrality_numpy(g)
        except Exception as exc:  # numerically degenerate graph
            eig = {n: None for n in g}
            eig_note = f"Eigenvector centrality could not be computed ({type(exc).__name__})."
    cutoff = np.quantile(list(deg.values()), hub_quantile) if deg else 0
    hubs = sorted([n for n, d in deg.items() if d >= max(cutoff, 1)], key=lambda n: -deg[n])
    nodes = [{"node": n, "degree": deg[n], "betweenness": btw[n], "eigenvector": eig[n], "hub": n in hubs}
             for n in sorted(g, key=lambda n: -deg[n])]
    edges = [{"source": u, "target": v, **d} for u, v, d in g.edges(data=True)]
    meaning = {"CORRELATION": "statistical co-variation across samples (not regulation or causation)",
               "KNOWN_INTERACTION": "interaction reported by the cited source",
               "PREDICTED_INTERACTION": "computationally predicted interaction (requires validation)",
               "REGULATORY": "regulatory relationship reported by the cited source"}[edge_type]
    return {"edge_type": edge_type, "edge_meaning": meaning, "params": params,
            "n_nodes": g.number_of_nodes(), "n_edges": g.number_of_edges(), "density": nx.density(g),
            "n_components": nx.number_connected_components(g) if g.number_of_nodes() else 0,
            "hub_rule": f"degree >= {hub_quantile:.0%} quantile (and >= 1)", "hub_genes": hubs,
            "nodes": nodes, "edges": edges, "_graph": g, "eigenvector_note": eig_note,
            "statement": finding("STATISTICS" if edge_type == "CORRELATION" else "DATA",
                                 f"Network of {g.number_of_nodes()} nodes and {g.number_of_edges()} edges; "
                                 f"edges represent {meaning}. Hub status reflects connectivity in this network only."
                                 + (f" {eig_note}" if eig_note else ""))}
