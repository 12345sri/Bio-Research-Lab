"""DEMONSTRATION DATA generator. Every value is synthetic, produced from a fixed seed.

These datasets exist to exercise the software end to end. They are not biomedical evidence,
contain no real participants or patients, and use invented gene names (DEMO_G###).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

BANNER = "DEMONSTRATION DATA - SYNTHETIC - NOT REAL BIOMEDICAL EVIDENCE"


def synthetic_rr(n_beats, mean_rr, lf_amp, hf_amp, noise, rng):
    t, out = 0.0, []
    lf_ph, hf_ph = rng.uniform(0, 2 * np.pi, 2)
    for _ in range(n_beats):
        rr = mean_rr + lf_amp * np.sin(2 * np.pi * 0.1 * t + lf_ph) + hf_amp * np.sin(2 * np.pi * 0.25 * t + hf_ph) \
            + rng.normal(0, noise)
        out.append(rr)
        t += rr / 1000
    return np.array(out)


def biosignal_demo(n_participants: int = 12, seed: int = 2026) -> pd.DataFrame:
    """Long-format RR data: two sessions per participant (NORMAL_DAY, EXAM_DAY), ~5 minutes each."""
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(1, n_participants + 1):
        base = rng.normal(850, 60)
        hf = rng.normal(30, 6)
        for cond, shift, hf_scale in (("NORMAL_DAY", 0, 1.0), ("EXAM_DAY", -70, 0.6)):
            rr = synthetic_rr(360, base + shift + rng.normal(0, 15), 20, hf * hf_scale, 8, rng)
            # Inject a few artifacts so quality control has something to classify.
            for j in rng.choice(np.arange(20, 340), 3, replace=False):
                rr[j] = rr[j] * rng.choice([0.55, 1.6])
            if i == 3 and cond == "EXAM_DAY":
                rr[100] = 3500.0  # implausible value, e.g. a missed detection
            for b, v in enumerate(rr):
                rows.append({"participant_id": f"student_{i:02d}", "session_id": f"{cond.lower()}_1",
                             "condition": cond, "beat_index": b, "rr_ms": round(float(v), 1)})
    df = pd.DataFrame(rows)
    df.attrs["banner"] = BANNER
    return df


def synthetic_ecg(rr_ms, fs: float = 250.0, seed: int = 1) -> np.ndarray:
    rng = np.random.default_rng(seed)
    beat_times = np.cumsum(rr_ms) / 1000
    t = np.arange(0, beat_times[-1] + 1, 1 / fs)
    ecg = np.zeros_like(t)
    for bt in beat_times:
        for off, amp, w in ((-0.2, 0.12, 0.025), (-0.03, -0.1, 0.01), (0, 1.0, 0.012), (0.03, -0.25, 0.01), (0.25, 0.3, 0.04)):
            ecg += amp * np.exp(-((t - bt - off) ** 2) / (2 * w ** 2))
    return ecg + 0.03 * rng.standard_normal(t.size) + 0.1 * np.sin(2 * np.pi * 0.3 * t)


def omics_demo(n_samples: int = 200, n_genes: int = 400, n_signal: int = 20, late_fraction: float = 0.25,
               seed: int = 2026, prefix: str = "S") -> tuple[pd.DataFrame, pd.DataFrame]:
    """Genes-as-rows expression matrix (log2 scale) and sample metadata. Signal genes DEMO_G001..G020."""
    rng = np.random.default_rng(seed)
    genes = [f"DEMO_G{i:03d}" for i in range(1, n_genes + 1)]
    samples = [f"{prefix}{i:04d}" for i in range(1, n_samples + 1)]
    stage = np.where(rng.random(n_samples) < late_fraction, "LATE", "EARLY")
    latent = rng.normal(0, 1, (n_samples, 5))
    load = rng.normal(0, 0.4, (5, n_genes))
    x = 6 + latent @ load + rng.normal(0, 0.8, (n_samples, n_genes))
    module = rng.normal(0, 1, n_samples)  # synthetic co-expression module shared by the signal genes
    x[:, :n_signal] += 1.0 * module[:, None]
    x[stage == "LATE", :n_signal] += rng.uniform(0.9, 1.4, n_signal)
    x[stage == "LATE", n_signal:n_signal + 5] -= 0.7
    x[rng.random(x.shape) < 0.01] = np.nan
    expr = pd.DataFrame(x.T, index=genes, columns=samples)
    meta = pd.DataFrame({"sample_id": samples, "stage": stage, "batch": rng.choice(["B1", "B2"], n_samples)})
    return expr, meta


def second_layer_demo(meta: pd.DataFrame, n_features: int = 60, seed: int = 7) -> pd.DataFrame:
    """Synthetic methylation-like layer (samples as rows), weakly associated with stage."""
    rng = np.random.default_rng(seed)
    x = rng.beta(2, 5, (len(meta), n_features))
    late = (meta.stage == "LATE").to_numpy()
    x[late, :5] = np.clip(x[late, :5] + 0.08, 0, 1)
    return pd.DataFrame(x, index=meta.sample_id, columns=[f"DEMO_CPG{i:03d}" for i in range(1, n_features + 1)])


def gene_sets_demo(n_genes: int = 400, seed: int = 11) -> str:
    """GMT text of invented gene sets. DEMO_SET_SIGNAL overlaps the planted signal genes."""
    rng = np.random.default_rng(seed)
    lines = ["DEMO_SET_SIGNAL\tsynthetic set overlapping planted signal\t" +
             "\t".join([f"DEMO_G{i:03d}" for i in range(1, 16)] + [f"DEMO_G{i:03d}" for i in range(200, 210)])]
    for s in range(1, 30):
        pool = np.arange(26, n_genes + 1)
        members = rng.choice(pool, min(int(rng.integers(10, 40)), len(pool)), replace=False)
        lines.append(f"DEMO_SET_{s:02d}\tsynthetic background set {s}\t" + "\t".join(f"DEMO_G{m:03d}" for m in members))
    return "\n".join(lines)
