"""External validation on an independent dataset, with guards against reuse of training data."""
from __future__ import annotations

import numpy as np
import pandas as pd

from app.science.common import ScienceError, data_hash, finding
from app.science.ml.metrics import binary_metrics


class NotIndependent(ScienceError):
    pass


def check_independence(train_X: pd.DataFrame, ext_X: pd.DataFrame, train_dataset_id=None, ext_dataset_id=None) -> dict:
    if train_dataset_id is not None and train_dataset_id == ext_dataset_id:
        raise NotIndependent("External validation dataset is the same dataset used for training")
    overlap = sorted(set(map(str, train_X.index)) & set(map(str, ext_X.index)))
    if overlap:
        raise NotIndependent(f"{len(overlap)} sample IDs appear in both training and external data, e.g. {overlap[:5]}")
    common = [c for c in ext_X.columns if c in train_X.columns]
    tr_rows = {tuple(np.round(r, 8)) for r in train_X[common].fillna(-9e9).to_numpy()}
    dup = sum(tuple(np.round(r, 8)) in tr_rows for r in ext_X[common].fillna(-9e9).to_numpy())
    if dup:
        raise NotIndependent(f"{dup} external samples are identical to training samples")
    return {"train_hash": data_hash(train_X), "external_hash": data_hash(ext_X), "sample_overlap": 0,
            "identical_rows": 0, "independent": True}


def validate_external(fitted: dict, train_X: pd.DataFrame, ext_X: pd.DataFrame, ext_y: pd.Series, positive,
                      train_dataset_id=None, ext_dataset_id=None) -> dict:
    """Evaluate frozen, already-trained pipelines. External data is never used for fitting."""
    independence = check_independence(train_X, ext_X, train_dataset_id, ext_dataset_id)
    y = (pd.Series(ext_y, index=ext_X.index) == positive).astype(int).to_numpy()
    out = {}
    for algo, pipe in fitted.items():
        out[algo] = binary_metrics(y, pipe.predict_proba(ext_X))
    return {"role": "EXTERNAL_VALIDATION", "independence": independence, "n": int(len(y)),
            "distribution": {"positive": int(y.sum()), "negative": int((1 - y).sum())}, "models": out,
            "statement": finding("MODEL", "Performance of frozen models on an independent dataset that was not "
                                 "used for training, tuning or feature selection.")}
