"""Structured research report from pipeline results. Exports HTML, PDF, JSON and CSV."""
from __future__ import annotations

import base64
import datetime as dt
import html
import io
import json
import pathlib
import zipfile

import pandas as pd

from app.science.common import DISCLAIMER, EVIDENCE_LABELS, clean
from app.science.reports import figures as F

EVIDENCE_LEGEND = {
    "DATA": "Observed values in the uploaded dataset",
    "STATISTICS": "Named statistical test with n, statistic, p, effect size and CI",
    "MODEL": "Machine-learning output on the stated data split",
    "EXPLANATION": "How the model uses features; not biological importance",
    "LITERATURE": "Claims supported by a verifiable reference",
    "INTERPRETATION": "Reasoned reading of the evidence above",
    "HYPOTHESIS": "Candidate idea requiring independent validation",
}


def _df(obj) -> pd.DataFrame | None:
    return obj if isinstance(obj, pd.DataFrame) else None


def build(result: dict, project: dict, review: list[dict] | None = None) -> dict:
    """Assemble the 16 report sections from actual results. Returns a report dict with figures as PNG bytes."""
    plat = result["platform"]
    S, figs, tables = [], {}, {}

    def sec(title, items=None, table=None, fig=None, text=None):
        S.append({"title": title, "items": items or [], "table": table, "figure": fig, "text": text})

    sec("1. Project information", text=f"{project.get('name', 'Untitled project')}. Platform: {plat}. "
        f"Principal researcher: {project.get('principal_researcher', 'not specified')}.")
    sec("2. Research question", text=project.get("research_question", "Not specified."))
    prov = result["provenance"]
    if plat == "BIOSIGNAL":
        ses = result["sessions"]
        tables["sessions"] = ses
        sec("3. Dataset information", [f for f in result["findings"] if f["evidence_label"] == "DATA"],
            table="sessions", text=f"{ses.participant_code.nunique()} pseudonymised participants, {len(ses)} sessions.")
        sec("4. Data preprocessing", text="RR quality control classified every beat as valid or excluded "
            f"(rules: {prov['config'].get('qc', 'defaults: 300-2000 ms, 20% successive change')}). "
            "Frequency-domain HRV was computed only for recordings meeting duration and artifact limits.")
        comp = pd.DataFrame([{k: c.get(k) for k in ("metric", "test", "n", "estimate", "ci_low", "ci_high",
                                                    "effect_size", "effect_size_type", "p_value", "p_adjusted")}
                             for c in result["comparisons"] if "p_value" in c])
        tables["comparisons"] = comp
        for m in ("rmssd_ms", "mean_hr_bpm"):
            if m in set(ses.columns):
                figs[f"paired_{m}"] = F.paired_conditions(ses, m, *prov["config"].get("compare", ["NORMAL_DAY", "EXAM_DAY"]))
        sec("5. Statistical methods", [f for f in result["findings"] if f["evidence_label"] == "STATISTICS"],
            table="comparisons", fig=[k for k in figs if k.startswith("paired_")],
            text="Paired comparisons chosen by normality of differences (Shapiro-Wilk); Benjamini-Hochberg "
                 "correction across HRV metrics. Researcher overrides are recorded.")
        ml = result.get("ml")
    else:
        de = result["differential_expression"]
        tables["differential_expression"] = de.head(200)
        sec("3. Dataset information", [f for f in result["findings"] if f["evidence_label"] == "DATA"],
            text=f"Orientation: {result['orientation']['orientation']} "
                 f"({'confirmed' if result['orientation']['orientation_confirmed'] else 'inferred from sample IDs'}). "
                 f"QC flagged {len(result['qc']['outlier_samples_candidate'])} candidate outlier samples (not removed).")
        pl = result["preprocessing"]
        sec("4. Data preprocessing", text=f"{pl['original_features']} features, {pl['filtered_features']} retained. "
            f"Removed for missingness: {len(pl['removed'].get('missing_above_threshold', []))}; zero variance: "
            f"{len(pl['removed'].get('zero_variance', []))}. {pl['note']}")
        sec("5. Statistical methods", [f for f in result["findings"] if f["evidence_label"] == "STATISTICS"][:1],
            table="differential_expression", text="Per-feature Welch t-test with log2 fold change and "
            "Benjamini-Hochberg adjusted p-values.")
        ml = result["ml"]

    if ml:
        cfg = prov["config"].get("ml", {})
        sec("6. Machine-learning methods", text=f"Split: {ml['split']['strategy']}, test fraction "
            f"{ml['split']['test_size']}. {cfg.get('cv_folds', 5)}-fold cross-validation on training data only. "
            f"Resampling: {cfg.get('resampling', 'NONE')} inside training folds. Seed {prov['random_seed']}. "
            f"Class distribution: {ml['split']['distribution']}. Unavailable models: "
            f"{ml['unavailable_models'] or 'none'}.")
        tables["model_comparison"] = pd.DataFrame(ml["comparison"]["table"])
        figs["roc"] = F.roc_curves(ml["models"])
        figs["calibration"] = F.calibration(ml["models"])
        model_items, seen = [], set()
        for f in [ml["comparison"]["statement"]] + [f for f in result["findings"] if f["evidence_label"] == "MODEL"]:
            if f["statement"] not in seen:  # a statement can arrive both directly and via findings
                seen.add(f["statement"]); model_items.append(f)
        sec("7. Model performance", model_items,
            table="model_comparison", fig=["roc", "calibration"], text=" ".join(ml["comparison"]["notes"]))
        ex = result.get("explanations") or ml.get("explanations") or {}
        items, fk = [], []
        for algo, e in ex.items():
            if e.get("shap_available"):
                items.append(e["global"]["statement"])
                figs[f"shap_{algo}"] = F.importance_bar(e["global"]["ranking"], "mean_abs_shap",
                                                       f"{algo}: mean |SHAP| (model feature importance)")
                fk.append(f"shap_{algo}")
            else:
                items.append({"evidence_label": "EXPLANATION", "statement":
                              f"{algo}: {e['shap_unavailable_reason']} Permutation importance shown instead."})
                figs[f"perm_{algo}"] = F.importance_bar(e["permutation"]["ranking"], "importance",
                                                       f"{algo}: permutation importance (ROC-AUC drop)")
                fk.append(f"perm_{algo}")
        sec("8. Explainability", items, fig=fk)
    else:
        sec("6. Machine-learning methods", text="No machine-learning analysis in this experiment.")
        sec("7. Model performance", text="Not applicable.")
        sec("8. Explainability", text="Not applicable.")

    net = result.get("network")
    if net:
        tables["network_nodes"] = pd.DataFrame(net["nodes"])
        figs["network"] = F.network_plot(result["_network_graph"], net["hub_genes"])
        sec("9. Network analysis", [net["statement"]], table="network_nodes", fig=["network"],
            text=f"Edges: {net['edge_meaning']}. Parameters: {net['params']}. Hub rule: {net['hub_rule']}.")
    else:
        sec("9. Network analysis", text="Not applicable to this experiment.")
    pw = result.get("pathway")
    if pw:
        tables["pathways"] = pw["table"]
        figs["pathways"] = F.pathway_bar(pw["table"])
        sec("10. Pathway analysis", [pw["statement"]], table="pathways", fig=["pathways"],
            text=f"{pw['test']}; gene sets: {pw['database']} {pw['database_release'] or ''}; "
                 f"background {pw['background_size']} measured genes.")
    else:
        sec("10. Pathway analysis", text="Not performed (no gene sets supplied or no significant features).")
    ext = result.get("external_validation")
    if ext:
        tables["external_validation"] = pd.DataFrame([{"algorithm": a, **{k: r.get(k) for k in
                                                       ("n", "roc_auc", "pr_auc", "balanced_accuracy", "brier")}}
                                                      for a, r in ext["models"].items()])
        sec("11. External validation", [ext["statement"]], table="external_validation",
            text=f"Independence checks: {ext['independence']}.")
    else:
        sec("11. External validation", text="NOT PERFORMED. Results reflect internal evaluation only and should "
            "not be generalised until tested on an independent dataset.")

    limits = [{"evidence_label": "INTERPRETATION", "statement": r["message"]} for r in (review or [])]
    limits.append({"evidence_label": "INTERPRETATION", "statement": DISCLAIMER})
    sec("12. Limitations", limits)
    sec("13. Reproducibility information", text=f"Config hash {prov['config_hash']}; input hashes "
        f"{prov['input_hashes']}; seed {prov['random_seed']}; code {prov['code_version']}; software "
        f"{prov['software_versions']}. Steps: " + " → ".join(prov["analysis_steps"]))
    sec("14. Evidence labels", [{"evidence_label": k, "statement": v} for k, v in EVIDENCE_LEGEND.items()])
    sec("15. Figures and tables", text=f"{len(figs)} figures and {len(tables)} tables generated from results.")
    sec("16. Machine-readable experiment configuration", text=json.dumps(prov["config"], indent=2, default=str))
    return {"title": project.get("name", "Research report"), "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            "platform": plat, "sections": S, "figures": figs, "tables": tables, "provenance": prov,
            "demo": bool(project.get("demo") or prov.get("config", {}).get("demo")), "disclaimer": DISCLAIMER}


# ------------------------------------------------------------------ exporters
def _items_html(items):
    out = []
    for it in items:
        lab = it["evidence_label"]
        assert lab in EVIDENCE_LABELS
        out.append(f'<li><span class="lab lab-{lab}">{lab}</span> {html.escape(it["statement"])}</li>')
    return f"<ul class='ev'>{''.join(out)}</ul>" if out else ""


def to_html(rep: dict) -> str:
    parts = []
    for s in rep["sections"]:
        body = f"<p>{html.escape(s['text'])}</p>" if s["text"] and not s["title"].startswith("16") else ""
        if s["title"].startswith("16"):
            body = f"<pre>{html.escape(s['text'])}</pre>"
        body += _items_html(s["items"])
        for k in (s["figure"] or []):
            body += f'<img alt="{k}" src="data:image/png;base64,{base64.b64encode(rep["figures"][k]).decode()}">'
        if s["table"]:
            body += "<div class='tw'>" + rep["tables"][s["table"]].head(30).to_html(index=False, float_format=lambda v: f"{v:.4g}", na_rep="—") + "</div>"
        parts.append(f"<section><h2>{html.escape(s['title'])}</h2>{body}</section>")
    banner = "<div class='demo'>DEMONSTRATION DATA: synthetic values, not biomedical evidence.</div>" if rep["demo"] else ""
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(rep['title'])}</title><style>
body{{font:15px/1.55 system-ui,sans-serif;color:#1B2140;max-width:900px;margin:0 auto;padding:24px}}
h1{{font-size:1.7rem}} h2{{font-size:1.15rem;border-bottom:1px solid #ddd;padding-bottom:4px;margin-top:28px}}
.demo{{background:#FFF2D6;color:#7A4E00;padding:10px 14px;border-radius:6px;font-weight:600}}
.ev{{list-style:none;padding:0}} .ev li{{margin:6px 0}} img{{max-width:100%;margin:8px 0}}
.lab{{display:inline-block;font-size:.72rem;font-weight:700;padding:2px 7px;border-radius:4px;background:#eef;margin-right:4px}}
.lab-STATISTICS{{background:#E3F1F0}} .lab-MODEL{{background:#E8E6F5}} .lab-EXPLANATION{{background:#FBE9D8}}
.lab-HYPOTHESIS{{background:#FBE1E5}} .lab-INTERPRETATION{{background:#EEE}}
.tw{{overflow-x:auto}} table{{border-collapse:collapse;font-size:.8rem}} td,th{{border-bottom:1px solid #e3e3e3;padding:4px 8px}}
pre{{background:#f6f6f8;padding:12px;overflow-x:auto;font-size:.8rem}}</style></head><body>
{banner}<h1>{html.escape(rep['title'])}</h1><p><small>Generated {rep['generated_at']} by BioAI Research Lab. {html.escape(rep['disclaimer'])}</small></p>
{''.join(parts)}</body></html>"""


def to_pdf(rep: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Image, Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle

    ss = getSampleStyleSheet()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm, title=rep["title"])
    flow = []
    if rep["demo"]:
        flow.append(Paragraph("<b>DEMONSTRATION DATA: synthetic values, not biomedical evidence.</b>", ss["Normal"]))
    flow += [Paragraph(html.escape(rep["title"]), ss["Title"]),
             Paragraph(html.escape(rep["disclaimer"]), ss["Italic"]), Spacer(1, 8)]
    for s in rep["sections"]:
        flow.append(Paragraph(html.escape(s["title"]), ss["Heading2"]))
        if s["text"]:
            if s["title"].startswith("16"):
                flow.append(Preformatted(s["text"][:4000], ss["Code"]))
            else:
                flow.append(Paragraph(html.escape(s["text"]), ss["BodyText"]))
        for it in s["items"]:
            flow.append(Paragraph(f"<b>[{it['evidence_label']}]</b> {html.escape(it['statement'])}", ss["BodyText"]))
        for k in (s["figure"] or []):
            img = Image(io.BytesIO(rep["figures"][k]))
            ratio = img.imageHeight / img.imageWidth
            img.drawWidth, img.drawHeight = 11 * cm, 11 * cm * ratio
            flow.append(img)
        if s["table"]:
            t = rep["tables"][s["table"]].head(15)
            t = t[[c for c in t.columns if t[c].map(lambda v: not isinstance(v, (list, dict))).all()]].iloc[:, :7]
            data = [list(map(str, t.columns))] + [[f"{v:.3g}" if isinstance(v, float) else str(v)[:28] for v in row]
                                                  for row in t.itertuples(index=False)]
            tb = Table(data, repeatRows=1)
            tb.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 6.5), ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8EAF2"))]))
            flow.append(tb)
        flow.append(Spacer(1, 6))
    doc.build(flow)
    return buf.getvalue()


def to_json(rep: dict, result: dict) -> str:
    payload = {"title": rep["title"], "generated_at": rep["generated_at"], "demo": rep["demo"],
               "disclaimer": rep["disclaimer"], "provenance": rep["provenance"],
               "findings": result["findings"],
               "sections": [{k: v for k, v in s.items() if k != "figure"} for s in rep["sections"]],
               "tables": {k: v.to_dict("records") for k, v in rep["tables"].items()}}
    return json.dumps(clean(payload), indent=2, default=str)


def to_csv_zip(rep: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, df in rep["tables"].items():
            z.writestr(f"{name}.csv", df.to_csv(index=False))
    return buf.getvalue()


def export_all(rep: dict, result: dict, out_dir: str | pathlib.Path, stem: str = "report") -> dict:
    out = pathlib.Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    files = {"html": out / f"{stem}.html", "pdf": out / f"{stem}.pdf", "json": out / f"{stem}.json",
             "csv": out / f"{stem}_tables.zip"}
    files["html"].write_text(to_html(rep), encoding="utf-8")
    files["pdf"].write_bytes(to_pdf(rep))
    files["json"].write_text(to_json(rep, result), encoding="utf-8")
    files["csv"].write_bytes(to_csv_zip(rep))
    for k, png in rep["figures"].items():
        (out / f"{stem}_fig_{k}.png").write_bytes(png)
    return {k: str(v) for k, v in files.items()}
