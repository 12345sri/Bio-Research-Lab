"""Figures rendered from actual results (matplotlib, headless)."""
from __future__ import annotations

import io

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import networkx as nx  # noqa: E402
import numpy as np  # noqa: E402

INK, RED, TEAL, GREY = "#1B2140", "#C1122F", "#0B7A78", "#9AA0B4"


def _png(fig) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    return buf.getvalue()


def _svg(fig) -> str:
    buf = io.StringIO()
    fig.savefig(buf, format="svg", bbox_inches="tight")
    plt.close(fig)
    return buf.getvalue()


def roc_curves(models: dict, fmt="png"):
    fig, ax = plt.subplots(figsize=(4.5, 4.2))
    for i, (algo, r) in enumerate(models.items()):
        c = r["test"].get("roc_curve")
        if c:
            ax.plot(c["fpr"], c["tpr"], label=f"{algo} (AUC {r['test']['roc_auc']:.2f})", lw=1.6)
    ax.plot([0, 1], [0, 1], "--", color=GREY, lw=1)
    ax.set(xlabel="False positive rate", ylabel="True positive rate", title="ROC curves (held-out test set)")
    ax.legend(fontsize=7, frameon=False)
    return _png(fig) if fmt == "png" else _svg(fig)


def calibration(models: dict):
    fig, ax = plt.subplots(figsize=(4.5, 4.2))
    for algo, r in models.items():
        c = r["test"].get("calibration")
        if c:
            ax.plot(c["mean_predicted"], c["observed_fraction"], "o-", label=algo, lw=1.4, ms=4)
    ax.plot([0, 1], [0, 1], "--", color=GREY, lw=1)
    ax.set(xlabel="Mean predicted probability", ylabel="Observed fraction", title="Calibration (test set)")
    ax.legend(fontsize=7, frameon=False)
    return _png(fig)


def importance_bar(ranking: list[dict], value_key: str, title: str):
    top = ranking[:15][::-1]
    fig, ax = plt.subplots(figsize=(5, 0.28 * len(top) + 1))
    ax.barh([r["feature"] for r in top], [r[value_key] for r in top], color=TEAL)
    ax.set(title=title, xlabel=value_key.replace("_", " "))
    ax.tick_params(labelsize=7)
    return _png(fig)


def paired_conditions(sessions, metric: str, a: str, b: str):
    wide = sessions.pivot_table(index="participant_code", columns="condition", values=metric).dropna()
    fig, ax = plt.subplots(figsize=(3.6, 4))
    for _, row in wide.iterrows():
        ax.plot([0, 1], [row[a], row[b]], color=GREY, lw=1)
    ax.plot([0, 1], [wide[a].median(), wide[b].median()], color=RED, lw=3, label="median")
    ax.set_xticks([0, 1], [a, b], fontsize=8)
    ax.set(title=metric, xlim=(-0.3, 1.3))
    ax.legend(fontsize=7, frameon=False)
    return _png(fig)


def network_plot(g: nx.Graph, hubs: list[str], seed: int = 0):
    fig, ax = plt.subplots(figsize=(5, 4.5))
    if g.number_of_nodes():
        pos = nx.spring_layout(g, seed=seed)
        nx.draw_networkx_edges(g, pos, ax=ax, alpha=0.4, edge_color=GREY)
        nx.draw_networkx_nodes(g, pos, ax=ax, node_size=[120 + 60 * g.degree(n) for n in g],
                               node_color=[RED if n in hubs else TEAL for n in g])
        label_pos = {n: (x, y - 0.09) for n, (x, y) in pos.items()}  # labels under nodes, not on top of them
        nx.draw_networkx_labels(g, label_pos, ax=ax, font_size=6)
        ax.margins(0.2)  # keep labels of edge nodes inside the figure
    ax.set_title("Correlation network (edges = co-variation, not regulation)", fontsize=9)
    ax.axis("off")
    return _png(fig)


def pathway_bar(table, top: int = 10):
    t = table.head(top).iloc[::-1]
    fig, ax = plt.subplots(figsize=(5, 0.3 * len(t) + 1))
    ax.barh(t["name"], -np.log10(t["p_adjusted"].clip(lower=1e-300)),
            color=[RED if s else GREY for s in t["significant"]])
    ax.set(xlabel="-log10 BH-adjusted p", title="Gene-set enrichment")
    ax.tick_params(labelsize=7)
    return _png(fig)
