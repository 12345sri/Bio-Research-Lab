"""Shared scientific primitives: evidence labels, findings, provenance."""
from __future__ import annotations

import hashlib
import importlib
import json
import math
import platform
from typing import Any

EVIDENCE_LABELS = ("DATA", "STATISTICS", "MODEL", "EXPLANATION", "LITERATURE", "INTERPRETATION", "HYPOTHESIS")
DISCLAIMER = ("Research output only. Not a diagnosis, not a prediction for an individual patient, "
              "and associations do not establish causation.")


class ScienceError(ValueError):
    """Raised when data or configuration cannot support a scientifically valid analysis."""


def finding(label: str, statement: str, **data: Any) -> dict:
    if label not in EVIDENCE_LABELS:
        raise ScienceError(f"Unknown evidence label: {label}")
    return {"evidence_label": label, "statement": statement, "data": clean(data)}


def clean(obj: Any) -> Any:
    """Make results JSON-safe: numpy scalars to Python, NaN/inf to None."""
    try:
        import numpy as np
    except ImportError:  # pragma: no cover
        np = None
    if hasattr(obj, "to_dict") and hasattr(obj, "columns"):  # pandas DataFrame -> list of row records
        return [clean(r) for r in obj.to_dict("records")]
    if hasattr(obj, "to_dict") and hasattr(obj, "index") and hasattr(obj, "dtype"):  # pandas Series -> {index: value}
        return {str(k): clean(v) for k, v in obj.to_dict().items()}
    if isinstance(obj, dict):
        return {str(k): clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if np is not None:
        if isinstance(obj, np.ndarray):
            return [clean(v) for v in obj.tolist()]
        if isinstance(obj, np.generic):
            obj = obj.item()
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj


def config_hash(config: dict) -> str:
    return hashlib.sha256(json.dumps(clean(config), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def data_hash(*frames) -> str:
    """Content hash of arrays/DataFrames, used to prove dataset independence."""
    h = hashlib.sha256()
    for f in frames:
        try:
            import pandas as pd
            if isinstance(f, (pd.DataFrame, pd.Series)):
                h.update(pd.util.hash_pandas_object(f, index=True).values.tobytes())
                continue
        except ImportError:  # pragma: no cover
            pass
        h.update(json.dumps(clean(f), sort_keys=True).encode())
    return h.hexdigest()


def software_versions() -> dict:
    versions = {"python": platform.python_version()}
    for mod in ("numpy", "scipy", "pandas", "sklearn", "networkx", "matplotlib", "xgboost", "shap"):
        try:
            versions[mod] = importlib.import_module(mod).__version__
        except ImportError:
            versions[mod] = None
    return versions


def provenance(config: dict, seed: int | None, steps: list[str], inputs: dict[str, str]) -> dict:
    return {
        "config": clean(config),
        "config_hash": config_hash(config),
        "random_seed": seed,
        "analysis_steps": steps,
        "input_hashes": inputs,
        "software_versions": software_versions(),
        "code_version": _code_version(),
    }


def _code_version() -> str:
    import os
    return os.environ.get("BIOAI_CODE_VERSION", "0.3.0-dev")
