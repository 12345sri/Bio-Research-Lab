"""Password hashing and tokens.

Passwords: scrypt (memory-hard, Python standard library) with a per-password random salt.
Tokens: short-lived JWT access tokens and longer-lived refresh tokens (HS256, secret from env).
One-time tokens (email verification, password reset): random, only their SHA-256 is stored.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import uuid
from datetime import datetime, timedelta, timezone

try:
    import jwt
except ImportError:  # local mode without PyJWT: equivalent HS256 implementation from the standard library
    from app.core import minijwt as jwt

SCRYPT_N, SCRYPT_R, SCRYPT_P, KEY_LEN = 2 ** 15, 8, 1, 32
MIN_PASSWORD_LENGTH = 12
ALGORITHM = "HS256"


class AuthError(Exception):
    """Authentication failed. The message is safe to return to the client."""


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def validate_password_strength(password: str, email: str | None = None) -> None:
    if len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"Password must be at least {MIN_PASSWORD_LENGTH} characters")
    if password.lower() == password or password.upper() == password:
        raise ValueError("Password must mix upper- and lower-case letters")
    if not any(c.isdigit() for c in password):
        raise ValueError("Password must contain a digit")
    if email and email.split("@")[0].lower() in password.lower():
        raise ValueError("Password must not contain your email name")


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P,
                        dklen=KEY_LEN, maxmem=64 * 1024 * 1024)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${_b64(salt)}${_b64(dk)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, n, r, p, salt, dk = stored.split("$")
        if algo != "scrypt":
            return False
        expected = _unb64(dk)
        got = hashlib.scrypt(password.encode(), salt=_unb64(salt), n=int(n), r=int(r), p=int(p),
                             dklen=len(expected), maxmem=64 * 1024 * 1024)
        return hmac.compare_digest(got, expected)
    except (ValueError, TypeError):
        return False


def needs_rehash(stored: str) -> bool:
    try:
        algo, n, r, p, *_ = stored.split("$")
        return algo != "scrypt" or (int(n), int(r), int(p)) != (SCRYPT_N, SCRYPT_R, SCRYPT_P)
    except ValueError:
        return True


def create_token(subject: str, token_type: str, secret: str, lifetime: timedelta, **claims) -> str:
    if token_type not in ("access", "refresh"):
        raise ValueError("token_type must be access or refresh")
    if not secret or len(secret) < 32:
        raise ValueError("SECRET_KEY must be at least 32 characters")
    now = datetime.now(timezone.utc)
    payload = {"sub": subject, "type": token_type, "iat": now, "nbf": now, "exp": now + lifetime,
               "jti": uuid.uuid4().hex, **claims}
    return jwt.encode(payload, secret, algorithm=ALGORITHM)


def decode_token(token: str, secret: str, expected_type: str) -> dict:
    try:
        payload = jwt.decode(token, secret, algorithms=[ALGORITHM],
                             options={"require": ["exp", "sub", "type", "iat", "jti"]})
    except jwt.ExpiredSignatureError as exc:
        raise AuthError("Token expired") from exc
    except jwt.PyJWTError as exc:
        raise AuthError("Invalid token") from exc
    if payload.get("type") != expected_type:
        raise AuthError("Wrong token type")
    return payload


def new_one_time_token() -> tuple[str, str]:
    """Returns (token sent to the user, SHA-256 hash stored in the database)."""
    token = secrets.token_urlsafe(32)
    return token, hashlib.sha256(token.encode()).hexdigest()


def hash_one_time_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()
