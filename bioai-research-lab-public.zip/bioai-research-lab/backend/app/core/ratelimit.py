"""Shared rate limiter (per client IP). RATE_LIMIT_ENABLED=false only for automated tests."""
import os

from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address, default_limits=["300/minute"],
                  enabled=os.environ.get("RATE_LIMIT_ENABLED", "true") == "true")
