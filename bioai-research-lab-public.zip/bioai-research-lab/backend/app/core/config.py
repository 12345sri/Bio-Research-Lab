"""Settings come only from environment variables. No secrets in source code."""
import os
from dataclasses import dataclass, field


def _require(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def _int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


@dataclass(frozen=True)
class Settings:
    environment: str = field(default_factory=lambda: os.environ.get("ENVIRONMENT", "development"))
    database_url: str = field(default_factory=lambda: _require("DATABASE_URL"))
    secret_key: str = field(default_factory=lambda: _require("SECRET_KEY"))
    redis_url: str = field(default_factory=lambda: os.environ.get("REDIS_URL", "redis://redis:6379/0"))
    s3_endpoint_url: str | None = field(default_factory=lambda: os.environ.get("S3_ENDPOINT_URL"))
    s3_access_key: str | None = field(default_factory=lambda: os.environ.get("S3_ACCESS_KEY"))
    s3_secret_key: str | None = field(default_factory=lambda: os.environ.get("S3_SECRET_KEY"))
    s3_bucket: str = field(default_factory=lambda: os.environ.get("S3_BUCKET", "bioai-datasets"))
    storage_backend: str = field(default_factory=lambda: os.environ.get("STORAGE_BACKEND", "s3"))
    local_storage_dir: str = field(default_factory=lambda: os.environ.get("LOCAL_STORAGE_DIR", "/tmp/bioai-storage"))
    pseudonym_secret: str = field(default_factory=lambda: os.environ.get("PSEUDONYM_SECRET", ""))
    access_token_minutes: int = field(default_factory=lambda: _int("ACCESS_TOKEN_MINUTES", 30))
    refresh_token_days: int = field(default_factory=lambda: _int("REFRESH_TOKEN_DAYS", 7))
    max_upload_mb: int = field(default_factory=lambda: _int("MAX_UPLOAD_MB", 200))
    run_tasks_inline: bool = field(default_factory=lambda: os.environ.get("RUN_TASKS_INLINE", "false") == "true")
    anthropic_api_key: str | None = field(default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY"))
    cors_origins: tuple = field(
        default_factory=lambda: tuple(o.strip() for o in os.environ.get("CORS_ORIGINS", "").split(",") if o.strip())
    )
    app_version: str = "0.3.0"
