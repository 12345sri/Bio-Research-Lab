"""Minimal HS256 JSON Web Tokens (subset of the PyJWT API used by app.core.security)."""
import base64
import hashlib
import hmac
import json
import time
from datetime import datetime


class PyJWTError(Exception):
    pass


class ExpiredSignatureError(PyJWTError):
    pass


def _b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _num(v):
    return int(v.timestamp()) if isinstance(v, datetime) else v


def encode(payload: dict, key: str, algorithm: str = "HS256") -> str:
    if algorithm != "HS256":
        raise PyJWTError("Only HS256 is supported")
    header = _b64e(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    body = _b64e(json.dumps({k: _num(v) for k, v in payload.items()}, separators=(",", ":")).encode())
    sig = _b64e(hmac.new(key.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
    return f"{header}.{body}.{sig}"


def decode(token: str, key: str, algorithms=None, options=None) -> dict:
    try:
        header, body, sig = token.split(".")
        if json.loads(_b64d(header)).get("alg") != "HS256" or "HS256" not in (algorithms or []):
            raise PyJWTError("Unsupported algorithm")
        expected = _b64e(hmac.new(key.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected):
            raise PyJWTError("Signature verification failed")
        payload = json.loads(_b64d(body))
    except PyJWTError:
        raise
    except Exception as exc:
        raise PyJWTError("Malformed token") from exc
    for claim in (options or {}).get("require", []):
        if claim not in payload:
            raise PyJWTError(f"Missing claim {claim}")
    now = time.time()
    if "exp" in payload and now >= payload["exp"]:
        raise ExpiredSignatureError("Token expired")
    if "nbf" in payload and now < payload["nbf"] - 5:
        raise PyJWTError("Token not yet valid")
    return payload
