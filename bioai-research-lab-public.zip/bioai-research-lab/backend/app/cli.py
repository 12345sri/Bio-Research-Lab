"""Administration commands.

    python -m app.cli seed                       # organization + roles (idempotent)
    python -m app.cli create-user EMAIL ROLE     # password read from BIOAI_NEW_PASSWORD env var
    python -m app.cli demo                       # DEMO project with synthetic data, run end to end
    python -m app.cli status                     # experiment counts by status

No users are created automatically: founders and the demo account are created explicitly.
"""
from __future__ import annotations

import io
import os
import sys
from datetime import datetime, timezone

from sqlalchemy import func, select

from app.core.security import hash_password, validate_password_strength
from app.db.session import session_factory
from app.models import Organization, Role
from app.models.enums import RoleName

ORG = {"name": "BioAI Research Lab", "slug": "bioai-research-lab",
       "mission": "Building explainable and reproducible AI infrastructure for biomedical research."}
ORG_LEVEL = {RoleName.ADMIN, RoleName.FOUNDER, RoleName.CO_FOUNDER}


def seed(db) -> Organization:
    org = db.scalar(select(Organization).where(Organization.slug == ORG["slug"]))
    if org is None:
        org = Organization(**ORG)
        db.add(org)
    for rn in RoleName:
        if db.scalar(select(Role).where(Role.name == rn)) is None:
            db.add(Role(name=rn, organization_level=rn in ORG_LEVEL))
    db.flush()
    return org


def create_user(db, email: str, role: str, password: str, display_name: str | None = None):
    from app.models import User
    validate_password_strength(password, email)
    org = seed(db)
    if db.scalar(select(User).where(func.lower(User.email) == email.lower())):
        raise SystemExit(f"User {email} already exists")
    r = db.scalar(select(Role).where(Role.name == RoleName(role)))
    u = User(email=email.lower(), password_hash=hash_password(password), display_name=display_name,
             organization_id=org.id, role_id=r.id, email_verified_at=datetime.now(timezone.utc))
    db.add(u); db.flush()
    return u


def demo(db, email: str, password: str):
    """Create a DEMONSTRATION project for `email` with synthetic datasets and run both workflows."""
    from app.models import Dataset, DatasetVersion, Experiment, Project, ProjectMember, User
    from app.models.enums import (ExperimentStatus, FileType, Platform, Privacy, ProjectRole, ValidationStatus)
    from app.science import demo_data as dd
    from app.science.common import _code_version
    from app.services.experiments import execute
    from app.services.storage import get_storage
    from app.services.uploads import validate_upload

    user = db.scalar(select(User).where(func.lower(User.email) == email.lower()))
    if user is None:
        user = create_user(db, email, "RESEARCHER", password, "Demo Researcher")
    name = "DEMO: BioAI workflow on synthetic data"
    if db.scalar(select(Project).where(Project.name == name, Project.organization_id == user.organization_id)):
        print("Demo project already exists"); return
    p = Project(organization_id=user.organization_id, name=name, principal_researcher_id=user.id,
                created_by_id=user.id, platform=Platform.GENERAL, privacy=Privacy.INTERNAL,
                research_question="DEMONSTRATION ONLY: synthetic data used to show the full workflow. "
                                  "Not biomedical evidence.")
    db.add(p); db.flush()
    db.add(ProjectMember(project_id=p.id, user_id=user.id, project_role=ProjectRole.OWNER))

    def upload(label: str, domain: Platform, csv_bytes: bytes, fname: str) -> DatasetVersion:
        info = validate_upload(fname, csv_bytes)
        d = Dataset(project_id=p.id, name=label, domain=domain, privacy=Privacy.INTERNAL, is_synthetic=True,
                    description="DEMONSTRATION DATA (synthetic)", created_by_id=user.id)
        db.add(d); db.flush()
        key = f"datasets/{p.id}/{d.id}/v1-{info.sha256[:12]}-{info.safe_filename}"
        get_storage().put(key, csv_bytes)
        v = DatasetVersion(dataset_id=d.id, version=1, storage_key=key, original_filename=info.safe_filename,
                           file_type=FileType(info.file_type), size_bytes=info.size_bytes, sha256=info.sha256,
                           n_rows=info.n_rows, n_columns=info.n_columns, column_schema=info.column_schema,
                           validation_status=ValidationStatus.PASSED,
                           validation_report={"warnings": info.warnings, "delimiter": info.delimiter,
                                              "columns": info.columns}, uploaded_by_id=user.id)
        db.add(v); db.flush()
        return v

    def csv(df, index=False) -> bytes:
        buf = io.StringIO(); df.to_csv(buf, index=index); return buf.getvalue().encode()

    rr = upload("DEMO RR intervals (normal vs exam day)", Platform.BIOSIGNAL, csv(dd.biosignal_demo(12)), "demo_rr.csv")
    expr, meta = dd.omics_demo()
    eexpr, emeta = dd.omics_demo(n_samples=100, seed=99, prefix="V")
    ev = upload("DEMO expression matrix", Platform.BIOOMICS, csv(expr.rename_axis("gene"), True), "demo_expr.csv")
    mv = upload("DEMO sample metadata", Platform.BIOOMICS, csv(meta), "demo_meta.csv")
    xv = upload("DEMO independent expression (external)", Platform.BIOOMICS,
                csv(eexpr.rename_axis("gene"), True), "demo_ext_expr.csv")
    xm = upload("DEMO independent metadata (external)", Platform.BIOOMICS, csv(emeta), "demo_ext_meta.csv")
    gs = upload("DEMO gene sets", Platform.BIOOMICS, dd.gene_sets_demo().encode(), "demo_gene_sets.txt")
    exps = [
        Experiment(project_id=p.id, dataset_version_id=rr.id, researcher_id=user.id, platform=Platform.BIOSIGNAL,
                   name="DEMO HRV: normal day vs exam day", analysis_type="hrv_workflow", random_seed=7,
                   code_version=_code_version(),
                   parameters={"demo": True, "random_seed": 7, "window_s": 60, "compare": ["NORMAL_DAY", "EXAM_DAY"],
                               "dataset_id": str(rr.id),
                               "ml": {"algorithms": ["LOGISTIC_REGRESSION", "RANDOM_FOREST", "XGBOOST"],
                                      "positive_class": "EXAM_DAY", "cv_folds": 3, "test_size": 0.25}}),
        Experiment(project_id=p.id, dataset_version_id=ev.id, researcher_id=user.id, platform=Platform.BIOOMICS,
                   name="DEMO omics: early vs late stage with external validation", analysis_type="omics_workflow",
                   random_seed=42, code_version=_code_version(),
                   parameters={"demo": True, "random_seed": 42, "metadata_version_id": str(mv.id),
                               "sample_column": "sample_id", "group_column": "stage", "positive_class": "LATE",
                               "negative_class": "EARLY", "network": {"threshold": 0.4},
                               "gene_sets_version_id": str(gs.id), "external_expression_version_id": str(xv.id),
                               "external_metadata_version_id": str(xm.id), "dataset_id": str(ev.id),
                               "external_dataset_id": str(xv.id),
                               "ml": {"algorithms": ["LOGISTIC_REGRESSION", "SVM", "RANDOM_FOREST", "XGBOOST"],
                                      "resampling": "SMOTE", "select_k_best": 30, "cv_folds": 5}}),
    ]
    for e in exps:
        e.status = ExperimentStatus.QUEUED
        db.add(e)
    db.commit()
    for e in exps:
        execute(db, e.id)
        print(f"{e.name}: {db.get(Experiment, e.id).status.value}")


def main(argv: list[str]) -> None:
    db = session_factory()()
    try:
        cmd = argv[1] if len(argv) > 1 else ""
        if cmd == "seed":
            seed(db); db.commit(); print("Seeded organization and roles")
        elif cmd == "create-user" and len(argv) >= 4:
            pw = os.environ.get("BIOAI_NEW_PASSWORD") or ""
            u = create_user(db, argv[2], argv[3].upper(), pw, argv[4] if len(argv) > 4 else None)
            db.commit(); print(f"Created {u.email} as {argv[3].upper()}")
        elif cmd == "demo":
            email = os.environ.get("DEMO_USER_EMAIL"); pw = os.environ.get("DEMO_USER_PASSWORD")
            if not email or not pw:
                raise SystemExit("Set DEMO_USER_EMAIL and DEMO_USER_PASSWORD")
            seed(db); db.commit(); demo(db, email, pw); db.commit()
        elif cmd == "status":
            from app.models import Experiment
            counts = dict(db.execute(select(Experiment.status, func.count()).group_by(Experiment.status)).all())
            print(" ".join(f"{k.value}={v}" for k, v in sorted(counts.items(), key=lambda kv: kv[0].value)) or "none")
        else:
            print(__doc__); raise SystemExit(2)
    finally:
        db.close()


if __name__ == "__main__":
    main(sys.argv)
