"""Engine and session factory. The URL comes from settings (environment only)."""
from functools import lru_cache

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import Settings


def make_engine(url: str | None = None):
    return create_engine(url or Settings().database_url, pool_pre_ping=True, future=True)


@lru_cache
def session_factory() -> sessionmaker:
    return sessionmaker(bind=make_engine(), autoflush=False, expire_on_commit=False)


def get_db():
    db: Session = session_factory()()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
