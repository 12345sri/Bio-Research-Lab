"""Request dependencies: current user from a Bearer token, and project-scoped authorization."""
from __future__ import annotations

import uuid
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.security import AuthError, decode_token
from app.db.session import get_db
from app.models import Project, ProjectMember, User
from app.services import audit
from app.services.permissions import can

bearer = HTTPBearer(auto_error=False)


def settings() -> Settings:
    return Settings()


def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db),
                 s: Settings = Depends(settings)) -> User:
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated",
                            headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = decode_token(creds.credentials, s.secret_key, "access")
    except AuthError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, str(exc), headers={"WWW-Authenticate": "Bearer"}) from exc
    user = db.get(User, uuid.UUID(payload["sub"]))
    if user is None or not user.is_active or user.deleted_at is not None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account not active")
    return user


@dataclass
class ProjectAccess:
    project: Project
    user: User
    project_role: str | None

    def require(self, action: str) -> None:
        ok = can(action, org_role=self.user.role.name.value, same_org=self.user.organization_id == self.project.organization_id,
                 project_role=self.project_role, project_privacy=self.project.privacy.value)
        if not ok:
            # 404 for projects the user cannot even read, so their existence is not disclosed.
            if not can("project.read", org_role=self.user.role.name.value,
                       same_org=self.user.organization_id == self.project.organization_id,
                       project_role=self.project_role, project_privacy=self.project.privacy.value):
                raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found")
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Your role does not allow '{action}' on this project")


def project_access(project_id: uuid.UUID, db: Session, user: User) -> ProjectAccess:
    project = db.get(Project, project_id)
    if project is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found")
    member = db.scalar(select(ProjectMember).where(ProjectMember.project_id == project_id,
                                                   ProjectMember.user_id == user.id))
    access = ProjectAccess(project, user, member.project_role.value if member else None)
    access.require("project.read")
    return access


def audit_request(db: Session, request: Request, user: User | None, action: str, resource_type: str,
                  resource_id=None, **details) -> None:
    audit.record(db, actor_id=user.id if user else None, organization_id=user.organization_id if user else None,
                 action=action, resource_type=resource_type, resource_id=resource_id,
                 ip=request.client.host if request.client else None,
                 user_agent=request.headers.get("user-agent"), **details)
