"""Authentication: register, verify email, login, refresh, password reset, profile."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import audit_request, current_user, settings
from app.core.config import Settings
from app.core.ratelimit import limiter
from app.core.security import (AuthError, create_token, decode_token, hash_one_time_token, hash_password,
                               needs_rehash, new_one_time_token, validate_password_strength, verify_password)
from app.db.session import get_db
from app.models import Organization, Role, User, UserToken
from app.models.enums import RoleName

router = APIRouter(prefix="/auth", tags=["auth"])
DEFAULT_ORG_SLUG = "bioai-research-lab"


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12, max_length=256)
    display_name: str | None = Field(default=None, max_length=200)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=256)


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshIn(BaseModel):
    refresh_token: str


class TokenIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)


class ResetRequestIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)
    new_password: str = Field(min_length=12, max_length=256)


class UserOut(BaseModel):
    id: uuid.UUID
    email: str
    display_name: str | None
    role: str
    organization_id: uuid.UUID | None
    email_verified: bool
    is_demo: bool = False


def user_out(u: User) -> UserOut:
    import os
    return UserOut(id=u.id, email=u.email, display_name=u.display_name, role=u.role.name.value,
                   organization_id=u.organization_id, email_verified=u.email_verified_at is not None,
                   is_demo=u.email.lower() == (os.environ.get("DEMO_USER_EMAIL") or "").lower())


def _issue(db: Session, user: User, purpose: str, hours: int) -> str:
    token, digest = new_one_time_token()
    db.add(UserToken(user_id=user.id, purpose=purpose, token_hash=digest,
                     expires_at=datetime.now(timezone.utc) + timedelta(hours=hours)))
    return token


def _consume(db: Session, token: str, purpose: str) -> User:
    row = db.scalar(select(UserToken).where(UserToken.token_hash == hash_one_time_token(token),
                                            UserToken.purpose == purpose))
    now = datetime.now(timezone.utc)
    if row is None or row.used_at is not None or row.expires_at < now:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid or expired token")
    row.used_at = now
    return db.get(User, row.user_id)


def _tokens(user: User, s: Settings) -> TokenOut:
    return TokenOut(
        access_token=create_token(str(user.id), "access", s.secret_key, timedelta(minutes=s.access_token_minutes),
                                  role=user.role.name.value),
        refresh_token=create_token(str(user.id), "refresh", s.secret_key, timedelta(days=s.refresh_token_days)))


@router.post("/register", status_code=201, summary="Create a researcher account")
@limiter.limit("10/minute")
def register(body: RegisterIn, request: Request, db: Session = Depends(get_db), s: Settings = Depends(settings)):
    try:
        validate_password_strength(body.password, body.email)
    except ValueError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    if db.scalar(select(User).where(func.lower(User.email) == body.email.lower())):
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")
    org = db.scalar(select(Organization).where(Organization.slug == DEFAULT_ORG_SLUG))
    role = db.scalar(select(Role).where(Role.name == RoleName.RESEARCHER))
    if org is None or role is None:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Platform not initialised; run the seed command")
    user = User(email=body.email.lower(), password_hash=hash_password(body.password),
                display_name=body.display_name, organization_id=org.id, role_id=role.id)
    db.add(user); db.flush()
    token = _issue(db, user, "VERIFY_EMAIL", 48)
    audit_request(db, request, user, "user.register", "user", user.id)
    out = {"user": user_out(user).model_dump(mode="json"),
           "message": "Account created. Verify your email before signing in."}
    # No mail server is configured in local development, so the token is returned directly there only.
    if s.environment == "development":
        out["verification_token"] = token
    return out


@router.post("/verify-email", summary="Confirm an email address")
def verify_email(body: TokenIn, request: Request, db: Session = Depends(get_db)):
    user = _consume(db, body.token, "VERIFY_EMAIL")
    user.email_verified_at = datetime.now(timezone.utc)
    audit_request(db, request, user, "user.verify_email", "user", user.id)
    return {"verified": True}


@router.post("/login", response_model=TokenOut, summary="Sign in with email and password")
@limiter.limit("10/minute")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db), s: Settings = Depends(settings)):
    user = db.scalar(select(User).where(func.lower(User.email) == body.email.lower()))
    if user is None or not verify_password(body.password, user.password_hash) or not user.is_active \
            or user.deleted_at is not None:
        audit_request(db, request, None, "user.login_failed", "user")
        db.commit()  # keep the failed-login audit entry even though the request fails
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")
    if user.email_verified_at is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Verify your email before signing in")
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(body.password)
    user.last_login_at = datetime.now(timezone.utc)
    audit_request(db, request, user, "user.login", "user", user.id)
    return _tokens(user, s)


@router.post("/demo-login", response_model=TokenOut, summary="Sign in to the public demo account (synthetic data)")
def demo_login(request: Request, db: Session = Depends(get_db), s: Settings = Depends(settings)):
    import os
    email = os.environ.get("DEMO_USER_EMAIL")
    if os.environ.get("LOAD_DEMO", "false") != "true" or not email:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Demo mode is disabled")
    user = db.scalar(select(User).where(func.lower(User.email) == email.lower()))
    if user is None:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE, "Demo is still being prepared; try again in a moment")
    audit_request(db, request, user, "user.demo_login", "user", user.id)
    return _tokens(user, s)


@router.post("/refresh", response_model=TokenOut, summary="Exchange a refresh token for new tokens")
def refresh(body: RefreshIn, db: Session = Depends(get_db), s: Settings = Depends(settings)):
    try:
        payload = decode_token(body.refresh_token, s.secret_key, "refresh")
    except AuthError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, str(exc)) from exc
    user = db.get(User, uuid.UUID(payload["sub"]))
    if user is None or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account not active")
    return _tokens(user, s)


@router.post("/password-reset/request", status_code=202, summary="Request a password reset")
@limiter.limit("10/minute")
def request_reset(body: ResetRequestIn, request: Request, db: Session = Depends(get_db),
                  s: Settings = Depends(settings)):
    user = db.scalar(select(User).where(func.lower(User.email) == body.email.lower()))
    out = {"message": "If the account exists, a reset link has been issued."}  # no account enumeration
    if user is not None:
        token = _issue(db, user, "RESET_PASSWORD", 1)
        audit_request(db, request, user, "user.password_reset_requested", "user", user.id)
        if s.environment == "development":
            out["reset_token"] = token
    return out


@router.post("/password-reset/confirm", summary="Set a new password with a reset token")
def confirm_reset(body: ResetIn, request: Request, db: Session = Depends(get_db)):
    user = _consume(db, body.token, "RESET_PASSWORD")
    try:
        validate_password_strength(body.new_password, user.email)
    except ValueError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    user.password_hash = hash_password(body.new_password)
    audit_request(db, request, user, "user.password_reset", "user", user.id)
    return {"reset": True}


class ProfileIn(BaseModel):
    display_name: str | None = Field(default=None, max_length=200)


@router.get("/me", response_model=UserOut, summary="Current researcher profile")
def me(user: User = Depends(current_user)):
    return user_out(user)


@router.patch("/me", response_model=UserOut, summary="Update your profile")
def update_me(body: ProfileIn, user: User = Depends(current_user)):
    user.display_name = body.display_name
    return user_out(user)
