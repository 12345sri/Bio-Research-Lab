"""Datasets and immutable versions. Files go to object storage after validation."""
from __future__ import annotations

import io
import uuid
from datetime import datetime, timezone

import pandas as pd
from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import Response
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import audit_request, current_user, project_access, settings
from app.core.config import Settings
from app.db.session import get_db
from app.models import Dataset, DatasetVersion, User
from app.models.enums import FileType, Platform, Privacy, RecordStatus, ValidationStatus
from app.services.storage import get_storage
from app.services.uploads import UploadRejected, validate_upload

router = APIRouter(tags=["datasets"])


def version_out(v: DatasetVersion) -> dict:
    return {"id": str(v.id), "version": v.version, "file_type": v.file_type.value, "size_bytes": v.size_bytes,
            "sha256": v.sha256, "n_rows": v.n_rows, "n_columns": v.n_columns, "columns": v.column_schema,
            "validation_status": v.validation_status.value, "validation_report": v.validation_report,
            "original_filename": v.original_filename, "change_note": v.change_note, "created_at": v.created_at}


def dataset_out(d: Dataset, versions: list[DatasetVersion]) -> dict:
    return {"id": str(d.id), "project_id": str(d.project_id), "name": d.name, "description": d.description,
            "domain": d.domain.value, "privacy": d.privacy.value, "status": d.status.value,
            "is_synthetic": d.is_synthetic, "created_at": d.created_at,
            "versions": [version_out(v) for v in versions]}


async def _read_limited(file: UploadFile, limit: int) -> bytes:
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, f"File exceeds the {limit // 1_000_000} MB limit")
    return data


def _store_version(db: Session, dataset: Dataset, filename: str, data: bytes, user: User, s: Settings,
                   note: str | None) -> DatasetVersion:
    try:
        info = validate_upload(filename, data, max_bytes=s.max_upload_mb * 1_000_000)
    except UploadRejected as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    last = db.scalar(select(func.max(DatasetVersion.version)).where(DatasetVersion.dataset_id == dataset.id)) or 0
    key = f"datasets/{dataset.project_id}/{dataset.id}/v{last + 1}-{info.sha256[:12]}-{info.safe_filename}"
    get_storage().put(key, data, "text/plain")
    v = DatasetVersion(dataset_id=dataset.id, version=last + 1, storage_key=key, original_filename=info.safe_filename,
                       file_type=FileType(info.file_type), size_bytes=info.size_bytes, sha256=info.sha256,
                       n_rows=info.n_rows, n_columns=info.n_columns, column_schema=info.column_schema,
                       validation_status=ValidationStatus.PASSED_WITH_WARNINGS if info.warnings
                       else ValidationStatus.PASSED,
                       validation_report={"warnings": info.warnings, "delimiter": info.delimiter,
                                          "columns": info.columns},
                       change_note=note, uploaded_by_id=user.id)
    db.add(v); db.flush()
    return v


@router.post("/projects/{project_id}/datasets", status_code=201, summary="Upload a new dataset (version 1)")
async def upload_dataset(project_id: uuid.UUID, request: Request, name: str = Form(..., min_length=2, max_length=300),
                         domain: Platform = Form(...), privacy: Privacy = Form(Privacy.INTERNAL),
                         description: str | None = Form(None), is_synthetic: bool = Form(False),
                         file: UploadFile = File(...), db: Session = Depends(get_db),
                         user: User = Depends(current_user), s: Settings = Depends(settings)):
    project_access(project_id, db, user).require("dataset.upload")
    data = await _read_limited(file, s.max_upload_mb * 1_000_000)
    d = Dataset(project_id=project_id, name=name, description=description, domain=domain, privacy=privacy,
                is_synthetic=is_synthetic, created_by_id=user.id)
    db.add(d)
    try:
        db.flush()
    except IntegrityError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, "A dataset with this name exists; upload a new version") from exc
    v = _store_version(db, d, file.filename or "upload.csv", data, user, s, "Initial upload")
    audit_request(db, request, user, "dataset.upload", "dataset_version", v.id, project_id=project_id,
                  dataset_id=d.id, version=v.version, sha256=v.sha256)
    return dataset_out(d, [v])


@router.post("/projects/{project_id}/datasets/{dataset_id}/versions", status_code=201,
             summary="Upload a new immutable version of a dataset")
async def upload_version(project_id: uuid.UUID, dataset_id: uuid.UUID, request: Request,
                         change_note: str = Form(..., min_length=3), file: UploadFile = File(...),
                         db: Session = Depends(get_db), user: User = Depends(current_user),
                         s: Settings = Depends(settings)):
    project_access(project_id, db, user).require("dataset.upload")
    d = db.get(Dataset, dataset_id)
    if d is None or d.project_id != project_id or d.status != RecordStatus.ACTIVE:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dataset not found")
    data = await _read_limited(file, s.max_upload_mb * 1_000_000)
    v = _store_version(db, d, file.filename or "upload.csv", data, user, s, change_note)
    audit_request(db, request, user, "dataset.version", "dataset_version", v.id, project_id=project_id,
                  dataset_id=d.id, version=v.version, sha256=v.sha256)
    return version_out(v)


@router.get("/projects/{project_id}/datasets", summary="Datasets and their versions")
def list_datasets(project_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(current_user)):
    project_access(project_id, db, user).require("dataset.read")
    out = []
    for d in db.scalars(select(Dataset).where(Dataset.project_id == project_id, Dataset.status != RecordStatus.DELETED)
                        .order_by(Dataset.created_at)):
        out.append(dataset_out(d, db.scalars(select(DatasetVersion).where(DatasetVersion.dataset_id == d.id)
                                             .order_by(DatasetVersion.version)).all()))
    return out


def _version(db: Session, project_id: uuid.UUID, version_id: uuid.UUID) -> DatasetVersion:
    v = db.get(DatasetVersion, version_id)
    if v is None or v.dataset.project_id != project_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dataset version not found")
    return v


@router.get("/projects/{project_id}/dataset-versions/{version_id}/preview", summary="First rows of a dataset version")
def preview(project_id: uuid.UUID, version_id: uuid.UUID, rows: int = 20, db: Session = Depends(get_db),
            user: User = Depends(current_user)):
    project_access(project_id, db, user).require("dataset.read")
    v = _version(db, project_id, version_id)
    df = read_version(v, nrows=min(max(rows, 1), 200))
    return {"columns": list(map(str, df.columns)), "rows": df.astype(object).where(df.notna(), None).values.tolist(),
            "total_rows": v.n_rows}


@router.get("/projects/{project_id}/dataset-versions/{version_id}/download", summary="Download the original file")
def download(project_id: uuid.UUID, version_id: uuid.UUID, request: Request, db: Session = Depends(get_db),
             user: User = Depends(current_user)):
    project_access(project_id, db, user).require("dataset.download")
    v = _version(db, project_id, version_id)
    audit_request(db, request, user, "dataset.download", "dataset_version", v.id, project_id=project_id)
    return Response(get_storage().get(v.storage_key), media_type="text/plain",
                    headers={"Content-Disposition": f'attachment; filename="{v.original_filename}"'})


@router.post("/projects/{project_id}/datasets/{dataset_id}/archive", summary="Archive a dataset (never hard-deleted)")
def archive(project_id: uuid.UUID, dataset_id: uuid.UUID, request: Request, db: Session = Depends(get_db),
            user: User = Depends(current_user)):
    project_access(project_id, db, user).require("dataset.archive")
    d = db.get(Dataset, dataset_id)
    if d is None or d.project_id != project_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Dataset not found")
    d.status, d.archived_at = RecordStatus.ARCHIVED, datetime.now(timezone.utc)
    audit_request(db, request, user, "dataset.archive", "dataset", d.id, project_id=project_id)
    return {"archived": True}


def read_version(v: DatasetVersion, nrows: int | None = None) -> pd.DataFrame:
    raw = get_storage().get(v.storage_key)
    sep = {"CSV": ",", "TSV": "\t"}.get(v.file_type.value) or (v.validation_report or {}).get("delimiter")
    if sep is None:  # single-column text file (e.g. one RR interval per line)
        cols = (v.validation_report or {}).get("columns") or ["column_1"]
        has_header = cols[0] != "column_1"
        return pd.read_csv(io.BytesIO(raw), header=0 if has_header else None,
                           names=None if has_header else ["column_1"], nrows=nrows)
    return pd.read_csv(io.BytesIO(raw), sep=sep, nrows=nrows)
