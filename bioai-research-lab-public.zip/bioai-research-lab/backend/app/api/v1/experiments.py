"""Experiments: configure, run in the background, poll, inspect results, clone, re-run, download reports."""
from __future__ import annotations

import uuid
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import Response
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import audit_request, current_user, project_access, settings
from app.core.config import Settings
from app.db.session import get_db
from app.models import DatasetVersion, Experiment, ExperimentResult, Report, User
from app.models.enums import ExperimentStatus, Platform
from app.science.common import _code_version
from app.science.copilot import copilot
from app.services.storage import get_storage
from app.workers.tasks import dispatch

router = APIRouter(tags=["experiments"])
ALGORITHMS = Literal["LOGISTIC_REGRESSION", "SVM", "RANDOM_FOREST", "XGBOOST"]


class MLConfig(BaseModel, extra="forbid"):
    algorithms: list[ALGORITHMS] = Field(default_factory=lambda: ["LOGISTIC_REGRESSION", "RANDOM_FOREST"], min_length=1)
    positive_class: str | None = None
    resampling: Literal["NONE", "CLASS_WEIGHT", "SMOTE"] = "NONE"
    cv_folds: int = Field(5, ge=2, le=20)
    test_size: float = Field(0.2, gt=0.05, lt=0.5)
    select_k_best: int | None = Field(default=None, ge=1)
    params: dict[str, dict] = Field(default_factory=dict)


class QCConfig(BaseModel, extra="forbid"):
    min_rr: float = Field(300.0, ge=200, le=1000)
    max_rr: float = Field(2000.0, ge=1000, le=3000)
    max_rel_change: float = Field(0.2, gt=0, le=1)
    local_window: int = Field(5, ge=3, le=51)


class FrequencyConfig(BaseModel, extra="forbid"):
    # 120 s is the floor: LF (0.04 Hz) needs several cycles; the engine refuses shorter windows anyway.
    min_duration_s: float = Field(120.0, ge=120)
    max_excluded_fraction: float = Field(0.05, ge=0, le=0.5)
    fs_interp: float = Field(4.0, ge=2, le=10)


class PreprocessConfig(BaseModel, extra="forbid"):
    max_missing: float = Field(0.2, ge=0, le=1)
    log2_transform: bool = False
    drop_zero_variance: bool = True
    duplicate_policy: Literal["mean", "error"] = "mean"


class NetworkConfig(BaseModel, extra="forbid"):
    method: Literal["spearman", "pearson"] = "spearman"
    threshold: float = Field(0.5, gt=0, lt=1)
    alpha: float = Field(0.05, gt=0, le=0.2)
    hub_quantile: float = Field(0.9, gt=0, lt=1)


class ExperimentIn(BaseModel, extra="forbid"):
    name: str = Field(min_length=3, max_length=300)
    platform: Literal["BIOSIGNAL", "BIOOMICS"]
    dataset_version_id: uuid.UUID
    random_seed: int = Field(42, ge=0, le=2 ** 31 - 1)
    # BIOSIGNAL: long table with participant_id, session_id, condition, rr_ms
    compare: list[str] | None = Field(default=None, min_length=2, max_length=2)
    window_s: int | None = Field(default=None, ge=30)
    qc: QCConfig = Field(default_factory=QCConfig)
    frequency: FrequencyConfig = Field(default_factory=FrequencyConfig)
    # BIOOMICS: expression matrix (first column = gene/sample id) + metadata
    metadata_version_id: uuid.UUID | None = None
    sample_column: str = "sample_id"
    group_column: str | None = None
    positive_class: str | None = None
    negative_class: str | None = None
    orientation: Literal["GENES_AS_ROWS", "SAMPLES_AS_ROWS"] | None = None
    preprocess: PreprocessConfig = Field(default_factory=PreprocessConfig)
    network: NetworkConfig = Field(default_factory=NetworkConfig)
    gene_sets_version_id: uuid.UUID | None = None
    external_expression_version_id: uuid.UUID | None = None
    external_metadata_version_id: uuid.UUID | None = None
    extra_layers: dict[str, uuid.UUID] = Field(default_factory=dict)
    ml: MLConfig | None = None
    demo: bool = False

    @model_validator(mode="after")
    def check(self):
        if self.platform == "BIOOMICS":
            missing = [f for f in ("metadata_version_id", "group_column", "positive_class", "negative_class")
                       if getattr(self, f) is None]
            if missing:
                raise ValueError(f"Omics experiments need: {', '.join(missing)}")
            if self.ml is None:
                self.ml = MLConfig()  # the omics workflow always trains and evaluates models
        if self.platform == "BIOSIGNAL" and self.ml is not None and not self.ml.positive_class:
            raise ValueError("Biosignal machine learning needs ml.positive_class (the condition to predict)")
        if bool(self.external_expression_version_id) != bool(self.external_metadata_version_id):
            raise ValueError("External validation needs both an expression and a metadata dataset version")
        return self


def _check_versions(db: Session, project_id: uuid.UUID, body: ExperimentIn) -> None:
    ids = {"dataset_version_id": body.dataset_version_id, "metadata_version_id": body.metadata_version_id,
           "gene_sets_version_id": body.gene_sets_version_id,
           "external_expression_version_id": body.external_expression_version_id,
           "external_metadata_version_id": body.external_metadata_version_id,
           **{f"layer:{k}": v for k, v in body.extra_layers.items()}}
    versions = {}
    for field, vid in ids.items():
        if vid is None:
            continue
        v = db.get(DatasetVersion, vid)
        if v is None or v.dataset.project_id != project_id:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"{field}: dataset version not in this project")
        versions[field] = v
    # External validation data must come from datasets never used for training (service-layer rule).
    training = {versions[f].dataset_id for f in versions if f in ("dataset_version_id", "metadata_version_id")
                or f.startswith("layer:")}
    for f in ("external_expression_version_id", "external_metadata_version_id"):
        if f in versions and versions[f].dataset_id in training:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY,
                                "External validation must use a dataset that is not part of training "
                                "(a different version of a training dataset is not independent)")


def exp_out(e: Experiment) -> dict:
    return {"id": str(e.id), "project_id": str(e.project_id), "name": e.name, "platform": e.platform.value,
            "analysis_type": e.analysis_type, "status": e.status.value, "dataset_version_id": str(e.dataset_version_id),
            "parameters": e.parameters, "random_seed": e.random_seed, "code_version": e.code_version,
            "software_versions": e.software_versions, "parent_experiment_id":
            str(e.parent_experiment_id) if e.parent_experiment_id else None, "error_message": e.error_message,
            "created_at": e.created_at, "started_at": e.started_at, "finished_at": e.finished_at}


def _pipeline_config(body: ExperimentIn, project_id: uuid.UUID) -> dict:
    cfg = body.model_dump(mode="json", exclude={"name", "platform", "dataset_version_id"}, exclude_none=True)
    cfg["dataset_id"] = str(body.dataset_version_id)
    if body.external_expression_version_id:
        cfg["external_dataset_id"] = str(body.external_expression_version_id)
    return cfg


@router.post("/projects/{project_id}/experiments", status_code=201, summary="Create an experiment (not yet run)")
def create_experiment(project_id: uuid.UUID, body: ExperimentIn, request: Request, db: Session = Depends(get_db),
                      user: User = Depends(current_user)):
    project_access(project_id, db, user).require("experiment.run")
    _check_versions(db, project_id, body)
    e = Experiment(project_id=project_id, dataset_version_id=body.dataset_version_id, researcher_id=user.id,
                   name=body.name, platform=Platform(body.platform),
                   analysis_type="hrv_workflow" if body.platform == "BIOSIGNAL" else "omics_workflow",
                   parameters=_pipeline_config(body, project_id),
                   preprocessing=(body.preprocess if body.platform == "BIOOMICS" else body.qc).model_dump(),
                   feature_selection={"select_k_best": body.ml.select_k_best} if body.ml else {},
                   random_seed=body.random_seed, code_version=_code_version())
    db.add(e); db.flush()
    audit_request(db, request, user, "experiment.create", "experiment", e.id, project_id=project_id,
                  dataset_version_id=body.dataset_version_id)
    return exp_out(e)


def _get(db: Session, project_id: uuid.UUID, experiment_id: uuid.UUID) -> Experiment:
    e = db.get(Experiment, experiment_id)
    if e is None or e.project_id != project_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Experiment not found")
    return e


@router.post("/projects/{project_id}/experiments/{experiment_id}/run", status_code=202,
             summary="Queue the experiment on the background worker")
def run(project_id: uuid.UUID, experiment_id: uuid.UUID, request: Request, db: Session = Depends(get_db),
        user: User = Depends(current_user), s: Settings = Depends(settings)):
    project_access(project_id, db, user).require("experiment.run")
    e = _get(db, project_id, experiment_id)
    if e.status in (ExperimentStatus.QUEUED, ExperimentStatus.RUNNING):
        raise HTTPException(status.HTTP_409_CONFLICT, "Experiment is already queued or running")
    if e.status == ExperimentStatus.SUCCEEDED:
        raise HTTPException(status.HTTP_409_CONFLICT, "Results are immutable; clone the experiment to re-run it")
    e.status, e.error_message = ExperimentStatus.QUEUED, None
    audit_request(db, request, user, "experiment.run", "experiment", e.id, project_id=project_id,
                  dataset_version_id=e.dataset_version_id)
    db.commit()  # the worker must see the QUEUED row
    e.job_id = dispatch(e.id, s.run_tasks_inline)
    db.refresh(e)
    return exp_out(e)


class CloneIn(BaseModel, extra="forbid"):
    name: str | None = Field(default=None, min_length=3, max_length=300)
    random_seed: int | None = Field(default=None, ge=0, le=2 ** 31 - 1)


@router.post("/projects/{project_id}/experiments/{experiment_id}/clone", status_code=201,
             summary="Copy an experiment's exact configuration to re-run it (optionally with a new seed)")
def clone(project_id: uuid.UUID, experiment_id: uuid.UUID, request: Request, body: CloneIn | None = None,
          db: Session = Depends(get_db), user: User = Depends(current_user)):
    project_access(project_id, db, user).require("experiment.clone")
    src = _get(db, project_id, experiment_id)
    body = body or CloneIn()
    seed = src.random_seed if body.random_seed is None else body.random_seed
    params = {**src.parameters, "random_seed": seed}  # dataset versions and settings are copied unchanged
    e = Experiment(project_id=project_id, dataset_version_id=src.dataset_version_id, researcher_id=user.id,
                   parent_experiment_id=src.id, name=(body.name or f"{src.name} (re-run)")[:300],
                   platform=src.platform, analysis_type=src.analysis_type, parameters=params,
                   preprocessing=src.preprocessing, feature_selection=src.feature_selection,
                   random_seed=seed, code_version=_code_version())
    db.add(e); db.flush()
    audit_request(db, request, user, "experiment.clone", "experiment", e.id, project_id=project_id, source=src.id)
    return exp_out(e)


@router.get("/projects/{project_id}/experiments", summary="Experiment history")
def list_experiments(project_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(current_user)):
    project_access(project_id, db, user).require("experiment.read")
    return [exp_out(e) for e in db.scalars(select(Experiment).where(Experiment.project_id == project_id)
                                           .order_by(Experiment.created_at.desc()))]


@router.get("/projects/{project_id}/experiments/{experiment_id}", summary="Experiment status and configuration")
def get_experiment(project_id: uuid.UUID, experiment_id: uuid.UUID, db: Session = Depends(get_db),
                   user: User = Depends(current_user)):
    project_access(project_id, db, user).require("experiment.read")
    return exp_out(_get(db, project_id, experiment_id))


def _results(db: Session, e: Experiment) -> dict:
    rows = {r.result_type: r.payload for r in db.scalars(select(ExperimentResult)
                                                          .where(ExperimentResult.experiment_id == e.id))}
    if "pipeline_result" not in rows:
        raise HTTPException(status.HTTP_409_CONFLICT, f"No results yet (status {e.status.value})")
    return rows


@router.get("/projects/{project_id}/experiments/{experiment_id}/results",
            summary="Full labelled results (statistics, models, explanations, network, pathways, validation)")
def results(project_id: uuid.UUID, experiment_id: uuid.UUID, db: Session = Depends(get_db),
            user: User = Depends(current_user)):
    project_access(project_id, db, user).require("experiment.read")
    e = _get(db, project_id, experiment_id)
    rows = _results(db, e)
    report = db.scalar(select(Report).where(Report.experiment_id == e.id))
    return {"experiment": exp_out(e), "result": rows["pipeline_result"],
            "review": rows.get("review", {}).get("issues", []),
            "report": {"id": str(report.id), "title": report.title, "formats": sorted(report.exports)} if report else None}


MEDIA = {"html": "text/html", "pdf": "application/pdf", "json": "application/json", "csv": "application/zip"}


@router.get("/projects/{project_id}/experiments/{experiment_id}/report.{fmt}", summary="Download the report")
def report_file(project_id: uuid.UUID, experiment_id: uuid.UUID, fmt: str, request: Request,
                db: Session = Depends(get_db), user: User = Depends(current_user)):
    project_access(project_id, db, user).require("report.read")
    report = db.scalar(select(Report).where(Report.experiment_id == experiment_id, Report.project_id == project_id))
    if report is None or fmt not in report.exports:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Report format not available")
    audit_request(db, request, user, "report.download", "report", report.id, project_id=project_id, format=fmt)
    ext = "zip" if fmt == "csv" else fmt
    disposition = "inline" if fmt == "html" else "attachment"
    return Response(get_storage().get(report.exports[fmt]), media_type=MEDIA[fmt],
                    headers={"Content-Disposition": f'{disposition}; filename="report-{experiment_id}.{ext}"'})


@router.get("/projects/{project_id}/experiments/{experiment_id}/figures/{name}", summary="A report figure (PNG)")
def figure(project_id: uuid.UUID, experiment_id: uuid.UUID, name: str, db: Session = Depends(get_db),
           user: User = Depends(current_user)):
    project_access(project_id, db, user).require("report.read")
    report = db.scalar(select(Report).where(Report.experiment_id == experiment_id, Report.project_id == project_id))
    key = (report.exports if report else {}).get(f"figure:{name}")
    if key is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Figure not found")
    return Response(get_storage().get(key), media_type="image/png")


class CopilotIn(BaseModel):
    question: str = Field(min_length=3, max_length=2000)


@router.post("/projects/{project_id}/experiments/{experiment_id}/copilot",
             summary="Ask the research copilot about this experiment (answers only from recorded evidence)")
def ask_copilot(project_id: uuid.UUID, experiment_id: uuid.UUID, body: CopilotIn, request: Request,
                db: Session = Depends(get_db), user: User = Depends(current_user), s: Settings = Depends(settings)):
    project_access(project_id, db, user).require("experiment.read")
    e = _get(db, project_id, experiment_id)
    result = _results(db, e)["pipeline_result"]
    if s.anthropic_api_key:
        out = copilot.answer(body.question, result)
        out.update(evidence=copilot.evidence(result), review=copilot.review(result), mode="language_model")
    else:
        out = {"mode": "evidence_only", "answer": None,
               "note": "No ANTHROPIC_API_KEY configured; showing the recorded evidence and automated review only.",
               "evidence": copilot.evidence(result), "review": copilot.review(result)}
    audit_request(db, request, user, "copilot.ask", "experiment", e.id, project_id=project_id)
    return out
