"""Projects, membership, teams, tasks, comments and the project audit trail."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import audit_request, current_user, project_access
from app.db.session import get_db
from app.models import AuditLog, Comment, Project, ProjectMember, Task, Team, TeamMember, User
from app.models.enums import (CommentTarget, Contribution, Discipline, Platform, Privacy, ProjectRole,
                              ProjectStatus, TaskStatus)
from app.services.permissions import ORG_LEVEL_ROLES, can_create_project

router = APIRouter(tags=["projects"])


class ProjectIn(BaseModel):
    name: str = Field(min_length=3, max_length=300)
    research_question: str = Field(min_length=5)
    hypothesis: str | None = None
    research_area: str | None = Field(default=None, max_length=200)
    description: str | None = None
    platform: Platform
    privacy: Privacy = Privacy.INTERNAL
    team_id: uuid.UUID | None = None
    start_date: date | None = None
    target_completion_date: date | None = None


class ProjectPatch(BaseModel):
    research_question: str | None = None
    hypothesis: str | None = None
    description: str | None = None
    status: ProjectStatus | None = None
    privacy: Privacy | None = None
    target_completion_date: date | None = None


def project_out(p: Project, role: str | None = None) -> dict:
    return {"id": str(p.id), "name": p.name, "research_question": p.research_question, "hypothesis": p.hypothesis,
            "research_area": p.research_area, "description": p.description, "platform": p.platform.value,
            "privacy": p.privacy.value, "status": p.status.value, "team_id": str(p.team_id) if p.team_id else None,
            "principal_researcher_id": str(p.principal_researcher_id),
            "start_date": p.start_date, "target_completion_date": p.target_completion_date,
            "created_at": p.created_at, "updated_at": p.updated_at, "archived": p.archived_at is not None,
            "my_role": role}


@router.post("/projects", status_code=201, summary="Create a research project")
def create_project(body: ProjectIn, request: Request, db: Session = Depends(get_db),
                   user: User = Depends(current_user)):
    if not can_create_project(user.role.name.value) or user.organization_id is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot create projects")
    if body.start_date and body.target_completion_date and body.target_completion_date < body.start_date:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Target completion date is before start date")
    p = Project(organization_id=user.organization_id, principal_researcher_id=user.id, created_by_id=user.id,
                **body.model_dump())
    db.add(p)
    try:
        db.flush()
    except IntegrityError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, "A project with this name already exists") from exc
    db.add(ProjectMember(project_id=p.id, user_id=user.id, project_role=ProjectRole.OWNER, added_by_id=user.id,
                         contributions=[Contribution.CONCEPTUALIZATION.value]))
    audit_request(db, request, user, "project.create", "project", p.id, project_id=p.id)
    return project_out(p, "OWNER")


@router.get("/projects", summary="Projects you can access")
def list_projects(db: Session = Depends(get_db), user: User = Depends(current_user),
                  status_filter: ProjectStatus | None = Query(default=None, alias="status")):
    member = select(ProjectMember.project_id).where(ProjectMember.user_id == user.id)
    q = select(Project)
    if user.role.name.value in ORG_LEVEL_ROLES:
        q = q.where(or_(Project.organization_id == user.organization_id, Project.privacy == Privacy.PUBLIC))
    else:
        q = q.where(or_(Project.id.in_(member), Project.privacy == Privacy.PUBLIC))
    if status_filter:
        q = q.where(Project.status == status_filter)
    roles = dict(db.execute(select(ProjectMember.project_id, ProjectMember.project_role)
                            .where(ProjectMember.user_id == user.id)).all())
    return [project_out(p, roles[p.id].value if p.id in roles else None)
            for p in db.scalars(q.order_by(Project.updated_at.desc()))]


@router.get("/projects/{project_id}", summary="Project details")
def get_project(project_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(current_user)):
    acc = project_access(project_id, db, user)
    return project_out(acc.project, acc.project_role)


@router.patch("/projects/{project_id}", summary="Update a project")
def update_project(project_id: uuid.UUID, body: ProjectPatch, request: Request, db: Session = Depends(get_db),
                   user: User = Depends(current_user)):
    acc = project_access(project_id, db, user)
    acc.require("project.update")
    changes = body.model_dump(exclude_unset=True)
    if changes.get("status") == ProjectStatus.ARCHIVED:
        acc.require("project.archive")
        acc.project.archived_at = datetime.now(timezone.utc)
    for k, v in changes.items():
        setattr(acc.project, k, v)
    audit_request(db, request, user, "project.update", "project", project_id, project_id=project_id,
                  fields=sorted(changes))
    return project_out(acc.project, acc.project_role)


class MemberIn(BaseModel):
    email: str
    project_role: ProjectRole
    contributions: list[Contribution] = []


@router.get("/projects/{project_id}/members", summary="Project members and contributions")
def list_members(project_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(current_user)):
    project_access(project_id, db, user)
    rows = db.execute(select(ProjectMember, User).join(User, User.id == ProjectMember.user_id)
                      .where(ProjectMember.project_id == project_id)).all()
    return [{"user_id": str(u.id), "display_name": u.display_name or u.email.split("@")[0],
             "project_role": m.project_role.value, "contributions": m.contributions} for m, u in rows]


@router.post("/projects/{project_id}/members", status_code=201, summary="Add or update a project member")
def add_member(project_id: uuid.UUID, body: MemberIn, request: Request, db: Session = Depends(get_db),
               user: User = Depends(current_user)):
    acc = project_access(project_id, db, user)
    acc.require("member.manage")
    target = db.scalar(select(User).where(func.lower(User.email) == body.email.lower()))
    if target is None or target.organization_id != acc.project.organization_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No researcher with that email in this organization")
    m = db.get(ProjectMember, (project_id, target.id))
    if m is None:
        m = ProjectMember(project_id=project_id, user_id=target.id, added_by_id=user.id, project_role=body.project_role)
        db.add(m)
    m.project_role = body.project_role
    m.contributions = [c.value for c in body.contributions]  # recorded, never converted into authorship
    audit_request(db, request, user, "project.member_set", "project", project_id, project_id=project_id,
                  member=target.id, project_role=body.project_role.value)
    return {"user_id": str(target.id), "project_role": m.project_role.value, "contributions": m.contributions}


# ------------------------------------------------------------------ teams
class TeamIn(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    discipline: Discipline | None = None
    description: str | None = None


@router.post("/teams", status_code=201, tags=["teams"], summary="Create a research team")
def create_team(body: TeamIn, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if not can_create_project(user.role.name.value) or user.organization_id is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Your role cannot create teams")
    t = Team(organization_id=user.organization_id, **body.model_dump())
    db.add(t)
    try:
        db.flush()
    except IntegrityError as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, "A team with this name already exists") from exc
    db.add(TeamMember(team_id=t.id, user_id=user.id))
    audit_request(db, request, user, "team.create", "team", t.id)
    return {"id": str(t.id), "name": t.name, "discipline": t.discipline.value if t.discipline else None}


@router.get("/teams", tags=["teams"], summary="Teams in your organization")
def list_teams(db: Session = Depends(get_db), user: User = Depends(current_user)):
    teams = db.scalars(select(Team).where(Team.organization_id == user.organization_id).order_by(Team.name)).all()
    out = []
    for t in teams:
        members = db.execute(select(User).join(TeamMember, TeamMember.user_id == User.id)
                             .where(TeamMember.team_id == t.id)).scalars().all()
        out.append({"id": str(t.id), "name": t.name, "discipline": t.discipline.value if t.discipline else None,
                    "description": t.description,
                    "members": [{"user_id": str(u.id), "display_name": u.display_name or u.email.split("@")[0]}
                                for u in members]})
    return out


class TeamMemberIn(BaseModel):
    email: str = Field(min_length=3, max_length=320)


@router.post("/teams/{team_id}/members", status_code=201, tags=["teams"], summary="Add a researcher to a team")
def add_team_member(team_id: uuid.UUID, body: TeamMemberIn, request: Request, db: Session = Depends(get_db),
                    user: User = Depends(current_user)):
    team = db.get(Team, team_id)
    if team is None or team.organization_id != user.organization_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Team not found")
    if not db.get(TeamMember, (team_id, user.id)) and user.role.name.value not in ORG_LEVEL_ROLES:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only team members can add researchers")
    target = db.scalar(select(User).where(func.lower(User.email) == body.email.lower()))
    if target is None or target.organization_id != user.organization_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No researcher with that email in this organization")
    if not db.get(TeamMember, (team_id, target.id)):
        db.add(TeamMember(team_id=team_id, user_id=target.id))
    audit_request(db, request, user, "team.member_add", "team", team_id, member=target.id)
    return {"team_id": str(team_id), "user_id": str(target.id)}


# ------------------------------------------------------------------ tasks & comments
class TaskIn(BaseModel):
    title: str = Field(min_length=2, max_length=300)
    description: str | None = None
    assignee_id: uuid.UUID | None = None
    due_date: date | None = None
    contribution_category: Contribution | None = None
    status: TaskStatus = TaskStatus.TODO


@router.get("/projects/{project_id}/tasks", tags=["collaboration"])
def list_tasks(project_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(current_user)):
    project_access(project_id, db, user)
    return [{"id": str(t.id), "title": t.title, "description": t.description, "status": t.status.value,
             "assignee_id": str(t.assignee_id) if t.assignee_id else None, "due_date": t.due_date,
             "contribution_category": t.contribution_category.value if t.contribution_category else None}
            for t in db.scalars(select(Task).where(Task.project_id == project_id).order_by(Task.created_at))]


@router.post("/projects/{project_id}/tasks", status_code=201, tags=["collaboration"])
def create_task(project_id: uuid.UUID, body: TaskIn, request: Request, db: Session = Depends(get_db),
                user: User = Depends(current_user)):
    project_access(project_id, db, user).require("task.manage")
    t = Task(project_id=project_id, created_by_id=user.id, **body.model_dump())
    db.add(t); db.flush()
    audit_request(db, request, user, "task.create", "task", t.id, project_id=project_id)
    return {"id": str(t.id), "title": t.title, "status": t.status.value}


class TaskPatch(BaseModel):
    status: TaskStatus


@router.patch("/projects/{project_id}/tasks/{task_id}", tags=["collaboration"])
def update_task(project_id: uuid.UUID, task_id: uuid.UUID, body: TaskPatch, db: Session = Depends(get_db),
                user: User = Depends(current_user)):
    project_access(project_id, db, user).require("task.manage")
    t = db.get(Task, task_id)
    if t is None or t.project_id != project_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Task not found")
    t.status = body.status
    return {"id": str(t.id), "status": t.status.value}


class CommentIn(BaseModel):
    target_type: CommentTarget
    target_id: uuid.UUID
    body: str = Field(min_length=1, max_length=10000)
    parent_id: uuid.UUID | None = None


@router.get("/projects/{project_id}/comments", tags=["collaboration"])
def list_comments(project_id: uuid.UUID, target_type: CommentTarget | None = None, target_id: uuid.UUID | None = None,
                  db: Session = Depends(get_db), user: User = Depends(current_user)):
    project_access(project_id, db, user).require("comment.read")
    q = select(Comment, User).outerjoin(User, User.id == Comment.author_id).where(Comment.project_id == project_id)
    if target_type:
        q = q.where(Comment.target_type == target_type)
    if target_id:
        q = q.where(Comment.target_id == target_id)
    return [{"id": str(c.id), "author": (u.display_name or u.email.split("@")[0]) if u else "former member",
             "target_type": c.target_type.value, "target_id": str(c.target_id), "body": c.body,
             "parent_id": str(c.parent_id) if c.parent_id else None, "resolved": c.resolved,
             "created_at": c.created_at} for c, u in db.execute(q.order_by(Comment.created_at))]


@router.post("/projects/{project_id}/comments", status_code=201, tags=["collaboration"])
def create_comment(project_id: uuid.UUID, body: CommentIn, request: Request, db: Session = Depends(get_db),
                   user: User = Depends(current_user)):
    project_access(project_id, db, user).require("comment.create")
    c = Comment(project_id=project_id, author_id=user.id, **body.model_dump())
    db.add(c); db.flush()
    audit_request(db, request, user, "comment.create", "comment", c.id, project_id=project_id)
    return {"id": str(c.id)}


@router.get("/projects/{project_id}/audit", tags=["audit"], summary="Append-only project audit trail")
def project_audit(project_id: uuid.UUID, limit: int = Query(200, le=1000), db: Session = Depends(get_db),
                  user: User = Depends(current_user)):
    project_access(project_id, db, user).require("audit.read")
    rows = db.execute(select(AuditLog, User).outerjoin(User, User.id == AuditLog.actor_id)
                      .where(AuditLog.details["project_id"].astext == str(project_id))
                      .order_by(AuditLog.occurred_at.desc()).limit(limit)).all()
    return [{"id": a.id, "when": a.occurred_at, "who": (u.display_name or u.email.split("@")[0]) if u else "system",
             "action": a.action, "resource_type": a.resource_type, "resource_id": a.resource_id,
             "details": {k: v for k, v in a.details.items() if k != "project_id"}} for a, u in rows]
