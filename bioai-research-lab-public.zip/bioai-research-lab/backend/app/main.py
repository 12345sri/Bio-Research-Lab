"""FastAPI entry point."""
import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

from app.api.v1 import auth, datasets, experiments, projects
from app.core.config import Settings
from app.core.ratelimit import limiter
from app.science.common import ScienceError

settings = Settings()
log = logging.getLogger("bioai")

app = FastAPI(
    title="BioAI Research Lab API",
    version=settings.app_version,
    description="Research infrastructure API. Not a medical device; it does not diagnose disease.",
    openapi_url="/api/v1/openapi.json",
    docs_url="/api/v1/docs",
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=list(settings.cors_origins), allow_credentials=False,
                   allow_methods=["GET", "POST", "PATCH"], allow_headers=["Authorization", "Content-Type"])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    return response


@app.exception_handler(ScienceError)
async def science_error(_: Request, exc: ScienceError):
    return JSONResponse(status_code=422, content={"detail": str(exc)})


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    # Log the type and path only: request bodies may contain research data or credentials.
    log.error("Unhandled %s on %s %s", type(exc).__name__, request.method, request.url.path)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


for r in (auth.router, projects.router, datasets.router, experiments.router):
    app.include_router(r, prefix="/api/v1")


@app.get("/api/v1/health", tags=["system"])
def health() -> dict:
    return {"status": "ok", "version": settings.app_version}
