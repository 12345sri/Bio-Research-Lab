"""Upload validation for CSV / TSV / TXT research files.

Checks: size limit, allowed extension, not a disguised binary, UTF-8 text, consistent
tabular structure, and a column schema. Also neutralises spreadsheet formula injection
when values are exported back to CSV.
"""
from __future__ import annotations

import csv
import hashlib
import io
import re
from dataclasses import dataclass, field

ALLOWED_EXTENSIONS = {".csv": "CSV", ".tsv": "TSV", ".txt": "TXT", ".gmt": "TXT"}
DEFAULT_MAX_BYTES = 200 * 1024 * 1024
BINARY_SIGNATURES = {b"PK\x03\x04": "zip/office document", b"%PDF": "PDF", b"MZ": "executable",
                     b"\x7fELF": "executable", b"\x89PNG": "PNG image", b"\xff\xd8\xff": "JPEG image",
                     b"\x1f\x8b": "gzip archive"}
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


class UploadRejected(ValueError):
    """The file cannot be accepted. The message is shown to the researcher."""


@dataclass
class UploadInfo:
    safe_filename: str
    file_type: str
    size_bytes: int
    sha256: str
    delimiter: str | None
    n_rows: int
    n_columns: int
    columns: list[str]
    column_schema: dict = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)


def safe_filename(name: str) -> str:
    base = re.split(r"[\\/]", name or "")[-1]
    base = re.sub(r"[^A-Za-z0-9._-]", "_", base).lstrip(".")
    return base[:200] or "upload"


def _infer_type(values: list[str]) -> str:
    vals = [v for v in values if v not in ("", "NA", "NaN", "nan", "null")]
    if not vals:
        return "empty"
    try:
        [float(v) for v in vals]
        return "numeric"
    except ValueError:
        return "text"


def validate_upload(filename: str, data: bytes, max_bytes: int = DEFAULT_MAX_BYTES,
                    sample_rows: int = 2000) -> UploadInfo:
    name = safe_filename(filename)
    ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in ALLOWED_EXTENSIONS:
        raise UploadRejected(f"Only {', '.join(ALLOWED_EXTENSIONS)} files are accepted")
    if len(data) == 0:
        raise UploadRejected("The file is empty")
    if len(data) > max_bytes:
        raise UploadRejected(f"File is {len(data) / 1e6:.1f} MB; the limit is {max_bytes / 1e6:.0f} MB")
    for sig, kind in BINARY_SIGNATURES.items():
        if data.startswith(sig):
            raise UploadRejected(f"This looks like a {kind}, not a text data file")
    if b"\x00" in data[:65536]:
        raise UploadRejected("The file contains binary content")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise UploadRejected("The file must be UTF-8 encoded text") from exc

    lines = [ln for ln in text.splitlines() if ln.strip()]
    if not lines:
        raise UploadRejected("The file has no content")
    if ext == ".gmt" or (ext == ".txt" and _looks_like_gmt(lines)):
        return _validate_gmt(name, data, lines)
    if ext == ".tsv":
        delim = "\t"
    elif ext == ".csv":
        delim = ","
    else:
        head = "\n".join(lines[:50])
        counts = {d: head.count(d) for d in ("\t", ",", ";")}
        delim = max(counts, key=counts.get) if max(counts.values()) > 0 else None
    warnings = []
    if delim is None:  # single-column text, e.g. one RR interval per line
        rows = [[ln.strip()] for ln in lines]
    else:
        rows = list(csv.reader(io.StringIO(text), delimiter=delim))
        rows = [r for r in rows if any(c.strip() for c in r)]
    width = len(rows[0])
    ragged = [i + 1 for i, r in enumerate(rows) if len(r) != width]
    if ragged:
        raise UploadRejected(f"Inconsistent number of columns on {len(ragged)} line(s), first at line {ragged[0]}")
    header = [c.strip() for c in rows[0]]
    has_header = any(_infer_type([c]) == "text" for c in header)
    columns = header if has_header else [f"column_{i + 1}" for i in range(width)]
    body = rows[1:] if has_header else rows
    if has_header and len(set(columns)) != len(columns):
        raise UploadRejected("Column names must be unique")
    schema = {c: _infer_type([r[i].strip() for r in body[:sample_rows]]) for i, c in enumerate(columns)}
    if len(body) == 0:
        raise UploadRejected("The file has a header but no data rows")
    if not has_header:
        warnings.append("No header row detected; columns were named column_1, column_2, ...")
    return UploadInfo(name, ALLOWED_EXTENSIONS[ext], len(data), hashlib.sha256(data).hexdigest(),
                      delim, len(body), width, columns, schema, warnings)


def csv_safe(value) -> str:
    """Prevent spreadsheet formula injection when exporting user-supplied values."""
    s = "" if value is None else str(value)
    if s.startswith(FORMULA_PREFIXES):
        try:
            float(s)  # plain negative numbers are data, not formulas
            return s
        except ValueError:
            return "'" + s
    return s


def _looks_like_gmt(lines: list[str]) -> bool:
    fields = [ln.split("\t") for ln in lines[:20]]
    return len(fields) > 1 and all(len(f) >= 3 for f in fields) and len({len(f) for f in fields}) > 1


def _validate_gmt(name: str, data: bytes, lines: list[str]) -> UploadInfo:
    """Gene-set files: one set per line, NAME<TAB>DESCRIPTION<TAB>GENE1<TAB>GENE2..."""
    sets, bad = {}, []
    for i, ln in enumerate(lines, start=1):
        f = [x.strip() for x in ln.split("\t")]
        genes = [g for g in f[2:] if g]
        if len(f) < 3 or not f[0] or not genes:
            bad.append(i)
        elif f[0] in sets:
            raise UploadRejected(f"Gene set '{f[0]}' appears more than once (line {i})")
        else:
            sets[f[0]] = len(genes)
    if bad:
        raise UploadRejected(f"{len(bad)} line(s) are not NAME<TAB>DESCRIPTION<TAB>GENES..., first at line {bad[0]}")
    return UploadInfo(name, "TXT", len(data), hashlib.sha256(data).hexdigest(), "\t", len(sets), 1,
                      ["gene_set"], {"format": "GMT", "gene_sets": len(sets),
                                     "genes_per_set_min": min(sets.values()), "genes_per_set_max": max(sets.values())})
