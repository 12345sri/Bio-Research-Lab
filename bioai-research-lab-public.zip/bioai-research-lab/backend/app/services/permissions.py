"""Authorization policy. Pure functions, so every rule is unit-tested without a database.

Organization-level roles (ADMIN, FOUNDER, CO_FOUNDER) may do everything inside their own
organization. Everyone else acts through their project membership. Non-members can only
read PUBLIC projects (metadata and results, never datasets).
"""
from __future__ import annotations

ORG_LEVEL_ROLES = frozenset({"ADMIN", "FOUNDER", "CO_FOUNDER"})

ACTIONS = frozenset({
    "project.read", "project.update", "project.archive", "member.manage",
    "dataset.read", "dataset.upload", "dataset.download", "dataset.archive",
    "experiment.read", "experiment.run", "experiment.clone",
    "report.read", "report.create", "report.approve",
    "comment.read", "comment.create", "task.manage",
    "audit.read", "publication.manage",
})

_PROJECT_ROLE_ACTIONS: dict[str, frozenset[str]] = {
    "VIEWER": frozenset({"project.read", "experiment.read", "report.read", "comment.read"}),
    "REVIEWER": frozenset({"project.read", "experiment.read", "report.read", "comment.read", "comment.create",
                           "dataset.read", "report.approve"}),
    "CONTRIBUTOR": frozenset({"project.read", "experiment.read", "report.read", "comment.read", "comment.create",
                              "dataset.read", "dataset.upload", "dataset.download", "experiment.run",
                              "experiment.clone", "report.create", "task.manage"}),
}
_PROJECT_ROLE_ACTIONS["LEAD"] = _PROJECT_ROLE_ACTIONS["CONTRIBUTOR"] | {
    "project.update", "member.manage", "dataset.archive", "report.approve", "audit.read", "publication.manage"}
_PROJECT_ROLE_ACTIONS["OWNER"] = _PROJECT_ROLE_ACTIONS["LEAD"] | {"project.archive"}

PUBLIC_READ = frozenset({"project.read", "experiment.read", "report.read"})


def can(action: str, *, org_role: str, same_org: bool, project_role: str | None,
        project_privacy: str) -> bool:
    if action not in ACTIONS:
        raise ValueError(f"Unknown action {action}")
    if org_role in ORG_LEVEL_ROLES and same_org:
        return True
    if project_role is not None:
        allowed = _PROJECT_ROLE_ACTIONS.get(project_role, frozenset())
        # Organization-wide VIEWER accounts never gain write access through a project role.
        if org_role == "VIEWER":
            allowed = allowed & _PROJECT_ROLE_ACTIONS["VIEWER"]
        return action in allowed
    return project_privacy == "PUBLIC" and action in PUBLIC_READ


def can_create_project(org_role: str) -> bool:
    return org_role != "VIEWER"


def can_view_individual_physiology(*, org_role: str, same_org: bool, project_role: str | None,
                                   requester_is_employer_context: bool) -> bool:
    """Workplace studies: employers only ever see governed aggregates (docs/scientific-rules.md)."""
    if requester_is_employer_context:
        return False
    return can("dataset.read", org_role=org_role, same_org=same_org, project_role=project_role,
               project_privacy="RESTRICTED_HUMAN_DATA")
