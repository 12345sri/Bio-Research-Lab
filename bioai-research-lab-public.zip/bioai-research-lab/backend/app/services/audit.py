"""Append-only audit trail writer. Never records participant identifiers or file contents."""
from __future__ import annotations

import uuid

from sqlalchemy.orm import Session

from app.models import AuditLog

_FORBIDDEN_DETAIL_KEYS = {"participant_id", "password", "token", "email_verification_token"}


def record(db: Session, *, actor_id: uuid.UUID | None, organization_id: uuid.UUID | None, action: str,
           resource_type: str, resource_id=None, ip: str | None = None, user_agent: str | None = None,
           **details) -> None:
    safe = {k: (str(v) if isinstance(v, uuid.UUID) else v) for k, v in details.items()
            if k not in _FORBIDDEN_DETAIL_KEYS}
    db.add(AuditLog(actor_id=actor_id, organization_id=organization_id, action=action,
                    resource_type=resource_type, resource_id=str(resource_id) if resource_id else None,
                    ip_address=ip, user_agent=(user_agent or "")[:400] or None, details=safe))
