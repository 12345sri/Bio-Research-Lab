"""Experiment execution: load pinned dataset versions, run the science pipeline, persist everything.

Used by the Celery worker (and inline in tests). Web requests never run analyses themselves.
"""
from __future__ import annotations

import json
import tempfile
import traceback
import uuid
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.v1.datasets import read_version
from app.core.config import Settings
from app.models import (DatasetVersion, Experiment, ExperimentResult, Feature, Model, ModelRun, Project, Report,
                        ValidationRun)
from app.models.enums import (Algorithm, EvidenceLabel, ExperimentStatus, FeatureType, ImportanceMethod, Platform,
                              Resampling, ResamplingScope, SplitStrategy, ValidationType)
from app.science.common import clean
from app.science.copilot.copilot import review
from app.science.pipelines import run_biosignal, run_omics
from app.services import audit
from app.services.storage import get_storage

PERMUTATION_KEY = "importance"
ARTIFACT_TYPES = {"html": "text/html", "pdf": "application/pdf", "json": "application/json",
                  "csv": "application/zip"}


def _public(result: dict) -> dict:
    """JSON-safe view of a pipeline result (private '_' objects removed, tables as records)."""
    return clean({k: (v.to_dict("records") if hasattr(v, "to_dict") else v)
                  for k, v in result.items() if not k.startswith("_")})


def _load(db: Session, version_id) -> tuple[DatasetVersion, object]:
    v = db.get(DatasetVersion, uuid.UUID(str(version_id)))
    if v is None:
        raise ValueError(f"Dataset version {version_id} not found")
    return v, read_version(v)


def execute(db: Session, experiment_id: uuid.UUID, settings: Settings | None = None) -> None:
    s = settings or Settings()
    exp = db.get(Experiment, experiment_id)
    if exp is None:
        raise ValueError("Experiment not found")
    exp.status, exp.started_at, exp.error_message = ExperimentStatus.RUNNING, datetime.now(timezone.utc), None
    db.commit()
    try:
        project = db.get(Project, exp.project_id)
        cfg = dict(exp.parameters)
        main_v, main_df = _load(db, exp.dataset_version_id)
        if exp.platform == Platform.BIOSIGNAL:
            if not s.pseudonym_secret:
                raise ValueError("PSEUDONYM_SECRET is not configured; biosignal analysis refuses to run without it")
            result = run_biosignal(main_df, cfg, s.pseudonym_secret + str(exp.project_id))
        else:
            _, meta = _load(db, cfg["metadata_version_id"])
            gmt = None
            if cfg.get("gene_sets_version_id"):
                gv = db.get(DatasetVersion, uuid.UUID(cfg["gene_sets_version_id"]))
                gmt = get_storage().get(gv.storage_key).decode("utf-8")
            external = None
            if cfg.get("external_expression_version_id"):
                _, ex = _load(db, cfg["external_expression_version_id"])
                _, em = _load(db, cfg["external_metadata_version_id"])
                external = (ex, em)
            layers = {name: _load(db, vid)[1] for name, vid in (cfg.get("extra_layers") or {}).items()} or None
            expr = main_df.set_index(main_df.columns[0])
            if external:
                external = (external[0].set_index(external[0].columns[0]), external[1])
            if layers:
                layers = {k: d.set_index(d.columns[0]) for k, d in layers.items()}
            result = run_omics(expr, meta, cfg, gmt_text=gmt, external=external, extra_layers=layers)

        issues = review(result)
        public = _public(result)
        db.add(ExperimentResult(experiment_id=exp.id, result_type="pipeline_result",
                                evidence_label=EvidenceLabel.DATA, payload=public))
        db.add(ExperimentResult(experiment_id=exp.id, result_type="review", evidence_label=EvidenceLabel.INTERPRETATION,
                                payload={"issues": clean(issues)}))
        _record_models(db, exp, result, cfg)

        from app.science.reports import builder
        rep = builder.build(result, {"name": project.name, "research_question": project.research_question,
                                     "principal_researcher": str(project.principal_researcher_id),
                                     "demo": bool(cfg.get("demo"))}, issues)
        keys = {}
        with tempfile.TemporaryDirectory() as tmp:
            files = builder.export_all(rep, result, tmp, "report")
            for fmt, path in files.items():
                key = f"experiments/{exp.project_id}/{exp.id}/report.{ 'zip' if fmt == 'csv' else fmt}"
                get_storage().put(key, open(path, "rb").read(), ARTIFACT_TYPES[fmt])
                keys[fmt] = key
            for name, png in rep["figures"].items():
                key = f"experiments/{exp.project_id}/{exp.id}/fig_{name}.png"
                get_storage().put(key, png, "image/png")
                keys[f"figure:{name}"] = key
        db.add(Report(project_id=exp.project_id, experiment_id=exp.id, title=rep["title"],
                      sections={"titles": [sec["title"] for sec in rep["sections"]]}, exports=keys,
                      created_by_id=exp.researcher_id))
        exp.software_versions = result["provenance"].get("software_versions", {})
        exp.status, exp.finished_at = ExperimentStatus.SUCCEEDED, datetime.now(timezone.utc)
        audit.record(db, actor_id=exp.researcher_id, organization_id=project.organization_id,
                     action="experiment.succeeded", resource_type="experiment", resource_id=exp.id,
                     project_id=exp.project_id, dataset_version_id=exp.dataset_version_id,
                     config_hash=result["provenance"].get("config_hash"))
        db.commit()
    except Exception as exc:  # recorded on the experiment; the traceback stays in worker logs only
        db.rollback()
        exp = db.get(Experiment, experiment_id)
        exp.status, exp.finished_at = ExperimentStatus.FAILED, datetime.now(timezone.utc)
        exp.error_message = f"{type(exc).__name__}: {exc}"[:2000]
        audit.record(db, actor_id=exp.researcher_id, organization_id=None, action="experiment.failed",
                     resource_type="experiment", resource_id=exp.id, project_id=exp.project_id,
                     error=type(exc).__name__)
        db.commit()
        traceback.print_exc()


def _record_models(db: Session, exp: Experiment, result: dict, cfg: dict) -> None:
    """Mirror ML runs into model_runs/features/validation_runs so database guard constraints apply."""
    ml = result.get("ml")
    if not ml:
        return
    split = (ml.get("split") or {}).get("strategy", "STRATIFIED_ROW")
    resampling = (cfg.get("ml") or {}).get("resampling", "NONE")
    for algo, r in ml["models"].items():
        name = f"{algo.lower()}"
        model = db.scalar(select(Model).where(Model.project_id == exp.project_id, Model.name == name))
        if model is None:
            model = Model(project_id=exp.project_id, name=name, algorithm=Algorithm(algo), created_by_id=exp.researcher_id)
            db.add(model); db.flush()
        run = ModelRun(model_id=model.id, experiment_id=exp.id,
                       hyperparameters=clean((cfg.get("ml") or {}).get("params", {}).get(algo, {})),
                       split_strategy=SplitStrategy(split), n_folds=(cfg.get("ml") or {}).get("cv_folds", 5),
                       random_seed=exp.random_seed, resampling=Resampling(resampling),
                       resampling_scope=ResamplingScope.TRAINING_FOLDS_ONLY if resampling == "SMOTE"
                       else ResamplingScope.NOT_APPLICABLE,
                       class_distribution=clean(ml["split"].get("distribution", {})),
                       metrics=clean({"cv": r.get("cv"), "test": {k: v for k, v in r.get("test", {}).items()
                                                               if k not in ("roc_curve", "pr_curve")}}))
        db.add(run); db.flush()
        expl = (result.get("explanations") or ml.get("explanations") or {}).get(algo) or {}
        if expl.get("shap_available"):
            ranking, method, key = (expl.get("global") or {}).get("ranking") or [], ImportanceMethod.SHAP, "mean_abs_shap"
        else:
            ranking, method, key = ((expl.get("permutation") or {}).get("ranking") or [],
                                    ImportanceMethod.PERMUTATION, PERMUTATION_KEY)
        for i, row in enumerate(ranking[:50], start=1):
            value = row.get(key)
            if value is None:
                continue
            db.add(Feature(model_run_id=run.id, name=str(row.get("feature"))[:200],
                           feature_type=FeatureType.GENE if exp.platform == Platform.BIOOMICS else FeatureType.HRV_METRIC,
                           importance_method=method, importance=float(value), rank=i,
                           evidence_label=EvidenceLabel.EXPLANATION))
        ext = (result.get("external_validation") or {}).get("models", {}).get(algo)
        if ext and cfg.get("external_expression_version_id"):
            db.add(ValidationRun(model_run_id=run.id, validation_type=ValidationType.EXTERNAL,
                                 train_dataset_version_id=exp.dataset_version_id,
                                 validation_dataset_version_id=uuid.UUID(cfg["external_expression_version_id"]),
                                 metrics=clean({k: v for k, v in ext.items() if k not in ("roc_curve", "pr_curve")})))
    db.flush()


def to_json_bytes(obj) -> bytes:
    return json.dumps(clean(obj), default=str).encode()
