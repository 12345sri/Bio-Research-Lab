"""SQLite schema for local mode. Mirrors the PostgreSQL model, including the scientific guard constraints
and the append-only audit trail, so local runs keep the same integrity rules."""
import sqlite3
import uuid
from datetime import datetime, timezone

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS organizations (id TEXT PRIMARY KEY, name TEXT UNIQUE NOT NULL, slug TEXT UNIQUE NOT NULL,
  mission TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS roles (id TEXT PRIMARY KEY, name TEXT UNIQUE NOT NULL CHECK (name IN ('ADMIN','FOUNDER',
  'CO_FOUNDER','RESEARCH_LEAD','RESEARCHER','BIOINFORMATICIAN','DATA_SCIENTIST','BIOMEDICAL_RESEARCHER','DEVELOPER','VIEWER')),
  organization_level INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT NOT NULL, password_hash TEXT NOT NULL, display_name TEXT,
  organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL, role_id TEXT NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  is_active INTEGER NOT NULL DEFAULT 1, email_verified_at TEXT, last_login_at TEXT, deleted_at TEXT, created_at TEXT NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_email_lower ON users (lower(email));
CREATE TABLE IF NOT EXISTS user_tokens (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  purpose TEXT NOT NULL CHECK (purpose IN ('VERIFY_EMAIL','RESET_PASSWORD')), token_hash TEXT UNIQUE NOT NULL,
  expires_at TEXT NOT NULL, used_at TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS teams (id TEXT PRIMARY KEY, organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name TEXT NOT NULL, discipline TEXT, description TEXT, created_at TEXT NOT NULL, UNIQUE (organization_id, name));
CREATE TABLE IF NOT EXISTS team_members (team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at TEXT NOT NULL, PRIMARY KEY (team_id, user_id));
CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  name TEXT NOT NULL, research_question TEXT NOT NULL, hypothesis TEXT, research_area TEXT, description TEXT,
  platform TEXT NOT NULL CHECK (platform IN ('BIOSIGNAL','BIOOMICS','GENERAL')),
  principal_researcher_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT, team_id TEXT REFERENCES teams(id) ON DELETE SET NULL,
  privacy TEXT NOT NULL DEFAULT 'INTERNAL' CHECK (privacy IN ('PUBLIC','INTERNAL','CONFIDENTIAL','RESTRICTED_HUMAN_DATA')),
  status TEXT NOT NULL DEFAULT 'IDEA' CHECK (status IN ('IDEA','PLANNING','DATA_COLLECTION','ANALYSIS','VALIDATION','MANUSCRIPT',
  'SUBMITTED','PUBLISHED','ARCHIVED')), start_date TEXT, target_completion_date TEXT, created_by_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  archived_at TEXT, is_demo INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE (organization_id, name),
  CHECK (target_completion_date IS NULL OR start_date IS NULL OR target_completion_date >= start_date));
CREATE TABLE IF NOT EXISTS project_members (project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_role TEXT NOT NULL CHECK (project_role IN ('OWNER','LEAD','CONTRIBUTOR','REVIEWER','VIEWER')),
  contributions TEXT NOT NULL DEFAULT '[]', added_by_id TEXT, created_at TEXT NOT NULL, PRIMARY KEY (project_id, user_id));
CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL, description TEXT, status TEXT NOT NULL DEFAULT 'TODO' CHECK (status IN ('TODO','IN_PROGRESS','IN_REVIEW','DONE')),
  contribution_category TEXT, assignee_id TEXT REFERENCES users(id) ON DELETE SET NULL, created_by_id TEXT, due_date TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS comments (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  author_id TEXT REFERENCES users(id) ON DELETE SET NULL, target_type TEXT NOT NULL CHECK (target_type IN
  ('PROJECT','DATASET','EXPERIMENT','REPORT','TASK','PUBLICATION')), target_id TEXT NOT NULL, parent_id TEXT REFERENCES comments(id)
  ON DELETE CASCADE, body TEXT NOT NULL CHECK (length(trim(body)) > 0), resolved INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS datasets (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
  name TEXT NOT NULL, description TEXT, domain TEXT NOT NULL CHECK (domain IN ('BIOSIGNAL','BIOOMICS','GENERAL')),
  privacy TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','ARCHIVED','DELETED')),
  is_synthetic INTEGER NOT NULL DEFAULT 0, created_by_id TEXT, archived_at TEXT, created_at TEXT NOT NULL,
  UNIQUE (project_id, name), CHECK (status <> 'ARCHIVED' OR archived_at IS NOT NULL));
CREATE TABLE IF NOT EXISTS dataset_versions (id TEXT PRIMARY KEY, dataset_id TEXT NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
  version INTEGER NOT NULL CHECK (version >= 1), storage_key TEXT UNIQUE NOT NULL, original_filename TEXT,
  file_type TEXT NOT NULL CHECK (file_type IN ('CSV','TSV','TXT')), size_bytes INTEGER NOT NULL CHECK (size_bytes >= 0),
  sha256 TEXT NOT NULL CHECK (length(sha256) = 64), n_rows INTEGER, n_columns INTEGER, column_schema TEXT NOT NULL DEFAULT '{}',
  validation_status TEXT NOT NULL, validation_report TEXT NOT NULL DEFAULT '{}', change_note TEXT, uploaded_by_id TEXT,
  created_at TEXT NOT NULL, UNIQUE (dataset_id, version));
CREATE TABLE IF NOT EXISTS experiments (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
  dataset_version_id TEXT NOT NULL REFERENCES dataset_versions(id) ON DELETE RESTRICT,
  researcher_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT, parent_experiment_id TEXT REFERENCES experiments(id) ON DELETE SET NULL,
  name TEXT NOT NULL, platform TEXT NOT NULL, analysis_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','QUEUED','RUNNING','SUCCEEDED','FAILED','CANCELLED')),
  parameters TEXT NOT NULL, preprocessing TEXT NOT NULL DEFAULT '{}', feature_selection TEXT NOT NULL DEFAULT '{}',
  random_seed INTEGER NOT NULL, code_version TEXT NOT NULL, software_versions TEXT NOT NULL DEFAULT '{}',
  error_message TEXT, started_at TEXT, finished_at TEXT, created_at TEXT NOT NULL,
  CHECK (status <> 'FAILED' OR error_message IS NOT NULL), CHECK (parent_experiment_id IS NULL OR parent_experiment_id <> id));
CREATE TABLE IF NOT EXISTS experiment_results (id TEXT PRIMARY KEY, experiment_id TEXT NOT NULL REFERENCES experiments(id) ON DELETE CASCADE,
  result_type TEXT NOT NULL, evidence_label TEXT NOT NULL CHECK (evidence_label IN ('DATA','STATISTICS','MODEL','EXPLANATION',
  'LITERATURE','INTERPRETATION','HYPOTHESIS')), payload TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS model_runs (id TEXT PRIMARY KEY, experiment_id TEXT NOT NULL REFERENCES experiments(id) ON DELETE CASCADE,
  algorithm TEXT NOT NULL, split_strategy TEXT NOT NULL, random_seed INTEGER NOT NULL,
  resampling TEXT NOT NULL CHECK (resampling IN ('NONE','CLASS_WEIGHT','SMOTE')),
  resampling_scope TEXT NOT NULL CHECK (resampling_scope IN ('NOT_APPLICABLE','TRAINING_FOLDS_ONLY')),
  metrics TEXT NOT NULL, created_at TEXT NOT NULL,
  CHECK (resampling <> 'SMOTE' OR resampling_scope = 'TRAINING_FOLDS_ONLY'));
CREATE TABLE IF NOT EXISTS features (id TEXT PRIMARY KEY, model_run_id TEXT NOT NULL REFERENCES model_runs(id) ON DELETE CASCADE,
  name TEXT NOT NULL, importance_method TEXT NOT NULL, importance REAL NOT NULL, rank INTEGER,
  evidence_label TEXT NOT NULL DEFAULT 'EXPLANATION' CHECK (evidence_label = 'EXPLANATION'));
CREATE TABLE IF NOT EXISTS validation_runs (id TEXT PRIMARY KEY, model_run_id TEXT NOT NULL REFERENCES model_runs(id) ON DELETE CASCADE,
  validation_type TEXT NOT NULL CHECK (validation_type IN ('INTERNAL_CV','INTERNAL_HOLDOUT','EXTERNAL')),
  train_dataset_version_id TEXT NOT NULL REFERENCES dataset_versions(id), validation_dataset_version_id TEXT REFERENCES dataset_versions(id),
  metrics TEXT NOT NULL, created_at TEXT NOT NULL,
  CHECK (validation_type <> 'EXTERNAL' OR (validation_dataset_version_id IS NOT NULL
         AND validation_dataset_version_id <> train_dataset_version_id)));
CREATE TABLE IF NOT EXISTS reports (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  experiment_id TEXT REFERENCES experiments(id) ON DELETE SET NULL, title TEXT NOT NULL, exports TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, occurred_at TEXT NOT NULL, actor_id TEXT, organization_id TEXT,
  project_id TEXT, action TEXT NOT NULL, resource_type TEXT NOT NULL, resource_id TEXT, ip_address TEXT, details TEXT NOT NULL DEFAULT '{}');
CREATE INDEX IF NOT EXISTS ix_audit_project ON audit_logs (project_id, occurred_at);
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_logs BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_logs BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;
"""
ROLES = ["ADMIN", "FOUNDER", "CO_FOUNDER", "RESEARCH_LEAD", "RESEARCHER", "BIOINFORMATICIAN", "DATA_SCIENTIST",
         "BIOMEDICAL_RESEARCHER", "DEVELOPER", "VIEWER"]


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return str(uuid.uuid4())


def connect(path: str) -> sqlite3.Connection:
    c = sqlite3.connect(path, timeout=30, isolation_level=None, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.execute("PRAGMA journal_mode = WAL")
    return c


def init(path: str) -> None:
    c = connect(path)
    c.executescript(SCHEMA)
    if not c.execute("SELECT 1 FROM organizations WHERE slug='bioai-research-lab'").fetchone():
        c.execute("INSERT INTO organizations VALUES (?,?,?,?,?)", (new_id(), "BioAI Research Lab", "bioai-research-lab",
                  "Building explainable and reproducible AI infrastructure for biomedical research.", now()))
    for r in ROLES:
        c.execute("INSERT OR IGNORE INTO roles VALUES (?,?,?)", (new_id(), r, int(r in ("ADMIN", "FOUNDER", "CO_FOUNDER"))))
    c.close()
