import argparse
import os
import sys

from local.server import start

ap = argparse.ArgumentParser(description="BioAI Research Lab (local mode)")
ap.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8765")))
ap.add_argument("--data", default=os.environ.get("BIOAI_DATA_DIR", "local-data"))
a = ap.parse_args()
httpd = start(a.host, a.port, a.data)
print(f"BioAI Research Lab running at http://{a.host}:{a.port}  (data: {os.path.abspath(a.data)})", flush=True)
try:
    httpd.serve_forever()
except KeyboardInterrupt:
    sys.exit(0)
