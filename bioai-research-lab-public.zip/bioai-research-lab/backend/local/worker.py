"""Background execution of experiments in local mode (thread-based equivalent of the Celery worker)."""
from __future__ import annotations

import json
import tempfile
import traceback

from app.science.common import clean
from app.science.copilot.copilot import review
from app.science.pipelines import run_biosignal, run_omics
from app.science.reports import builder
from local import db as dbm

MEDIA = {"html": "text/html", "pdf": "application/pdf", "json": "application/json", "csv": "application/zip"}


def _public(result: dict) -> dict:
    return clean({k: (v.to_dict("records") if hasattr(v, "to_dict") else v) for k, v in result.items() if not k.startswith("_")})


def execute(cfg, eid: str) -> None:
    from local.server import read_version  # shared reader

    c = dbm.connect(cfg.db_path)
    try:
        e = c.execute("SELECT * FROM experiments WHERE id=?", (eid,)).fetchone()
        if e is None or e["status"] not in ("QUEUED",):
            return
        c.execute("UPDATE experiments SET status='RUNNING', started_at=?, error_message=NULL WHERE id=?", (dbm.now(), eid))
        p = c.execute("SELECT * FROM projects WHERE id=?", (e["project_id"],)).fetchone()
        params = json.loads(e["parameters"])

        def load(vid):
            v = c.execute("SELECT * FROM dataset_versions WHERE id=?", (vid,)).fetchone()
            if v is None:
                raise ValueError(f"Dataset version {vid} not found")
            return v, read_version_cfg(cfg, v, read_version)

        _, main = load(e["dataset_version_id"])
        if e["platform"] == "BIOSIGNAL":
            result = run_biosignal(main, params, cfg.pseudonym_secret + e["project_id"])
        else:
            _, meta = load(params["metadata_version_id"])
            gmt = None
            if params.get("gene_sets_version_id"):
                gv = c.execute("SELECT * FROM dataset_versions WHERE id=?", (params["gene_sets_version_id"],)).fetchone()
                gmt = cfg.storage.get(gv["storage_key"]).decode("utf-8")
            external = None
            if params.get("external_expression_version_id"):
                ex = load(params["external_expression_version_id"])[1]
                em = load(params["external_metadata_version_id"])[1]
                external = (ex.set_index(ex.columns[0]), em)
            result = run_omics(main.set_index(main.columns[0]), meta, params, gmt_text=gmt, external=external)

        issues = review(result)
        with c:
            c.execute("INSERT INTO experiment_results VALUES (?,?,?,?,?,?)", (dbm.new_id(), eid, "pipeline_result", "DATA",
                      json.dumps(_public(result), default=str), dbm.now()))
            c.execute("INSERT INTO experiment_results VALUES (?,?,?,?,?,?)", (dbm.new_id(), eid, "review", "INTERPRETATION",
                      json.dumps({"issues": clean(issues)}, default=str), dbm.now()))
            _record_models(c, e, result, params)
        rep = builder.build(result, {"name": p["name"], "research_question": p["research_question"],
                                     "principal_researcher": str(p["principal_researcher_id"]),
                                     "demo": bool(params.get("demo") or p["is_demo"])}, issues)
        keys = {}
        with tempfile.TemporaryDirectory() as tmp:
            for fmt, path in builder.export_all(rep, result, tmp, "report").items():
                key = f"experiments/{e['project_id']}/{eid}/report.{'zip' if fmt == 'csv' else fmt}"
                cfg.storage.put(key, open(path, "rb").read())
                keys[fmt] = key
        for name, png in rep["figures"].items():
            key = f"experiments/{e['project_id']}/{eid}/fig_{name}.png"
            cfg.storage.put(key, png)
            keys[f"figure:{name}"] = key
        with c:
            c.execute("INSERT INTO reports VALUES (?,?,?,?,?,?)", (dbm.new_id(), e["project_id"], eid, rep["title"], json.dumps(keys), dbm.now()))
            c.execute("UPDATE experiments SET status='SUCCEEDED', finished_at=?, software_versions=? WHERE id=?",
                      (dbm.now(), json.dumps(result["provenance"].get("software_versions", {})), eid))
            c.execute("INSERT INTO audit_logs (occurred_at, actor_id, organization_id, project_id, action, resource_type, resource_id, details)"
                      " VALUES (?,?,?,?,?,?,?,?)", (dbm.now(), e["researcher_id"], p["organization_id"], e["project_id"],
                      "experiment.succeeded", "experiment", eid, json.dumps({"dataset_version_id": e["dataset_version_id"],
                                                                            "config_hash": result["provenance"].get("config_hash")})))
    except Exception as exc:
        traceback.print_exc()
        msg = f"{type(exc).__name__}: {exc}"[:2000]
        with c:
            c.execute("DELETE FROM experiment_results WHERE experiment_id=?", (eid,))
            c.execute("UPDATE experiments SET status='FAILED', finished_at=?, error_message=? WHERE id=?", (dbm.now(), msg, eid))
            row = c.execute("SELECT project_id, researcher_id FROM experiments WHERE id=?", (eid,)).fetchone()
            if row:
                c.execute("INSERT INTO audit_logs (occurred_at, actor_id, project_id, action, resource_type, resource_id, details)"
                          " VALUES (?,?,?,?,?,?,?)", (dbm.now(), row["researcher_id"], row["project_id"], "experiment.failed",
                                                     "experiment", eid, json.dumps({"error": type(exc).__name__})))
    finally:
        c.close()


def read_version_cfg(cfg, v, reader):
    return reader(v)


def _record_models(c, e, result, params):
    """Mirror model runs, explanation features and external validation into guarded tables."""
    ml = result.get("ml")
    if not ml:
        return
    resampling = (params.get("ml") or {}).get("resampling", "NONE")
    for algo, r in ml["models"].items():
        rid = dbm.new_id()
        c.execute("INSERT INTO model_runs VALUES (?,?,?,?,?,?,?,?,?)", (rid, e["id"], algo, ml["split"].get("strategy"), e["random_seed"],
                  resampling, "TRAINING_FOLDS_ONLY" if resampling == "SMOTE" else "NOT_APPLICABLE",
                  json.dumps(clean({"cv": r.get("cv"), "test": {k: v for k, v in r["test"].items() if k not in ("roc_curve", "pr_curve")}})),
                  dbm.now()))
        ex = (result.get("explanations") or {}).get(algo) or {}
        if ex.get("shap_available"):
            ranking, method, key = ex["global"]["ranking"], "SHAP", "mean_abs_shap"
        else:
            ranking, method, key = (ex.get("permutation") or {}).get("ranking") or [], "PERMUTATION", "importance"
        for i, rw in enumerate(ranking[:50], 1):
            if rw.get(key) is not None:
                c.execute("INSERT INTO features VALUES (?,?,?,?,?,?,?)", (dbm.new_id(), rid, str(rw["feature"]), method, float(rw[key]), i, "EXPLANATION"))
        ext = ((result.get("external_validation") or {}).get("models") or {}).get(algo)
        if ext and params.get("external_expression_version_id"):
            c.execute("INSERT INTO validation_runs VALUES (?,?,?,?,?,?,?)", (dbm.new_id(), rid, "EXTERNAL", e["dataset_version_id"],
                      params["external_expression_version_id"],
                      json.dumps(clean({k: v for k, v in ext.items() if k not in ("roc_curve", "pr_curve")})), dbm.now()))
