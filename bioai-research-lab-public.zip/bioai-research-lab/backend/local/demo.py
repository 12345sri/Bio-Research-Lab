"""Demonstration project on synthetic data, created on first start in local mode.

Everything here is DEMONSTRATION DATA generated with fixed seeds. It is not biomedical evidence.
"""
from __future__ import annotations

import io
import json

from app.core.security import hash_password
from app.science import demo_data as dd
from app.science.common import _code_version
from local import db as dbm

DEMO_EMAIL, DEMO_PASSWORD = "demo@bioai.local", "Demo-Research-2026"
PROJECT = "DEMO: BioAI workflow on synthetic data"


def _csv(df, index=False) -> bytes:
    b = io.StringIO(); df.to_csv(b, index=index); return b.getvalue().encode()


def ensure_demo(cfg, jobs) -> None:
    from local.server import store_version
    c = dbm.connect(cfg.db_path)
    try:
        if c.execute("SELECT 1 FROM projects WHERE is_demo=1").fetchone():
            return
        org = c.execute("SELECT id FROM organizations WHERE slug='bioai-research-lab'").fetchone()["id"]
        role = c.execute("SELECT id FROM roles WHERE name='RESEARCHER'").fetchone()["id"]
        u = c.execute("SELECT * FROM users WHERE lower(email)=?", (DEMO_EMAIL,)).fetchone()
        c.execute("BEGIN")
        if u is None:
            uid = dbm.new_id()
            c.execute("INSERT INTO users (id,email,password_hash,display_name,organization_id,role_id,email_verified_at,created_at)"
                      " VALUES (?,?,?,?,?,?,?,?)", (uid, DEMO_EMAIL, hash_password(DEMO_PASSWORD), "Demo Researcher", org, role,
                                                   dbm.now(), dbm.now()))
        else:
            uid = u["id"]
        user = {"id": uid}
        pid, t = dbm.new_id(), dbm.now()
        c.execute("INSERT INTO projects (id, organization_id, name, research_question, hypothesis, research_area, platform,"
                  " principal_researcher_id, privacy, status, created_by_id, is_demo, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (pid, org, PROJECT, "DEMONSTRATION ONLY: can synthetic HRV separate a normal day from an exam day, and can "
                   "synthetic expression profiles separate early from late stage on an independent dataset?",
                   "Synthetic data were generated with planted effects so the workflow can be shown end to end.",
                   "Demonstration", "GENERAL", uid, "INTERNAL", "ANALYSIS", uid, 1, t, t))
        c.execute("INSERT INTO project_members VALUES (?,?,?,?,?,?)", (pid, uid, "OWNER", '["CONCEPTUALIZATION","ANALYSIS"]', uid, t))

        def upload(name, domain, data, fname):
            did = dbm.new_id()
            c.execute("INSERT INTO datasets (id, project_id, name, description, domain, privacy, is_synthetic, created_by_id, created_at)"
                      " VALUES (?,?,?,?,?,?,?,?,?)", (did, pid, name, "DEMONSTRATION DATA (synthetic, fixed seed)", domain, "INTERNAL", 1, uid, dbm.now()))
            return store_version(c, c.execute("SELECT * FROM datasets WHERE id=?", (did,)).fetchone(), fname, data, user, "Initial upload")["id"]

        rr = upload("DEMO RR intervals (normal vs exam day)", "BIOSIGNAL", _csv(dd.biosignal_demo(12)), "demo_rr_intervals.csv")
        expr, meta = dd.omics_demo()
        eexpr, emeta = dd.omics_demo(n_samples=100, seed=99, prefix="V")
        ev = upload("DEMO expression matrix", "BIOOMICS", _csv(expr.rename_axis("gene"), True), "demo_expression.csv")
        mv = upload("DEMO sample metadata", "BIOOMICS", _csv(meta), "demo_metadata.csv")
        xv = upload("DEMO independent expression (external)", "BIOOMICS", _csv(eexpr.rename_axis("gene"), True), "demo_external_expression.csv")
        xm = upload("DEMO independent metadata (external)", "BIOOMICS", _csv(emeta), "demo_external_metadata.csv")
        gs = upload("DEMO gene sets", "BIOOMICS", dd.gene_sets_demo().encode(), "demo_gene_sets.gmt")
        base = {"qc": {"min_rr": 300.0, "max_rr": 2000.0, "max_rel_change": 0.2, "local_window": 5},
                "frequency": {"min_duration_s": 120.0, "max_excluded_fraction": 0.05, "fs_interp": 4.0},
                "preprocess": {"max_missing": 0.2, "log2_transform": False, "drop_zero_variance": True, "duplicate_policy": "mean"}}
        exps = [
            (rr, "BIOSIGNAL", "DEMO HRV: normal day vs exam day", "hrv_workflow", 7,
             {**base, "demo": True, "random_seed": 7, "window_s": 60, "compare": ["NORMAL_DAY", "EXAM_DAY"], "dataset_id": rr,
              "ml": {"algorithms": ["LOGISTIC_REGRESSION", "RANDOM_FOREST", "XGBOOST"], "positive_class": "EXAM_DAY",
                     "resampling": "NONE", "cv_folds": 3, "test_size": 0.25, "select_k_best": None, "params": {}}}),
            (ev, "BIOOMICS", "DEMO omics: early vs late stage with external validation", "omics_workflow", 42,
             {**base, "demo": True, "random_seed": 42, "metadata_version_id": mv, "sample_column": "sample_id", "group_column": "stage",
              "positive_class": "LATE", "negative_class": "EARLY", "gene_sets_version_id": gs,
              "network": {"method": "spearman", "threshold": 0.4, "alpha": 0.05, "hub_quantile": 0.9},
              "external_expression_version_id": xv, "external_metadata_version_id": xm, "dataset_id": ev, "external_dataset_id": xv,
              "ml": {"algorithms": ["LOGISTIC_REGRESSION", "SVM", "RANDOM_FOREST", "XGBOOST"], "resampling": "SMOTE",
                     "cv_folds": 5, "test_size": 0.2, "select_k_best": 30, "params": {}}}),
        ]
        ids = []
        for vid, plat, name, atype, seed, params in exps:
            eid = dbm.new_id(); ids.append(eid)
            c.execute("INSERT INTO experiments (id, project_id, dataset_version_id, researcher_id, name, platform, analysis_type, status,"
                      " parameters, random_seed, code_version, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                      (eid, pid, vid, uid, name, plat, atype, "QUEUED", json.dumps(params), seed, _code_version(), dbm.now()))
            c.execute("INSERT INTO audit_logs (occurred_at, actor_id, organization_id, project_id, action, resource_type, resource_id, details)"
                      " VALUES (?,?,?,?,?,?,?,?)", (dbm.now(), uid, org, pid, "experiment.run", "experiment", eid, json.dumps({"demo": True})))
        c.execute("INSERT INTO tasks (id, project_id, title, status, created_by_id, created_at) VALUES (?,?,?,?,?,?)",
                  (dbm.new_id(), pid, "Replace demonstration data with a real, consented dataset", "TODO", uid, dbm.now()))
        c.execute("INSERT INTO comments VALUES (?,?,?,?,?,?,?,?,?)", (dbm.new_id(), pid, uid, "PROJECT", pid, None,
                  "All datasets in this project are synthetic. Results illustrate the workflow and are not research findings.", 0, dbm.now()))
        c.execute("COMMIT")
        for eid in ids:
            jobs.put(eid)
    finally:
        c.close()
