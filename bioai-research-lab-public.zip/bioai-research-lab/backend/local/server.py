"""BioAI Research Lab: local mode server.

Runs without Docker, PostgreSQL, Redis, MinIO or internet access. Implements the same /api/v1 contract as the
FastAPI service using SQLite, local file storage and a background worker thread, and serves the built frontend.
Scientific engines, report builder, copilot, upload validation, permissions and password hashing are the same
modules used by the full stack.
"""
from __future__ import annotations

import io
import json
import mimetypes
import os
import pathlib
import queue
import re
import sqlite3
import sys
import threading
import traceback
from datetime import datetime, timedelta, timezone
from email.parser import BytesParser
from email.policy import default as email_policy
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

BACKEND = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND))

import pandas as pd  # noqa: E402

from app.core import security as sec  # noqa: E402
from app.science.common import ScienceError, _code_version, clean  # noqa: E402
from app.science.copilot import copilot  # noqa: E402
from app.services.permissions import ORG_LEVEL_ROLES, can, can_create_project  # noqa: E402
from app.services.storage import LocalStorage  # noqa: E402
from app.services.uploads import UploadRejected, validate_upload  # noqa: E402
from local import db as dbm  # noqa: E402

VERSION = "0.4.0-local"


class Config:
    def __init__(self, data_dir: pathlib.Path):
        self.data_dir = data_dir
        data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = str(data_dir / "bioai.sqlite3")
        self.storage = LocalStorage(str(data_dir / "storage"))
        self.secret_key = self._secret("SECRET_KEY", ".secret_key")
        self.pseudonym_secret = self._secret("PSEUDONYM_SECRET", ".pseudonym_secret")
        self.max_upload = int(os.environ.get("MAX_UPLOAD_MB", "200")) * 1_000_000
        dev = os.environ.get("ENVIRONMENT", "development") == "development"
        # No email is sent by this server. Verification links may be shown on screen (low risk: they only confirm
        # an address), but password-reset links are shown only in development: on a public server that would let
        # anyone reset anyone's password.
        self.show_verification_links = os.environ.get("SHOW_VERIFICATION_LINKS", "true" if dev else "false") == "true"
        self.show_reset_links = dev and os.environ.get("SHOW_RESET_LINKS", "true") == "true"
        self.trust_proxy = os.environ.get("TRUST_PROXY", "false") == "true"
        self.demo = os.environ.get("LOAD_DEMO", "true") == "true"
        self.static_dir = pathlib.Path(os.environ.get("FRONTEND_DIST", BACKEND.parent / "frontend" / "dist-local"))

    def _secret(self, env: str, fname: str) -> str:
        """Use the environment if set, otherwise a random per-installation secret stored in the data directory."""
        if os.environ.get(env):
            return os.environ[env]
        f = self.data_dir / fname
        if not f.exists():
            import secrets
            f.write_text(secrets.token_urlsafe(48))
            f.chmod(0o600)
        return f.read_text().strip()


CFG: Config
JOBS: "queue.Queue[str]" = queue.Queue()
DEMO_EMAIL, DEMO_PASSWORD = "demo@bioai.local", "Demo-Research-2026"


class ApiError(Exception):
    def __init__(self, status: int, detail):
        self.status, self.detail = status, detail


def conn() -> sqlite3.Connection:
    return dbm.connect(CFG.db_path)


def row(r) -> dict | None:
    return dict(r) if r is not None else None


def j(v, default=None):
    return json.loads(v) if v else default


def audit(c, user, action, rtype, rid=None, project_id=None, ip=None, **details):
    safe = {k: v for k, v in details.items() if k not in ("participant_id", "password", "token")}
    c.execute("INSERT INTO audit_logs (occurred_at, actor_id, organization_id, project_id, action, resource_type, resource_id,"
              " ip_address, details) VALUES (?,?,?,?,?,?,?,?,?)",
              (dbm.now(), user["id"] if user else None, user["organization_id"] if user else None, project_id, action,
               rtype, str(rid) if rid else None, ip, json.dumps(clean(safe), default=str)))


# ------------------------------------------------------------------ validation helpers
def need(body: dict, key: str, typ=str, min_len: int = 0, max_len: int = 100000, choices=None, optional=False):
    v = body.get(key)
    if v is None or v == "":
        if optional:
            return None
        raise ApiError(422, f"{key}: field required")
    if typ is str:
        v = str(v)
        if not (min_len <= len(v) <= max_len):
            raise ApiError(422, f"{key}: length must be between {min_len} and {max_len}")
    elif typ in (int, float):
        try:
            v = typ(v)
        except (TypeError, ValueError):
            raise ApiError(422, f"{key}: must be a number")
    elif typ is bool:
        v = v in (True, "true", "1", 1, "on")
    if choices and v not in choices:
        raise ApiError(422, f"{key}: must be one of {', '.join(choices)}")
    return v


def only(body: dict, allowed: set, where: str):
    extra = set(body) - allowed
    if extra:
        raise ApiError(422, f"{where}: unknown field(s) {', '.join(sorted(extra))}")


# ------------------------------------------------------------------ auth
def user_by_email(c, email):
    return row(c.execute("SELECT u.*, r.name AS role FROM users u JOIN roles r ON r.id=u.role_id WHERE lower(u.email)=lower(?)",
                         (email,)).fetchone())


def user_by_id(c, uid):
    return row(c.execute("SELECT u.*, r.name AS role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?", (uid,)).fetchone())


def user_out(u):
    return {"id": u["id"], "email": u["email"], "display_name": u["display_name"], "role": u["role"],
            "organization_id": u["organization_id"], "email_verified": u["email_verified_at"] is not None,
            "is_demo": u["email"] == DEMO_EMAIL}


def tokens_for(u):
    return {"access_token": sec.create_token(u["id"], "access", CFG.secret_key, timedelta(minutes=30), role=u["role"]),
            "refresh_token": sec.create_token(u["id"], "refresh", CFG.secret_key, timedelta(days=7)), "token_type": "bearer"}


def issue_token(c, uid, purpose, hours):
    token, digest = sec.new_one_time_token()
    c.execute("INSERT INTO user_tokens VALUES (?,?,?,?,?,?,?)", (dbm.new_id(), uid, purpose, digest,
              (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat(), None, dbm.now()))
    return token


def consume_token(c, token, purpose):
    r = c.execute("SELECT * FROM user_tokens WHERE token_hash=? AND purpose=?", (sec.hash_one_time_token(token), purpose)).fetchone()
    if r is None or r["used_at"] or datetime.fromisoformat(r["expires_at"]) < datetime.now(timezone.utc):
        raise ApiError(400, "Invalid or expired token")
    c.execute("UPDATE user_tokens SET used_at=? WHERE id=?", (dbm.now(), r["id"]))
    return user_by_id(c, r["user_id"])


def create_user(c, email, password, display_name, role="RESEARCHER", verified=False):
    org = c.execute("SELECT id FROM organizations WHERE slug='bioai-research-lab'").fetchone()["id"]
    rid = c.execute("SELECT id FROM roles WHERE name=?", (role,)).fetchone()["id"]
    uid = dbm.new_id()
    c.execute("INSERT INTO users (id,email,password_hash,display_name,organization_id,role_id,email_verified_at,created_at)"
              " VALUES (?,?,?,?,?,?,?,?)", (uid, email.lower(), sec.hash_password(password), display_name, org, rid,
                                           dbm.now() if verified else None, dbm.now()))
    return user_by_id(c, uid)


def r_register(ctx):
    b = ctx.json
    email = need(b, "email", str, 3, 320).strip()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        raise ApiError(422, "email: not a valid email address")
    pw = need(b, "password", str, 12, 256)
    try:
        sec.validate_password_strength(pw, email)
    except ValueError as exc:
        raise ApiError(422, str(exc))
    c = ctx.db
    if user_by_email(c, email):
        raise ApiError(409, "An account with this email already exists")
    u = create_user(c, email, pw, need(b, "display_name", str, 0, 200, optional=True))
    token = issue_token(c, u["id"], "VERIFY_EMAIL", 48)
    audit(c, u, "user.register", "user", u["id"], ip=ctx.ip)
    out = {"user": user_out(u), "message": "Account created. Verify your email before signing in."}
    if CFG.show_verification_links:
        out["verification_token"] = token
    return 201, out


def r_verify(ctx):
    u = consume_token(ctx.db, need(ctx.json, "token", str, 10, 200), "VERIFY_EMAIL")
    ctx.db.execute("UPDATE users SET email_verified_at=? WHERE id=?", (dbm.now(), u["id"]))
    audit(ctx.db, u, "user.verify_email", "user", u["id"], ip=ctx.ip)
    return 200, {"verified": True}


def r_login(ctx):
    email, pw = need(ctx.json, "email", str, 3, 320), need(ctx.json, "password", str, 1, 256)
    u = user_by_email(ctx.db, email)
    if u is None or not sec.verify_password(pw, u["password_hash"]) or not u["is_active"] or u["deleted_at"]:
        audit(ctx.db, None, "user.login_failed", "user", ip=ctx.ip)
        raise ApiError(401, "Incorrect email or password")
    if not u["email_verified_at"]:
        raise ApiError(403, "Verify your email before signing in")
    ctx.db.execute("UPDATE users SET last_login_at=? WHERE id=?", (dbm.now(), u["id"]))
    audit(ctx.db, u, "user.login", "user", u["id"], ip=ctx.ip)
    return 200, tokens_for(u)


def r_demo_login(ctx):
    """Signs in to the public demonstration account (synthetic data only). Disabled when LOAD_DEMO=false."""
    if not CFG.demo:
        raise ApiError(404, "Demo mode is disabled")
    u = user_by_email(ctx.db, DEMO_EMAIL)
    if u is None:
        raise ApiError(503, "Demo is still being prepared; try again in a moment")
    audit(ctx.db, u, "user.demo_login", "user", u["id"], ip=ctx.ip)
    return 200, tokens_for(u)


def r_refresh(ctx):
    try:
        p = sec.decode_token(need(ctx.json, "refresh_token", str, 10, 4000), CFG.secret_key, "refresh")
    except sec.AuthError as exc:
        raise ApiError(401, str(exc))
    u = user_by_id(ctx.db, p["sub"])
    if u is None or not u["is_active"]:
        raise ApiError(401, "Account not active")
    return 200, tokens_for(u)


def r_reset_request(ctx):
    u = user_by_email(ctx.db, need(ctx.json, "email", str, 3, 320))
    if not CFG.show_reset_links:
        return 202, {"message": "Password reset by email is not available on this server because it does not send email. "
                                "Please contact the site administrator to reset your password."}
    out = {"message": "If the account exists, a reset link has been issued."}
    if u and u["email"] != DEMO_EMAIL:
        tok = issue_token(ctx.db, u["id"], "RESET_PASSWORD", 1)
        audit(ctx.db, u, "user.password_reset_requested", "user", u["id"], ip=ctx.ip)
        out["reset_token"] = tok
    return 202, out


def r_reset_confirm(ctx):
    u = consume_token(ctx.db, need(ctx.json, "token", str, 10, 200), "RESET_PASSWORD")
    pw = need(ctx.json, "new_password", str, 12, 256)
    try:
        sec.validate_password_strength(pw, u["email"])
    except ValueError as exc:
        raise ApiError(422, str(exc))
    ctx.db.execute("UPDATE users SET password_hash=? WHERE id=?", (sec.hash_password(pw), u["id"]))
    audit(ctx.db, u, "user.password_reset", "user", u["id"], ip=ctx.ip)
    return 200, {"reset": True}


def r_me(ctx):
    return 200, user_out(ctx.user)


def r_update_me(ctx):
    only(ctx.json, {"display_name"}, "profile")
    name = need(ctx.json, "display_name", str, 0, 200, optional=True)
    ctx.db.execute("UPDATE users SET display_name=? WHERE id=?", (name, ctx.user["id"]))
    return 200, user_out(user_by_id(ctx.db, ctx.user["id"]))


# ------------------------------------------------------------------ projects & access
class Access:
    def __init__(self, project, user, role):
        self.project, self.user, self.role = project, user, role

    def allowed(self, action):
        return can(action, org_role=self.user["role"], same_org=self.user["organization_id"] == self.project["organization_id"],
                   project_role=self.role, project_privacy=self.project["privacy"])

    def require(self, action):
        if not self.allowed(action):
            if not self.allowed("project.read"):
                raise ApiError(404, "Project not found")
            raise ApiError(403, f"Your role does not allow '{action}' on this project")
        return self


def access(ctx, pid) -> Access:
    p = row(ctx.db.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone())
    if p is None:
        raise ApiError(404, "Project not found")
    m = ctx.db.execute("SELECT project_role FROM project_members WHERE project_id=? AND user_id=?", (pid, ctx.user["id"])).fetchone()
    return Access(p, ctx.user, m["project_role"] if m else None).require("project.read")


def project_out(p, role):
    return {k: p[k] for k in ("id", "name", "research_question", "hypothesis", "research_area", "description", "platform",
                              "privacy", "status", "team_id", "principal_researcher_id", "start_date",
                              "target_completion_date", "created_at", "updated_at")} | {
        "archived": p["archived_at"] is not None, "my_role": role, "is_demo": bool(p["is_demo"])}


PLATFORMS, PRIVACY = ("BIOSIGNAL", "BIOOMICS", "GENERAL"), ("PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED_HUMAN_DATA")
STATUSES = ("IDEA", "PLANNING", "DATA_COLLECTION", "ANALYSIS", "VALIDATION", "MANUSCRIPT", "SUBMITTED", "PUBLISHED", "ARCHIVED")


def r_create_project(ctx):
    b, u = ctx.json, ctx.user
    if not can_create_project(u["role"]):
        raise ApiError(403, "Your role cannot create projects")
    only(b, {"name", "research_question", "hypothesis", "research_area", "description", "platform", "privacy", "team_id",
             "start_date", "target_completion_date"}, "project")
    p = {"name": need(b, "name", str, 3, 300), "research_question": need(b, "research_question", str, 5),
         "hypothesis": need(b, "hypothesis", str, optional=True), "research_area": need(b, "research_area", str, 0, 200, optional=True),
         "description": need(b, "description", str, optional=True), "platform": need(b, "platform", str, choices=PLATFORMS),
         "privacy": need(b, "privacy", str, choices=PRIVACY, optional=True) or "INTERNAL", "team_id": b.get("team_id") or None,
         "start_date": b.get("start_date") or None, "target_completion_date": b.get("target_completion_date") or None}
    if p["team_id"] and not ctx.db.execute("SELECT 1 FROM teams WHERE id=? AND organization_id=?", (p["team_id"], u["organization_id"])).fetchone():
        raise ApiError(422, "team_id: team not found in your organization")
    pid, t = dbm.new_id(), dbm.now()
    try:
        ctx.db.execute("INSERT INTO projects (id, organization_id, name, research_question, hypothesis, research_area, description,"
                       " platform, principal_researcher_id, team_id, privacy, start_date, target_completion_date, created_by_id,"
                       " created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (pid, u["organization_id"], p["name"], p["research_question"], p["hypothesis"], p["research_area"],
                        p["description"], p["platform"], u["id"], p["team_id"], p["privacy"], p["start_date"],
                        p["target_completion_date"], u["id"], t, t))
    except sqlite3.IntegrityError as exc:
        raise ApiError(409 if "UNIQUE" in str(exc) else 422,
                       "A project with this name already exists" if "UNIQUE" in str(exc) else "Target completion date is before start date")
    ctx.db.execute("INSERT INTO project_members VALUES (?,?,?,?,?,?)", (pid, u["id"], "OWNER", '["CONCEPTUALIZATION"]', u["id"], t))
    audit(ctx.db, u, "project.create", "project", pid, pid, ctx.ip)
    return 201, project_out(row(ctx.db.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()), "OWNER")


def r_list_projects(ctx):
    u = ctx.user
    roles = {r["project_id"]: r["project_role"] for r in ctx.db.execute("SELECT project_id, project_role FROM project_members WHERE user_id=?", (u["id"],))}
    q, args = "SELECT * FROM projects WHERE privacy='PUBLIC' OR id IN (SELECT project_id FROM project_members WHERE user_id=?)", [u["id"]]
    if u["role"] in ORG_LEVEL_ROLES:
        q, args = "SELECT * FROM projects WHERE privacy='PUBLIC' OR organization_id=?", [u["organization_id"]]
    st = ctx.query.get("status")
    if st:
        q, args = f"SELECT * FROM ({q}) WHERE status=?", args + [st]
    return 200, [project_out(dict(p), roles.get(p["id"])) for p in ctx.db.execute(q + " ORDER BY updated_at DESC", args)]


def r_get_project(ctx, pid):
    a = access(ctx, pid)
    return 200, project_out(a.project, a.role)


def r_update_project(ctx, pid):
    a = access(ctx, pid).require("project.update")
    only(ctx.json, {"research_question", "hypothesis", "description", "status", "privacy", "target_completion_date"}, "project")
    ch = dict(ctx.json)
    if "status" in ch:
        need(ch, "status", str, choices=STATUSES)
        if ch["status"] == "ARCHIVED":
            a.require("project.archive")
            ch["archived_at"] = dbm.now()
    if "privacy" in ch:
        need(ch, "privacy", str, choices=PRIVACY)
    if ch:
        ctx.db.execute(f"UPDATE projects SET {', '.join(f'{k}=?' for k in ch)}, updated_at=? WHERE id=?", [*ch.values(), dbm.now(), pid])
    audit(ctx.db, ctx.user, "project.update", "project", pid, pid, ctx.ip, fields=sorted(ctx.json))
    return 200, project_out(row(ctx.db.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone()), a.role)


def uname(u):
    return u["display_name"] or u["email"].split("@")[0]


def r_members(ctx, pid):
    access(ctx, pid)
    rs = ctx.db.execute("SELECT m.*, u.display_name, u.email FROM project_members m JOIN users u ON u.id=m.user_id WHERE project_id=?", (pid,))
    return 200, [{"user_id": r["user_id"], "display_name": uname(r), "project_role": r["project_role"],
                  "contributions": j(r["contributions"], [])} for r in rs]


CONTRIB = ("CONCEPTUALIZATION", "DATA_COLLECTION", "DATA_CURATION", "SOFTWARE", "METHODOLOGY", "ANALYSIS", "VISUALIZATION",
           "SUPERVISION", "WRITING")


def r_add_member(ctx, pid):
    a = access(ctx, pid).require("member.manage")
    role = need(ctx.json, "project_role", str, choices=("OWNER", "LEAD", "CONTRIBUTOR", "REVIEWER", "VIEWER"))
    contribs = ctx.json.get("contributions") or []
    if not isinstance(contribs, list) or any(c not in CONTRIB for c in contribs):
        raise ApiError(422, "contributions: invalid value")
    t = user_by_email(ctx.db, need(ctx.json, "email", str, 3, 320))
    if t is None or t["organization_id"] != a.project["organization_id"]:
        raise ApiError(404, "No researcher with that email in this organization")
    ctx.db.execute("INSERT INTO project_members VALUES (?,?,?,?,?,?) ON CONFLICT(project_id, user_id) DO UPDATE SET "
                   "project_role=excluded.project_role, contributions=excluded.contributions",
                   (pid, t["id"], role, json.dumps(contribs), ctx.user["id"], dbm.now()))
    audit(ctx.db, ctx.user, "project.member_set", "project", pid, pid, ctx.ip, member=t["id"], project_role=role)
    return 201, {"user_id": t["id"], "project_role": role, "contributions": contribs}


def r_create_team(ctx):
    if not can_create_project(ctx.user["role"]):
        raise ApiError(403, "Your role cannot create teams")
    b = ctx.json
    disc = need(b, "discipline", str, optional=True, choices=("BIOMEDICAL_SCIENCE", "BIOINFORMATICS", "AI_ML", "STATISTICS", "SOFTWARE_ENGINEERING"))
    tid = dbm.new_id()
    try:
        ctx.db.execute("INSERT INTO teams VALUES (?,?,?,?,?,?)", (tid, ctx.user["organization_id"], need(b, "name", str, 2, 200), disc,
                       need(b, "description", str, optional=True), dbm.now()))
    except sqlite3.IntegrityError:
        raise ApiError(409, "A team with this name already exists")
    ctx.db.execute("INSERT INTO team_members VALUES (?,?,?)", (tid, ctx.user["id"], dbm.now()))
    audit(ctx.db, ctx.user, "team.create", "team", tid, ip=ctx.ip)
    return 201, {"id": tid, "name": b["name"], "discipline": disc}


def r_list_teams(ctx):
    out = []
    for t in ctx.db.execute("SELECT * FROM teams WHERE organization_id=? ORDER BY name", (ctx.user["organization_id"],)).fetchall():
        ms = ctx.db.execute("SELECT u.id, u.display_name, u.email FROM team_members m JOIN users u ON u.id=m.user_id WHERE team_id=?", (t["id"],))
        out.append({"id": t["id"], "name": t["name"], "discipline": t["discipline"], "description": t["description"],
                    "members": [{"user_id": m["id"], "display_name": uname(m)} for m in ms]})
    return 200, out


def r_add_team_member(ctx, tid):
    t = ctx.db.execute("SELECT * FROM teams WHERE id=?", (tid,)).fetchone()
    if t is None or t["organization_id"] != ctx.user["organization_id"]:
        raise ApiError(404, "Team not found")
    if not ctx.db.execute("SELECT 1 FROM team_members WHERE team_id=? AND user_id=?", (tid, ctx.user["id"])).fetchone() \
            and ctx.user["role"] not in ORG_LEVEL_ROLES:
        raise ApiError(403, "Only team members can add researchers")
    target = user_by_email(ctx.db, need(ctx.json, "email", str, 3, 320))
    if target is None or target["organization_id"] != ctx.user["organization_id"]:
        raise ApiError(404, "No researcher with that email in this organization")
    ctx.db.execute("INSERT OR IGNORE INTO team_members VALUES (?,?,?)", (tid, target["id"], dbm.now()))
    audit(ctx.db, ctx.user, "team.member_add", "team", tid, ip=ctx.ip, member=target["id"])
    return 201, {"team_id": tid, "user_id": target["id"]}


TASK_ST = ("TODO", "IN_PROGRESS", "IN_REVIEW", "DONE")


def task_out(t):
    return {k: t[k] for k in ("id", "title", "description", "status", "assignee_id", "due_date", "contribution_category")}


def r_tasks(ctx, pid):
    access(ctx, pid)
    return 200, [task_out(t) for t in ctx.db.execute("SELECT * FROM tasks WHERE project_id=? ORDER BY created_at", (pid,))]


def r_create_task(ctx, pid):
    access(ctx, pid).require("task.manage")
    tid = dbm.new_id()
    ctx.db.execute("INSERT INTO tasks (id, project_id, title, description, status, created_by_id, due_date, created_at) VALUES (?,?,?,?,?,?,?,?)",
                   (tid, pid, need(ctx.json, "title", str, 2, 300), need(ctx.json, "description", str, optional=True),
                    need(ctx.json, "status", str, choices=TASK_ST, optional=True) or "TODO", ctx.user["id"],
                    ctx.json.get("due_date") or None, dbm.now()))
    audit(ctx.db, ctx.user, "task.create", "task", tid, pid, ctx.ip)
    return 201, task_out(ctx.db.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone())


def r_update_task(ctx, pid, tid):
    access(ctx, pid).require("task.manage")
    st = need(ctx.json, "status", str, choices=TASK_ST)
    if ctx.db.execute("UPDATE tasks SET status=? WHERE id=? AND project_id=?", (st, tid, pid)).rowcount == 0:
        raise ApiError(404, "Task not found")
    return 200, {"id": tid, "status": st}


def r_comments(ctx, pid):
    access(ctx, pid).require("comment.read")
    q, args = "SELECT c.*, u.display_name, u.email FROM comments c LEFT JOIN users u ON u.id=c.author_id WHERE c.project_id=?", [pid]
    for k in ("target_type", "target_id"):
        if ctx.query.get(k):
            q += f" AND c.{k}=?"; args.append(ctx.query[k])
    return 200, [{"id": c["id"], "author": uname(c) if c["email"] else "former member", "target_type": c["target_type"],
                  "target_id": c["target_id"], "body": c["body"], "parent_id": c["parent_id"], "resolved": bool(c["resolved"]),
                  "created_at": c["created_at"]} for c in ctx.db.execute(q + " ORDER BY c.created_at", args)]


def r_create_comment(ctx, pid):
    access(ctx, pid).require("comment.create")
    cid = dbm.new_id()
    ctx.db.execute("INSERT INTO comments VALUES (?,?,?,?,?,?,?,?,?)", (cid, pid, ctx.user["id"],
                   need(ctx.json, "target_type", str, choices=("PROJECT", "DATASET", "EXPERIMENT", "REPORT", "TASK", "PUBLICATION")),
                   need(ctx.json, "target_id", str, 1, 64), ctx.json.get("parent_id"), need(ctx.json, "body", str, 1, 10000), 0, dbm.now()))
    audit(ctx.db, ctx.user, "comment.create", "comment", cid, pid, ctx.ip)
    return 201, {"id": cid}


def r_audit(ctx, pid):
    access(ctx, pid).require("audit.read")
    lim = min(int(ctx.query.get("limit", 200)), 1000)
    rs = ctx.db.execute("SELECT a.*, u.display_name, u.email FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id "
                        "WHERE a.project_id=? ORDER BY a.id DESC LIMIT ?", (pid, lim))
    return 200, [{"id": a["id"], "when": a["occurred_at"], "who": uname(a) if a["email"] else "system", "action": a["action"],
                  "resource_type": a["resource_type"], "resource_id": a["resource_id"], "details": j(a["details"], {})} for a in rs]


# ------------------------------------------------------------------ datasets
def version_out(v):
    return {"id": v["id"], "version": v["version"], "file_type": v["file_type"], "size_bytes": v["size_bytes"], "sha256": v["sha256"],
            "n_rows": v["n_rows"], "n_columns": v["n_columns"], "columns": j(v["column_schema"], {}),
            "validation_status": v["validation_status"], "validation_report": j(v["validation_report"], {}),
            "original_filename": v["original_filename"], "change_note": v["change_note"], "created_at": v["created_at"]}


def dataset_out(c, d):
    vs = c.execute("SELECT * FROM dataset_versions WHERE dataset_id=? ORDER BY version", (d["id"],)).fetchall()
    return {"id": d["id"], "project_id": d["project_id"], "name": d["name"], "description": d["description"], "domain": d["domain"],
            "privacy": d["privacy"], "status": d["status"], "is_synthetic": bool(d["is_synthetic"]), "created_at": d["created_at"],
            "versions": [version_out(v) for v in vs]}


def store_version(c, d, filename, data, user, note):
    try:
        info = validate_upload(filename, data, max_bytes=CFG.max_upload)
    except UploadRejected as exc:
        raise ApiError(422, str(exc))
    last = c.execute("SELECT COALESCE(MAX(version),0) FROM dataset_versions WHERE dataset_id=?", (d["id"],)).fetchone()[0]
    key = f"datasets/{d['project_id']}/{d['id']}/v{last + 1}-{info.sha256[:12]}-{info.safe_filename}"
    CFG.storage.put(key, data)
    vid = dbm.new_id()
    c.execute("INSERT INTO dataset_versions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
              (vid, d["id"], last + 1, key, info.safe_filename, info.file_type, info.size_bytes, info.sha256, info.n_rows,
               info.n_columns, json.dumps(info.column_schema), "PASSED_WITH_WARNINGS" if info.warnings else "PASSED",
               json.dumps({"warnings": info.warnings, "delimiter": info.delimiter, "columns": info.columns}), note,
               user["id"], dbm.now()))
    return c.execute("SELECT * FROM dataset_versions WHERE id=?", (vid,)).fetchone()


def r_upload(ctx, pid):
    access(ctx, pid).require("dataset.upload")
    f = ctx.form
    if "file" not in f.files:
        raise ApiError(422, "file: field required")
    fname, data = f.files["file"]
    did = dbm.new_id()
    try:
        ctx.db.execute("INSERT INTO datasets (id, project_id, name, description, domain, privacy, is_synthetic, created_by_id, created_at)"
                       " VALUES (?,?,?,?,?,?,?,?,?)", (did, pid, need(f.fields, "name", str, 2, 300),
                       need(f.fields, "description", str, optional=True), need(f.fields, "domain", str, choices=PLATFORMS),
                       need(f.fields, "privacy", str, choices=PRIVACY, optional=True) or "INTERNAL",
                       int(need(f.fields, "is_synthetic", bool, optional=True) or False), ctx.user["id"], dbm.now()))
    except sqlite3.IntegrityError:
        raise ApiError(409, "A dataset with this name exists; upload a new version")
    d = ctx.db.execute("SELECT * FROM datasets WHERE id=?", (did,)).fetchone()
    v = store_version(ctx.db, d, fname, data, ctx.user, "Initial upload")
    audit(ctx.db, ctx.user, "dataset.upload", "dataset_version", v["id"], pid, ctx.ip, dataset_id=did, version=1, sha256=v["sha256"])
    return 201, dataset_out(ctx.db, d)


def r_upload_version(ctx, pid, did):
    access(ctx, pid).require("dataset.upload")
    d = ctx.db.execute("SELECT * FROM datasets WHERE id=? AND project_id=? AND status='ACTIVE'", (did, pid)).fetchone()
    if d is None:
        raise ApiError(404, "Dataset not found")
    if "file" not in ctx.form.files:
        raise ApiError(422, "file: field required")
    fname, data = ctx.form.files["file"]
    v = store_version(ctx.db, d, fname, data, ctx.user, need(ctx.form.fields, "change_note", str, 3, 2000))
    audit(ctx.db, ctx.user, "dataset.version", "dataset_version", v["id"], pid, ctx.ip, dataset_id=did, version=v["version"])
    return 201, version_out(v)


def r_list_datasets(ctx, pid):
    access(ctx, pid).require("dataset.read")
    return 200, [dataset_out(ctx.db, d) for d in ctx.db.execute(
        "SELECT * FROM datasets WHERE project_id=? AND status<>'DELETED' ORDER BY created_at", (pid,)).fetchall()]


def get_version(c, pid, vid):
    v = c.execute("SELECT v.* FROM dataset_versions v JOIN datasets d ON d.id=v.dataset_id WHERE v.id=? AND d.project_id=?", (vid, pid)).fetchone()
    if v is None:
        raise ApiError(404, "Dataset version not found")
    return v


def read_version(v, nrows=None) -> pd.DataFrame:
    raw = CFG.storage.get(v["storage_key"])
    rep = j(v["validation_report"], {})
    sep = {"CSV": ",", "TSV": "\t"}.get(v["file_type"]) or rep.get("delimiter")
    if sep is None:
        cols = rep.get("columns") or ["column_1"]
        has_header = cols[0] != "column_1"
        return pd.read_csv(io.BytesIO(raw), header=0 if has_header else None, names=None if has_header else ["column_1"], nrows=nrows)
    return pd.read_csv(io.BytesIO(raw), sep=sep, nrows=nrows)


def r_preview(ctx, pid, vid):
    access(ctx, pid).require("dataset.read")
    v = get_version(ctx.db, pid, vid)
    if (j(v["column_schema"], {}) or {}).get("format") == "GMT":
        lines = CFG.storage.get(v["storage_key"]).decode().splitlines()[:20]
        return 200, {"columns": ["gene_set", "description", "genes"], "total_rows": v["n_rows"],
                     "rows": [[p[0], p[1], ", ".join(p[2:12]) + (" ..." if len(p) > 12 else "")] for p in (ln.split("\t") for ln in lines)]}
    df = read_version(v, nrows=min(max(int(ctx.query.get("rows", 20)), 1), 200))
    df = df.iloc[:, :30]
    return 200, {"columns": list(map(str, df.columns)), "rows": json.loads(df.to_json(orient="values")), "total_rows": v["n_rows"]}


def r_download(ctx, pid, vid):
    access(ctx, pid).require("dataset.download")
    v = get_version(ctx.db, pid, vid)
    audit(ctx.db, ctx.user, "dataset.download", "dataset_version", vid, pid, ctx.ip)
    return 200, Raw(CFG.storage.get(v["storage_key"]), "text/plain", f'attachment; filename="{v["original_filename"]}"')


def r_archive(ctx, pid, did):
    access(ctx, pid).require("dataset.archive")
    if ctx.db.execute("UPDATE datasets SET status='ARCHIVED', archived_at=? WHERE id=? AND project_id=?", (dbm.now(), did, pid)).rowcount == 0:
        raise ApiError(404, "Dataset not found")
    audit(ctx.db, ctx.user, "dataset.archive", "dataset", did, pid, ctx.ip)
    return 200, {"archived": True}


class Raw:
    def __init__(self, data: bytes, ctype: str, disposition: str | None = None):
        self.data, self.ctype, self.disposition = data, ctype, disposition


# ------------------------------------------------------------------ experiments
ALGOS = ("LOGISTIC_REGRESSION", "SVM", "RANDOM_FOREST", "XGBOOST")


def _num(d, k, lo, hi, default, typ=float, lo_open=False, hi_open=False):
    v = d.get(k, default)
    try:
        v = typ(v)
    except (TypeError, ValueError):
        raise ApiError(422, f"{k}: must be a number")
    if v < lo or v > hi or (lo_open and v == lo) or (hi_open and v == hi):
        raise ApiError(422, f"{k}: out of range")
    return v


def validate_options(b):
    """Same rules as the typed option models of the FastAPI service."""
    def sub(name, allowed):
        d = b.get(name) or {}
        if not isinstance(d, dict):
            raise ApiError(422, f"{name}: must be an object")
        only(d, allowed, name)
        return d
    qc = sub("qc", {"min_rr", "max_rr", "max_rel_change", "local_window"})
    fr = sub("frequency", {"min_duration_s", "max_excluded_fraction", "fs_interp"})
    pre = sub("preprocess", {"max_missing", "log2_transform", "drop_zero_variance", "duplicate_policy"})
    net = sub("network", {"method", "threshold", "alpha", "hub_quantile"})
    out = {
        "qc": {"min_rr": _num(qc, "min_rr", 200, 1000, 300.0), "max_rr": _num(qc, "max_rr", 1000, 3000, 2000.0),
               "max_rel_change": _num(qc, "max_rel_change", 0, 1, 0.2, lo_open=True), "local_window": _num(qc, "local_window", 3, 51, 5, int)},
        "frequency": {"min_duration_s": _num(fr, "min_duration_s", 120, 1e6, 120.0),
                      "max_excluded_fraction": _num(fr, "max_excluded_fraction", 0, 0.5, 0.05), "fs_interp": _num(fr, "fs_interp", 2, 10, 4.0)},
        "preprocess": {"max_missing": _num(pre, "max_missing", 0, 1, 0.2), "log2_transform": bool(pre.get("log2_transform", False)),
                       "drop_zero_variance": bool(pre.get("drop_zero_variance", True)),
                       "duplicate_policy": need({"x": pre.get("duplicate_policy", "mean")}, "x", str, choices=("mean", "error"))},
        "network": {"method": need({"x": net.get("method", "spearman")}, "x", str, choices=("spearman", "pearson")),
                    "threshold": _num(net, "threshold", 0, 1, 0.5, lo_open=True, hi_open=True), "alpha": _num(net, "alpha", 0, 0.2, 0.05, lo_open=True),
                    "hub_quantile": _num(net, "hub_quantile", 0, 1, 0.9, lo_open=True, hi_open=True)},
    }
    ml = b.get("ml")
    if ml is not None:
        if not isinstance(ml, dict):
            raise ApiError(422, "ml: must be an object")
        only(ml, {"algorithms", "positive_class", "resampling", "cv_folds", "test_size", "select_k_best", "params"}, "ml")
        algos = ml.get("algorithms") or ["LOGISTIC_REGRESSION", "RANDOM_FOREST"]
        if not isinstance(algos, list) or not algos or any(a not in ALGOS for a in algos):
            raise ApiError(422, f"ml.algorithms: choose from {', '.join(ALGOS)}")
        ml = {"algorithms": algos, "positive_class": ml.get("positive_class"),
              "resampling": need({"x": ml.get("resampling", "NONE")}, "x", str, choices=("NONE", "CLASS_WEIGHT", "SMOTE")),
              "cv_folds": _num(ml, "cv_folds", 2, 20, 5, int), "test_size": _num(ml, "test_size", 0.05, 0.5, 0.2, lo_open=True, hi_open=True),
              "select_k_best": None if ml.get("select_k_best") in (None, "") else _num(ml, "select_k_best", 1, 1e6, None, int),
              "params": ml.get("params") or {}}
    out["ml"] = ml
    return out


EXP_FIELDS = {"name", "platform", "dataset_version_id", "random_seed", "compare", "window_s", "qc", "frequency", "metadata_version_id",
              "sample_column", "group_column", "positive_class", "negative_class", "orientation", "preprocess", "network",
              "gene_sets_version_id", "external_expression_version_id", "external_metadata_version_id", "extra_layers", "ml", "demo"}


def r_create_experiment(ctx, pid):
    access(ctx, pid).require("experiment.run")
    b = ctx.json
    only(b, EXP_FIELDS, "experiment")
    name = need(b, "name", str, 3, 300)
    platform = need(b, "platform", str, choices=("BIOSIGNAL", "BIOOMICS"))
    seed = _num(b, "random_seed", 0, 2 ** 31 - 1, 42, int)
    opts = validate_options(b)
    cfg = {"random_seed": seed, "demo": bool(b.get("demo", False)), **{k: v for k, v in opts.items() if v is not None}}
    if platform == "BIOSIGNAL":
        cmp_ = b.get("compare") or ["NORMAL_DAY", "EXAM_DAY"]
        if not isinstance(cmp_, list) or len(cmp_) != 2:
            raise ApiError(422, "compare: exactly two conditions")
        cfg["compare"] = [str(x) for x in cmp_]
        if b.get("window_s") not in (None, ""):
            cfg["window_s"] = _num(b, "window_s", 30, 3600, 60, int)
        if opts["ml"] is not None and not opts["ml"].get("positive_class"):
            raise ApiError(422, "Biosignal machine learning needs ml.positive_class (the condition to predict)")
    else:
        for k in ("metadata_version_id", "group_column", "positive_class", "negative_class"):
            cfg[k] = need(b, k, str, 1, 300)
        cfg["sample_column"] = need(b, "sample_column", str, 1, 300, optional=True) or "sample_id"
        if b.get("orientation"):
            cfg["orientation"] = need(b, "orientation", str, choices=("GENES_AS_ROWS", "SAMPLES_AS_ROWS"))
        if cfg.get("ml") is None:
            cfg["ml"] = validate_options({"ml": {}})["ml"]
    if bool(b.get("external_expression_version_id")) != bool(b.get("external_metadata_version_id")):
        raise ApiError(422, "External validation needs both an expression and a metadata dataset version")
    ids = {"dataset_version_id": need(b, "dataset_version_id", str, 1, 64)}
    for k in ("metadata_version_id", "gene_sets_version_id", "external_expression_version_id", "external_metadata_version_id"):
        if b.get(k):
            ids[k] = b[k]; cfg[k] = b[k]
    versions = {k: get_version(ctx.db, pid, v) for k, v in ids.items()}
    training = {versions[k]["dataset_id"] for k in versions if k in ("dataset_version_id", "metadata_version_id")}
    for k in ("external_expression_version_id", "external_metadata_version_id"):
        if k in versions and versions[k]["dataset_id"] in training:
            raise ApiError(422, "External validation must use a dataset that is not part of training "
                                "(a different version of a training dataset is not independent)")
    cfg["dataset_id"] = ids["dataset_version_id"]
    if "external_expression_version_id" in ids:
        cfg["external_dataset_id"] = ids["external_expression_version_id"]
    eid = dbm.new_id()
    ctx.db.execute("INSERT INTO experiments (id, project_id, dataset_version_id, researcher_id, name, platform, analysis_type, parameters,"
                   " preprocessing, feature_selection, random_seed, code_version, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (eid, pid, ids["dataset_version_id"], ctx.user["id"], name, platform,
                    "hrv_workflow" if platform == "BIOSIGNAL" else "omics_workflow", json.dumps(cfg),
                    json.dumps(cfg["qc"] if platform == "BIOSIGNAL" else cfg["preprocess"]),
                    json.dumps({"select_k_best": (cfg.get("ml") or {}).get("select_k_best")}), seed, _code_version(), dbm.now()))
    audit(ctx.db, ctx.user, "experiment.create", "experiment", eid, pid, ctx.ip, dataset_version_id=ids["dataset_version_id"])
    return 201, exp_out(get_exp(ctx.db, pid, eid))


def get_exp(c, pid, eid):
    e = c.execute("SELECT * FROM experiments WHERE id=? AND project_id=?", (eid, pid)).fetchone()
    if e is None:
        raise ApiError(404, "Experiment not found")
    return e


def exp_out(e):
    return {"id": e["id"], "project_id": e["project_id"], "name": e["name"], "platform": e["platform"], "analysis_type": e["analysis_type"],
            "status": e["status"], "dataset_version_id": e["dataset_version_id"], "parameters": j(e["parameters"], {}),
            "random_seed": e["random_seed"], "code_version": e["code_version"], "software_versions": j(e["software_versions"], {}),
            "parent_experiment_id": e["parent_experiment_id"], "error_message": e["error_message"], "created_at": e["created_at"],
            "started_at": e["started_at"], "finished_at": e["finished_at"]}


def r_run(ctx, pid, eid):
    access(ctx, pid).require("experiment.run")
    e = get_exp(ctx.db, pid, eid)
    if e["status"] in ("QUEUED", "RUNNING"):
        raise ApiError(409, "Experiment is already queued or running")
    if e["status"] == "SUCCEEDED":
        raise ApiError(409, "Results are immutable; clone the experiment to re-run it")
    ctx.db.execute("UPDATE experiments SET status='QUEUED', error_message=NULL WHERE id=?", (eid,))
    audit(ctx.db, ctx.user, "experiment.run", "experiment", eid, pid, ctx.ip, dataset_version_id=e["dataset_version_id"])
    ctx.after_commit.append(lambda: JOBS.put(eid))  # the worker must only see the job once QUEUED is committed
    return 202, exp_out(get_exp(ctx.db, pid, eid))


def r_clone(ctx, pid, eid):
    access(ctx, pid).require("experiment.clone")
    only(ctx.json, {"name", "random_seed"}, "clone")
    src = get_exp(ctx.db, pid, eid)
    seed = src["random_seed"] if ctx.json.get("random_seed") is None else _num(ctx.json, "random_seed", 0, 2 ** 31 - 1, 0, int)
    params = {**j(src["parameters"]), "random_seed": seed}
    nid = dbm.new_id()
    ctx.db.execute("INSERT INTO experiments (id, project_id, dataset_version_id, researcher_id, parent_experiment_id, name, platform,"
                   " analysis_type, parameters, preprocessing, feature_selection, random_seed, code_version, created_at)"
                   " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (nid, pid, src["dataset_version_id"], ctx.user["id"], eid,
                    (need(ctx.json, "name", str, 3, 300, optional=True) or f"{src['name']} (re-run)")[:300], src["platform"],
                    src["analysis_type"], json.dumps(params), src["preprocessing"], src["feature_selection"], seed, _code_version(), dbm.now()))
    audit(ctx.db, ctx.user, "experiment.clone", "experiment", nid, pid, ctx.ip, source=eid)
    return 201, exp_out(get_exp(ctx.db, pid, nid))


def r_list_exps(ctx, pid):
    access(ctx, pid).require("experiment.read")
    return 200, [exp_out(e) for e in ctx.db.execute("SELECT * FROM experiments WHERE project_id=? ORDER BY created_at DESC", (pid,))]


def r_get_exp(ctx, pid, eid):
    access(ctx, pid).require("experiment.read")
    return 200, exp_out(get_exp(ctx.db, pid, eid))


def results_rows(c, e):
    rows = {r["result_type"]: j(r["payload"]) for r in c.execute("SELECT * FROM experiment_results WHERE experiment_id=?", (e["id"],))}
    if "pipeline_result" not in rows:
        raise ApiError(409, f"No results yet (status {e['status']})")
    return rows


def report_row(c, pid, eid):
    return c.execute("SELECT * FROM reports WHERE experiment_id=? AND project_id=?", (eid, pid)).fetchone()


def r_results(ctx, pid, eid):
    access(ctx, pid).require("experiment.read")
    e = get_exp(ctx.db, pid, eid)
    rows = results_rows(ctx.db, e)
    rep = report_row(ctx.db, pid, eid)
    return 200, {"experiment": exp_out(e), "result": rows["pipeline_result"], "review": rows.get("review", {}).get("issues", []),
                 "report": {"id": rep["id"], "title": rep["title"], "formats": sorted(j(rep["exports"]))} if rep else None}


MEDIA = {"html": "text/html; charset=utf-8", "pdf": "application/pdf", "json": "application/json", "csv": "application/zip"}


def r_report(ctx, pid, eid, fmt):
    access(ctx, pid).require("report.read")
    rep = report_row(ctx.db, pid, eid)
    ex = j(rep["exports"]) if rep else {}
    if fmt not in ex or fmt not in MEDIA:
        raise ApiError(404, "Report format not available")
    audit(ctx.db, ctx.user, "report.download", "report", rep["id"], pid, ctx.ip, format=fmt)
    return 200, Raw(CFG.storage.get(ex[fmt]), MEDIA[fmt],
                    f'{"inline" if fmt == "html" else "attachment"}; filename="report-{eid}.{"zip" if fmt == "csv" else fmt}"')


def r_figure(ctx, pid, eid, name):
    access(ctx, pid).require("report.read")
    rep = report_row(ctx.db, pid, eid)
    key = (j(rep["exports"]) if rep else {}).get(f"figure:{name}")
    if key is None:
        raise ApiError(404, "Figure not found")
    return 200, Raw(CFG.storage.get(key), "image/png")


def r_copilot(ctx, pid, eid):
    access(ctx, pid).require("experiment.read")
    q = need(ctx.json, "question", str, 3, 2000)
    result = results_rows(ctx.db, get_exp(ctx.db, pid, eid))["pipeline_result"]
    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            out = copilot.answer(q, result)
            out["mode"] = "language_model"
        except Exception as exc:  # network unavailable etc.: fall back to evidence-only mode, and say why
            out = {"mode": "evidence_only", "answer": None, "note": "AI-written answers are temporarily unavailable. Below are "
                   "the recorded evidence and the automated review, generated directly from this experiment's results."}
    else:
        out = {"mode": "evidence_only", "answer": None,
               "note": "AI-written answers are not enabled on this server. Below are the recorded evidence and the automated review, "
                        "which are generated directly from this experiment's results."}
    out.update(evidence=copilot.evidence(result), review=copilot.review(result))
    audit(ctx.db, ctx.user, "copilot.ask", "experiment", eid, pid, ctx.ip)
    return 200, out


def r_health(ctx):
    from app.science.common import software_versions
    return 200, {"status": "ok", "version": VERSION, "mode": "local", "software": software_versions()}


# ------------------------------------------------------------------ routing
P = r"(?P<{}>[0-9a-fA-F-]{{36}})"
ROUTES = [
    ("GET", r"/health", r_health, False),
    ("POST", r"/auth/register", r_register, False), ("POST", r"/auth/verify-email", r_verify, False),
    ("POST", r"/auth/login", r_login, False), ("POST", r"/auth/demo-login", r_demo_login, False),
    ("POST", r"/auth/refresh", r_refresh, False),
    ("POST", r"/auth/password-reset/request", r_reset_request, False), ("POST", r"/auth/password-reset/confirm", r_reset_confirm, False),
    ("GET", r"/auth/me", r_me, True), ("PATCH", r"/auth/me", r_update_me, True),
    ("POST", r"/projects", r_create_project, True), ("GET", r"/projects", r_list_projects, True),
    ("GET", rf"/projects/{P.format('pid')}", r_get_project, True), ("PATCH", rf"/projects/{P.format('pid')}", r_update_project, True),
    ("GET", rf"/projects/{P.format('pid')}/members", r_members, True), ("POST", rf"/projects/{P.format('pid')}/members", r_add_member, True),
    ("POST", r"/teams", r_create_team, True), ("GET", r"/teams", r_list_teams, True),
    ("POST", rf"/teams/{P.format('tid')}/members", r_add_team_member, True),
    ("GET", rf"/projects/{P.format('pid')}/tasks", r_tasks, True), ("POST", rf"/projects/{P.format('pid')}/tasks", r_create_task, True),
    ("PATCH", rf"/projects/{P.format('pid')}/tasks/{P.format('tid')}", r_update_task, True),
    ("GET", rf"/projects/{P.format('pid')}/comments", r_comments, True), ("POST", rf"/projects/{P.format('pid')}/comments", r_create_comment, True),
    ("GET", rf"/projects/{P.format('pid')}/audit", r_audit, True),
    ("POST", rf"/projects/{P.format('pid')}/datasets", r_upload, True), ("GET", rf"/projects/{P.format('pid')}/datasets", r_list_datasets, True),
    ("POST", rf"/projects/{P.format('pid')}/datasets/{P.format('did')}/versions", r_upload_version, True),
    ("POST", rf"/projects/{P.format('pid')}/datasets/{P.format('did')}/archive", r_archive, True),
    ("GET", rf"/projects/{P.format('pid')}/dataset-versions/{P.format('vid')}/preview", r_preview, True),
    ("GET", rf"/projects/{P.format('pid')}/dataset-versions/{P.format('vid')}/download", r_download, True),
    ("POST", rf"/projects/{P.format('pid')}/experiments", r_create_experiment, True),
    ("GET", rf"/projects/{P.format('pid')}/experiments", r_list_exps, True),
    ("GET", rf"/projects/{P.format('pid')}/experiments/{P.format('eid')}", r_get_exp, True),
    ("POST", rf"/projects/{P.format('pid')}/experiments/{P.format('eid')}/run", r_run, True),
    ("POST", rf"/projects/{P.format('pid')}/experiments/{P.format('eid')}/clone", r_clone, True),
    ("GET", rf"/projects/{P.format('pid')}/experiments/{P.format('eid')}/results", r_results, True),
    ("GET", rf"/projects/{P.format('pid')}/experiments/{P.format('eid')}/report\.(?P<fmt>[a-z]+)", r_report, True),
    ("GET", rf"/projects/{P.format('pid')}/experiments/{P.format('eid')}/figures/(?P<name>[A-Za-z0-9_\-]+)", r_figure, True),
    ("POST", rf"/projects/{P.format('pid')}/experiments/{P.format('eid')}/copilot", r_copilot, True),
]
COMPILED = [(m, re.compile(f"^/api/v1{p}$"), h, a) for m, p, h, a in ROUTES]
AUTH_LIMITED = {"/api/v1/auth/login", "/api/v1/auth/register", "/api/v1/auth/password-reset/request"}
_rate: dict[tuple, list[float]] = {}
_rate_lock = threading.Lock()


def rate_limited(ip: str, path: str) -> bool:
    import time
    if path not in AUTH_LIMITED or os.environ.get("RATE_LIMIT_ENABLED", "true") != "true":
        return False
    with _rate_lock:
        now = time.time()
        hits = [t for t in _rate.get((ip, path), []) if now - t < 60]
        hits.append(now)
        _rate[(ip, path)] = hits
        return len(hits) > 10


class Form:
    def __init__(self):
        self.fields: dict[str, str] = {}
        self.files: dict[str, tuple[str, bytes]] = {}


class Ctx:
    pass


class Handler(BaseHTTPRequestHandler):
    server_version = "BioAI-Local"
    sys_version = ""

    def log_message(self, fmt, *args):  # method, path and status only; never bodies or tokens
        sys.stderr.write(f"{self.address_string()} {fmt % args}\n")

    def _send(self, status, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, status, obj):
        self._send(status, json.dumps(clean(obj), default=str).encode(), "application/json")

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PATCH(self):
        self._handle("PATCH")

    def do_HEAD(self):
        self._handle("GET")

    def _static(self, path: str):
        root = CFG.static_dir.resolve()
        target = (root / unquote(path).lstrip("/")).resolve()
        if root not in target.parents and target != root:
            return self._send(404, b"Not found", "text/plain")
        if not target.is_file():
            target = root / "index.html"  # single-page app routing
        if not target.is_file():
            return self._send(503, b"Frontend not built. Run: python3 run_local.py --rebuild-frontend", "text/plain")
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        cache = "no-cache" if target.name == "index.html" else "public, max-age=3600"
        self._send(200, target.read_bytes(), ctype, {"Cache-Control": cache})

    def _handle(self, method):
        url = urlparse(self.path)
        if not url.path.startswith("/api/"):
            return self._static(url.path) if method == "GET" else self._send(405, b"", "text/plain")
        ip = self.client_address[0]
        if CFG.trust_proxy and self.headers.get("X-Forwarded-For"):
            ip = self.headers["X-Forwarded-For"].split(",")[0].strip()  # real client behind the hosting proxy
        if rate_limited(ip, url.path):
            return self._json(429, {"detail": "Too many attempts; wait a minute and try again"})
        for m, rx, handler, needs_auth in COMPILED:
            match = rx.match(url.path)
            if not match:
                continue
            if m != method:
                continue
            c = conn()
            try:
                ctx = Ctx()
                ctx.db, ctx.ip, ctx.json, ctx.form, ctx.after_commit = c, ip, {}, Form(), []
                ctx.query = {k: v[-1] for k, v in parse_qs(url.query).items()}
                length = int(self.headers.get("Content-Length") or 0)
                if length > CFG.max_upload + 1_000_000:
                    raise ApiError(413, f"Request exceeds the {CFG.max_upload // 1_000_000} MB limit")
                body = self.rfile.read(length) if length else b""
                ctype = self.headers.get("Content-Type", "")
                if body and ctype.startswith("application/json"):
                    try:
                        ctx.json = json.loads(body)
                    except json.JSONDecodeError:
                        raise ApiError(422, "Request body is not valid JSON")
                    if not isinstance(ctx.json, dict):
                        raise ApiError(422, "Request body must be a JSON object")
                elif body and ctype.startswith("multipart/form-data"):
                    msg = BytesParser(policy=email_policy).parsebytes(b"Content-Type: " + ctype.encode() + b"\r\n\r\n" + body)
                    for part in msg.iter_parts():
                        name = part.get_param("name", header="content-disposition")
                        if part.get_filename() is not None:
                            ctx.form.files[name] = (part.get_filename(), part.get_payload(decode=True) or b"")
                        else:
                            ctx.form.fields[name] = (part.get_payload(decode=True) or b"").decode("utf-8", "replace")
                if needs_auth:
                    auth = self.headers.get("Authorization", "")
                    if not auth.startswith("Bearer "):
                        raise ApiError(401, "Not authenticated")
                    try:
                        payload = sec.decode_token(auth[7:], CFG.secret_key, "access")
                    except sec.AuthError as exc:
                        raise ApiError(401, str(exc))
                    ctx.user = user_by_id(c, payload["sub"])
                    if ctx.user is None or not ctx.user["is_active"] or ctx.user["deleted_at"]:
                        raise ApiError(401, "Account not active")
                    if ctx.user["email"] == DEMO_EMAIL and method != "GET" and handler is not r_copilot:
                        raise ApiError(403, "The demo is read-only so it stays the same for every visitor. "
                                            "Create a free account to upload data and run your own analyses.")
                c.execute("BEGIN")
                try:
                    status, out = handler(ctx, **match.groupdict())
                    c.execute("COMMIT")
                    for action in ctx.after_commit:
                        action()
                except ApiError as exc:
                    # keep security audit entries (e.g. failed logins) even when the request fails
                    c.execute("COMMIT" if exc.status == 401 else "ROLLBACK")
                    raise
                except Exception:
                    c.execute("ROLLBACK")
                    raise
                if isinstance(out, Raw):
                    extra = {"Content-Disposition": out.disposition} if out.disposition else {}
                    return self._send(status, out.data, out.ctype, extra)
                return self._json(status, out)
            except ApiError as exc:
                return self._json(exc.status, {"detail": exc.detail})
            except ScienceError as exc:
                return self._json(422, {"detail": str(exc)})
            except Exception as exc:
                sys.stderr.write(f"Unhandled {type(exc).__name__} on {method} {url.path}\n")
                traceback.print_exc()
                return self._json(500, {"detail": "Internal server error"})
            finally:
                c.close()
        allowed = [m for m, rx, _, _ in COMPILED if rx.match(url.path)]
        if allowed:
            return self._json(405, {"detail": "Method not allowed"})
        return self._json(404, {"detail": "Not found"})


def worker_loop():
    from local.worker import execute
    while True:
        eid = JOBS.get()
        try:
            execute(CFG, eid)
        except Exception:
            traceback.print_exc()
        finally:
            JOBS.task_done()


def start(host: str, port: int, data_dir: str) -> ThreadingHTTPServer:
    global CFG
    CFG = Config(pathlib.Path(data_dir))
    dbm.init(CFG.db_path)
    c = conn()
    # Jobs interrupted by a previous shutdown are re-queued, never silently lost.
    for r in c.execute("SELECT id FROM experiments WHERE status IN ('QUEUED','RUNNING')").fetchall():
        c.execute("UPDATE experiments SET status='QUEUED' WHERE id=?", (r["id"],))
        JOBS.put(r["id"])
    c.close()
    for _ in range(2):
        threading.Thread(target=worker_loop, daemon=True).start()
    if CFG.demo:
        from local.demo import ensure_demo
        threading.Thread(target=ensure_demo, args=(CFG, JOBS), daemon=True).start()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    return httpd
