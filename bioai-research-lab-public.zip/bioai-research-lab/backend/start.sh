#!/bin/sh
# Backend container entrypoint: migrate, seed roles, optionally load the demo, then serve.
set -e
cd /srv
if [ ! -f alembic/versions/0001_initial_schema.py ]; then
  alembic revision --autogenerate -m "initial schema" --rev-id 0001_initial_schema
  cp alembic/pending/0002_audit_append_only.py alembic/versions/
fi
alembic upgrade head
python -m app.cli seed
# The demo runs real analyses (minutes), so it runs in the background after the API is up.
if [ "${LOAD_DEMO:-false}" = "true" ]; then (sleep 5; python -m app.cli demo || echo "Demo load failed (see above)") & fi
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers
