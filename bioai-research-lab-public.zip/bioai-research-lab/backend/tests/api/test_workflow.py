"""End-to-end API workflow on DEMONSTRATION DATA, plus authorization and scientific-rule checks."""
import io
import uuid

import pytest

from app.science import demo_data as dd

PW = "Research-Lab-2026"


def csv(df, index=False) -> bytes:
    b = io.StringIO(); df.to_csv(b, index=index); return b.getvalue().encode()


def account(client, name="r"):
    email = f"{name}-{uuid.uuid4().hex[:8]}@example.org"
    r = client.post("/api/v1/auth/register", json={"email": email, "password": PW, "display_name": name})
    assert r.status_code == 201, r.text
    assert client.post("/api/v1/auth/login", json={"email": email, "password": PW}).status_code == 403  # unverified
    assert client.post("/api/v1/auth/verify-email", json={"token": r.json()["verification_token"]}).status_code == 200
    t = client.post("/api/v1/auth/login", json={"email": email, "password": PW}).json()
    return email, {"Authorization": f"Bearer {t['access_token']}"}


def upload(client, h, pid, name, domain, data, fname):
    r = client.post(f"/api/v1/projects/{pid}/datasets", headers=h,
                    data={"name": name, "domain": domain, "is_synthetic": "true"}, files={"file": (fname, data)})
    assert r.status_code == 201, r.text
    return r.json()["versions"][0]["id"]


def wait_done(client, h, pid, eid):
    e = client.get(f"/api/v1/projects/{pid}/experiments/{eid}", headers=h).json()
    assert e["status"] == "SUCCEEDED", e.get("error_message")  # inline worker has finished by now
    return client.get(f"/api/v1/projects/{pid}/experiments/{eid}/results", headers=h).json()


def test_auth_rules(client):
    assert client.get("/api/v1/projects").status_code == 401
    assert client.post("/api/v1/auth/register", json={"email": "weak@example.org", "password": "weakpassword1"}).status_code == 422
    email, h = account(client)
    assert client.post("/api/v1/auth/login", json={"email": email, "password": "Wrong-Password-99"}).status_code == 401
    assert client.post("/api/v1/auth/register", json={"email": email.upper(), "password": PW}).status_code == 409
    assert client.get("/api/v1/auth/me", headers=h).json()["email"] == email
    r = client.post("/api/v1/auth/password-reset/request", json={"email": email}).json()
    assert client.post("/api/v1/auth/password-reset/confirm", json={"token": r["reset_token"], "new_password": "New-Research-2027"}).status_code == 200
    assert client.post("/api/v1/auth/password-reset/confirm", json={"token": r["reset_token"], "new_password": "Other-Research-2028"}).status_code == 400  # single use
    assert client.post("/api/v1/auth/login", json={"email": email, "password": "New-Research-2027"}).status_code == 200


def test_full_omics_workflow_with_external_validation_and_report(client):
    _, h = account(client, "omics")
    p = client.post("/api/v1/projects", headers=h, json={"name": f"Omics {uuid.uuid4().hex[:6]}", "platform": "BIOOMICS",
                                                          "research_question": "Early vs late stage (demo)?"}).json()
    pid = p["id"]
    expr, meta = dd.omics_demo(n_samples=120, n_genes=150)
    eexpr, emeta = dd.omics_demo(n_samples=60, n_genes=150, seed=99, prefix="V")
    ev = upload(client, h, pid, "expr", "BIOOMICS", csv(expr.rename_axis("gene"), True), "expr.csv")
    mv = upload(client, h, pid, "meta", "BIOOMICS", csv(meta), "meta.csv")
    xv = upload(client, h, pid, "ext expr", "BIOOMICS", csv(eexpr.rename_axis("gene"), True), "ext.csv")
    xm = upload(client, h, pid, "ext meta", "BIOOMICS", csv(emeta), "extmeta.csv")
    gs = upload(client, h, pid, "gene sets", "BIOOMICS", dd.gene_sets_demo(150).encode(), "sets.gmt")
    body = {"name": "demo omics", "platform": "BIOOMICS", "dataset_version_id": ev, "metadata_version_id": mv,
            "group_column": "stage", "positive_class": "LATE", "negative_class": "EARLY", "demo": True,
            "gene_sets_version_id": gs, "network": {"threshold": 0.4},
            "external_expression_version_id": xv, "external_metadata_version_id": xm,
            "ml": {"algorithms": ["LOGISTIC_REGRESSION", "RANDOM_FOREST", "XGBOOST"], "resampling": "SMOTE", "cv_folds": 3}}

    # Scientific rule: training data can never be used as "external" validation.
    bad = {**body, "external_expression_version_id": ev, "external_metadata_version_id": mv}
    assert client.post(f"/api/v1/projects/{pid}/experiments", headers=h, json=bad).status_code == 422

    e = client.post(f"/api/v1/projects/{pid}/experiments", headers=h, json=body).json()
    assert client.post(f"/api/v1/projects/{pid}/experiments/{e['id']}/run", headers=h).status_code == 202
    res = wait_done(client, h, pid, e["id"])
    r = res["result"]
    assert r["external_validation"]["role"] == "EXTERNAL_VALIDATION"
    assert r["ml"]["models"]["LOGISTIC_REGRESSION"]["resampling"]["final"]["scope"] == "TRAINING_FOLDS_ONLY"
    assert r["network"]["edge_type"] == "CORRELATION"
    assert "XGBOOST" in r["ml"]["models"], r["ml"]["unavailable_models"]   # verified in the real environment
    assert r["explanations"]["RANDOM_FOREST"]["shap_available"] is True     # tree SHAP with the shap library
    assert {"pdf", "html", "json", "csv"} <= set(res["report"]["formats"])
    pdf = client.get(f"/api/v1/projects/{pid}/experiments/{e['id']}/report.pdf", headers=h)
    assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF"
    assert b"DEMONSTRATION DATA" in client.get(f"/api/v1/projects/{pid}/experiments/{e['id']}/report.html", headers=h).content
    assert client.post(f"/api/v1/projects/{pid}/experiments/{e['id']}/run", headers=h).status_code == 409  # immutable
    clone = client.post(f"/api/v1/projects/{pid}/experiments/{e['id']}/clone", headers=h).json()
    assert clone["parameters"] == e["parameters"] and clone["parent_experiment_id"] == e["id"]
    # A clone can only change name/seed; smuggling in other dataset versions must be rejected.
    smuggle = client.post(f"/api/v1/projects/{pid}/experiments/{e['id']}/clone", headers=h,
                          json={"parameters": {"external_expression_version_id": ev}})
    assert smuggle.status_code == 422
    reseeded = client.post(f"/api/v1/projects/{pid}/experiments/{e['id']}/clone", headers=h, json={"random_seed": 7}).json()
    assert reseeded["random_seed"] == 7 and reseeded["parameters"]["random_seed"] == 7
    # Unknown analysis options are rejected up front instead of failing inside the worker.
    typo = {**body, "network": {"treshold": 0.4}}
    assert client.post(f"/api/v1/projects/{pid}/experiments", headers=h, json=typo).status_code == 422
    cp = client.post(f"/api/v1/projects/{pid}/experiments/{e['id']}/copilot", headers=h, json={"question": "limitations?"})
    assert cp.status_code == 200 and cp.json()["evidence"]
    actions = {a["action"] for a in client.get(f"/api/v1/projects/{pid}/audit", headers=h).json()}
    assert {"project.create", "dataset.upload", "experiment.run", "experiment.succeeded", "report.download"} <= actions


def test_biosignal_workflow_pseudonymised(client):
    _, h = account(client, "bio")
    pid = client.post("/api/v1/projects", headers=h, json={"name": f"HRV {uuid.uuid4().hex[:6]}", "platform": "BIOSIGNAL",
                                                           "research_question": "Normal vs exam day HRV (demo)?"}).json()["id"]
    rr = upload(client, h, pid, "rr", "BIOSIGNAL", csv(dd.biosignal_demo(6)), "rr.csv")
    e = client.post(f"/api/v1/projects/{pid}/experiments", headers=h, json={
        "name": "hrv", "platform": "BIOSIGNAL", "dataset_version_id": rr, "compare": ["NORMAL_DAY", "EXAM_DAY"],
        "window_s": 60, "ml": {"algorithms": ["LOGISTIC_REGRESSION"], "positive_class": "EXAM_DAY", "cv_folds": 3}}).json()
    client.post(f"/api/v1/projects/{pid}/experiments/{e['id']}/run", headers=h)
    res = wait_done(client, h, pid, e["id"])
    text = str(res)
    assert "student_" not in text  # raw participant identifiers never stored in results
    for s in res["result"]["sessions"]:
        assert s["n_valid"] + s["n_excluded"] == s["n_total"]
        if not s["frequency_domain_valid"]:
            assert s.get("lf_hf_ratio") is None


def test_project_isolation(client):
    _, owner = account(client, "owner")
    email_b, outsider = account(client, "outsider")
    pid = client.post("/api/v1/projects", headers=owner, json={"name": f"Private {uuid.uuid4().hex[:6]}",
                      "platform": "GENERAL", "research_question": "Private question", "privacy": "CONFIDENTIAL"}).json()["id"]
    for path in (f"/projects/{pid}", f"/projects/{pid}/datasets", f"/projects/{pid}/experiments", f"/projects/{pid}/audit"):
        assert client.get(f"/api/v1{path}", headers=outsider).status_code == 404, path  # existence not disclosed
    assert client.post(f"/api/v1/projects/{pid}/members", headers=owner, json={"email": email_b, "project_role": "VIEWER"}).status_code == 201
    assert client.get(f"/api/v1/projects/{pid}", headers=outsider).status_code == 200
    r = client.post(f"/api/v1/projects/{pid}/datasets", headers=outsider, data={"name": "x", "domain": "GENERAL"},
                    files={"file": ("x.csv", b"a,b\n1,2\n")})
    assert r.status_code == 403  # viewers cannot upload


def test_upload_validation_errors_are_reported(client):
    _, h = account(client, "up")
    pid = client.post("/api/v1/projects", headers=h, json={"name": f"Up {uuid.uuid4().hex[:6]}", "platform": "GENERAL",
                                                           "research_question": "Upload checks"}).json()["id"]
    for fname, data in (("x.xlsx", b"a,b\n1,2\n"), ("x.csv", b"PK\x03\x04zip"), ("x.csv", b"a,b\n1,2,3\n")):
        r = client.post(f"/api/v1/projects/{pid}/datasets", headers=h, data={"name": f"d{uuid.uuid4().hex[:4]}", "domain": "GENERAL"},
                        files={"file": (fname, data)})
        assert r.status_code == 422, (fname, r.text)


def test_invalid_task_status_is_a_validation_error(client):
    _, h = account(client, "tasks")
    pid = client.post("/api/v1/projects", headers=h, json={"name": f"T {uuid.uuid4().hex[:6]}", "platform": "GENERAL",
                                                           "research_question": "Task checks"}).json()["id"]
    tid = client.post(f"/api/v1/projects/{pid}/tasks", headers=h, json={"title": "Write methods"}).json()["id"]
    assert client.patch(f"/api/v1/projects/{pid}/tasks/{tid}", headers=h, json={"status": "FINISHED"}).status_code == 422
    assert client.patch(f"/api/v1/projects/{pid}/tasks/{tid}", headers=h, json={"status": "DONE"}).json()["status"] == "DONE"
