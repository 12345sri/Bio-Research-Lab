"""API tests run the real FastAPI app against real PostgreSQL (TEST_DATABASE_URL).

Background jobs run inline (RUN_TASKS_INLINE=true) and files go to a temporary local store,
so the whole workflow is exercised in one process. Skipped without PostgreSQL unless REQUIRE_DB=1.
"""
import os
import tempfile

import pytest

URL = os.environ.get("TEST_DATABASE_URL", "")
if URL.startswith("postgresql"):
    os.environ.update(DATABASE_URL=URL, RUN_TASKS_INLINE="true", STORAGE_BACKEND="local",
                      LOCAL_STORAGE_DIR=tempfile.mkdtemp(prefix="bioai-test-"), ENVIRONMENT="development",
                      PSEUDONYM_SECRET="test-pseudonym-secret", RATE_LIMIT_ENABLED="false",
                      SECRET_KEY=os.environ.get("SECRET_KEY") or "test-secret-key-that-is-long-enough-0123456789")


@pytest.fixture(scope="session")
def client():
    if not URL.startswith("postgresql"):
        if os.environ.get("REQUIRE_DB") == "1":
            pytest.fail("REQUIRE_DB=1 but TEST_DATABASE_URL is not PostgreSQL")
        pytest.skip("API workflow tests need PostgreSQL in TEST_DATABASE_URL")
    from alembic import command
    from fastapi.testclient import TestClient

    from tests.integration.helpers import alembic_config
    cfg = alembic_config(URL)
    command.downgrade(cfg, "base")
    command.upgrade(cfg, "head")
    from app.cli import seed
    from app.db.session import session_factory
    db = session_factory()()
    seed(db); db.commit(); db.close()
    from app.main import app
    return TestClient(app)
