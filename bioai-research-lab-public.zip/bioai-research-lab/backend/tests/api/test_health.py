from fastapi.testclient import TestClient

from app.main import app


def test_health_ok():
    r = TestClient(app).get("/api/v1/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_openapi_states_research_only():
    r = TestClient(app).get("/api/v1/openapi.json")
    assert r.status_code == 200
    assert "not a medical device" in r.json()["info"]["description"].lower()
