"""Local-mode API tests: a real server on a free port with an empty data directory, exercised over HTTP.

Mirrors tests/api/test_workflow.py (FastAPI + PostgreSQL) so both backends honour the same contract.
Runs without Docker, databases or network access.
"""
import io
import json
import os
import socket
import tempfile
import threading
import time
import urllib.error
import urllib.request
import uuid

from app.science import demo_data as dd

PW = "Research-Lab-2026"
_state = {}


def _server():
    if "base" not in _state:
        os.environ.update(RATE_LIMIT_ENABLED="false", LOAD_DEMO="false", ENVIRONMENT="development")
        from local.server import start
        s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
        httpd = start("127.0.0.1", port, tempfile.mkdtemp(prefix="bioai-local-test-"))
        threading.Thread(target=httpd.serve_forever, daemon=True).start()
        _state["base"] = f"http://127.0.0.1:{port}/api/v1"
    return _state["base"]


def call(method, path, token=None, body=None, files=None, fields=None, raw=False):
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    data = None
    if files is not None:
        boundary = uuid.uuid4().hex
        parts = [f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode() for k, v in (fields or {}).items()]
        for k, (fname, content) in files.items():
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"; filename="{fname}"\r\n'
                         f'Content-Type: application/octet-stream\r\n\r\n'.encode() + content + b"\r\n")
        data = b"".join(parts) + f"--{boundary}--\r\n".encode()
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    elif body is not None:
        data = json.dumps(body).encode(); headers["Content-Type"] = "application/json"
    req = urllib.request.Request(_server() + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            content = r.read()
            return r.status, (content if raw else json.loads(content or b"null"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"null")


def csv(df, index=False):
    b = io.StringIO(); df.to_csv(b, index=index); return b.getvalue().encode()


def account(name="r"):
    email = f"{name}-{uuid.uuid4().hex[:8]}@example.org"
    st, r = call("POST", "/auth/register", body={"email": email, "password": PW, "display_name": name})
    assert st == 201, r
    assert call("POST", "/auth/login", body={"email": email, "password": PW})[0] == 403
    assert call("POST", "/auth/verify-email", body={"token": r["verification_token"]})[0] == 200
    st, t = call("POST", "/auth/login", body={"email": email, "password": PW})
    assert st == 200
    return email, t["access_token"], t["refresh_token"]


def upload(tok, pid, name, domain, data, fname):
    st, r = call("POST", f"/projects/{pid}/datasets", tok, files={"file": (fname, data)},
                 fields={"name": name, "domain": domain, "is_synthetic": "true"})
    assert st == 201, r
    return r["versions"][0]["id"]


def wait(tok, pid, eid, timeout=300):
    t0 = time.time()
    while time.time() - t0 < timeout:
        e = call("GET", f"/projects/{pid}/experiments/{eid}", tok)[1]
        if e["status"] not in ("QUEUED", "RUNNING"):
            return e
        time.sleep(1)
    raise AssertionError("experiment did not finish")


def test_auth_rules():
    assert call("GET", "/projects")[0] == 401
    assert call("POST", "/auth/register", body={"email": "weak@example.org", "password": "weakpassword1"})[0] == 422
    email, tok, refresh = account()
    assert call("POST", "/auth/login", body={"email": email, "password": "Wrong-Password-99"})[0] == 401
    assert call("POST", "/auth/register", body={"email": email.upper(), "password": PW})[0] == 409
    assert call("GET", "/auth/me", tok)[1]["email"] == email
    assert call("GET", "/auth/me", tok[:-3] + "abc")[0] == 401                       # tampered token
    assert call("GET", "/auth/me", refresh)[0] == 401                                 # refresh token is not an access token
    assert call("POST", "/auth/refresh", body={"refresh_token": refresh})[0] == 200
    r = call("POST", "/auth/password-reset/request", body={"email": email})[1]
    assert call("POST", "/auth/password-reset/confirm", body={"token": r["reset_token"], "new_password": "New-Research-2027"})[0] == 200
    assert call("POST", "/auth/password-reset/confirm", body={"token": r["reset_token"], "new_password": "Other-Research-2028"})[0] == 400
    assert call("POST", "/auth/login", body={"email": email, "password": "New-Research-2027"})[0] == 200
    assert call("PATCH", "/auth/me", tok, body={"display_name": "Renamed"})[1]["display_name"] == "Renamed"
    assert call("POST", "/auth/demo-login")[0] == 404                                 # demo disabled in this server


def test_full_omics_workflow_with_external_validation_report_and_audit():
    _, tok, _ = account("omics")
    st, p = call("POST", "/projects", tok, body={"name": f"Omics {uuid.uuid4().hex[:6]}", "platform": "BIOOMICS",
                                                  "research_question": "Early vs late stage (demo)?"})
    assert st == 201
    pid = p["id"]
    expr, meta = dd.omics_demo(n_samples=120, n_genes=150)
    eexpr, emeta = dd.omics_demo(n_samples=60, n_genes=150, seed=99, prefix="V")
    ev = upload(tok, pid, "expr", "BIOOMICS", csv(expr.rename_axis("gene"), True), "expr.csv")
    mv = upload(tok, pid, "meta", "BIOOMICS", csv(meta), "meta.csv")
    xv = upload(tok, pid, "ext expr", "BIOOMICS", csv(eexpr.rename_axis("gene"), True), "ext.csv")
    xm = upload(tok, pid, "ext meta", "BIOOMICS", csv(emeta), "extmeta.csv")
    gs = upload(tok, pid, "gene sets", "BIOOMICS", dd.gene_sets_demo(150).encode(), "sets.gmt")
    prev = call("GET", f"/projects/{pid}/dataset-versions/{mv}/preview", tok)[1]
    assert prev["columns"][:2] == ["sample_id", "stage"] and len(prev["rows"]) == 20
    assert call("GET", f"/projects/{pid}/dataset-versions/{gs}/preview", tok)[1]["columns"][0] == "gene_set"
    st, data = call("GET", f"/projects/{pid}/dataset-versions/{mv}/download", tok, raw=True)
    assert st == 200 and data == csv(meta)                                             # byte-identical storage
    datasets = call("GET", f"/projects/{pid}/datasets", tok)[1]
    did = next(d["id"] for d in datasets if d["name"] == "meta")
    st, v2 = call("POST", f"/projects/{pid}/datasets/{did}/versions", tok, files={"file": ("meta2.csv", csv(meta.iloc[:100]))},
                  fields={"change_note": "subset"})
    assert st == 201 and v2["version"] == 2
    assert call("GET", f"/projects/{pid}/dataset-versions/{mv}/download", tok, raw=True)[1] == csv(meta)  # v1 unchanged

    body = {"name": "demo omics", "platform": "BIOOMICS", "dataset_version_id": ev, "metadata_version_id": mv,
            "group_column": "stage", "positive_class": "LATE", "negative_class": "EARLY", "demo": True,
            "gene_sets_version_id": gs, "network": {"threshold": 0.4},
            "external_expression_version_id": xv, "external_metadata_version_id": xm,
            "ml": {"algorithms": ["LOGISTIC_REGRESSION", "RANDOM_FOREST", "XGBOOST"], "resampling": "SMOTE", "cv_folds": 3}}
    bad = {**body, "external_expression_version_id": ev, "external_metadata_version_id": mv}
    assert call("POST", f"/projects/{pid}/experiments", tok, body=bad)[0] == 422      # training data as "external"
    assert call("POST", f"/projects/{pid}/experiments", tok, body={**body, "network": {"treshold": 0.4}})[0] == 422
    assert call("POST", f"/projects/{pid}/experiments", tok, body={**body, "frequency": {"min_duration_s": 60}})[0] == 422
    st, e = call("POST", f"/projects/{pid}/experiments", tok, body=body)
    assert st == 201 and e["status"] == "DRAFT"
    assert call("POST", f"/projects/{pid}/experiments/{e['id']}/run", tok)[0] == 202
    done = wait(tok, pid, e["id"])
    assert done["status"] == "SUCCEEDED", done["error_message"]
    res = call("GET", f"/projects/{pid}/experiments/{e['id']}/results", tok)[1]
    r = res["result"]
    assert r["external_validation"]["role"] == "EXTERNAL_VALIDATION"
    assert r["ml"]["models"]["LOGISTIC_REGRESSION"]["resampling"]["final"]["scope"] == "TRAINING_FOLDS_ONLY"
    assert r["network"]["edge_type"] == "CORRELATION"
    assert isinstance(r["pathway"]["table"], list) and "p_adjusted" in r["pathway"]["table"][0]
    xgb_installed = done["software_versions"].get("xgboost") not in (None, "not installed")
    assert ("XGBOOST" in r["ml"]["models"]) == xgb_installed                          # runs if installed, else reported
    if not xgb_installed:
        assert "XGBOOST" in r["ml"]["unavailable_models"]
    assert {"pdf", "html", "json", "csv"} <= set(res["report"]["formats"])
    st, pdf = call("GET", f"/projects/{pid}/experiments/{e['id']}/report.pdf", tok, raw=True)
    assert st == 200 and pdf[:4] == b"%PDF"
    assert b"DEMONSTRATION DATA" in call("GET", f"/projects/{pid}/experiments/{e['id']}/report.html", tok, raw=True)[1]
    st, png = call("GET", f"/projects/{pid}/experiments/{e['id']}/figures/roc", tok, raw=True)
    assert st == 200 and png[:4] == b"\x89PNG"
    assert call("POST", f"/projects/{pid}/experiments/{e['id']}/run", tok)[0] == 409  # results immutable
    st, clone = call("POST", f"/projects/{pid}/experiments/{e['id']}/clone", tok)
    assert st == 201 and clone["parameters"] == e["parameters"] and clone["parent_experiment_id"] == e["id"]
    assert call("POST", f"/projects/{pid}/experiments/{e['id']}/clone", tok,
                body={"parameters": {"external_expression_version_id": ev}})[0] == 422
    cp = call("POST", f"/projects/{pid}/experiments/{e['id']}/copilot", tok, body={"question": "limitations?"})[1]
    assert cp["evidence"] and any(i["code"] == "SMALL_TEST_CLASS" or i["severity"] for i in cp["review"])
    actions = {a["action"] for a in call("GET", f"/projects/{pid}/audit", tok)[1]}
    assert {"project.create", "dataset.upload", "dataset.version", "dataset.download", "experiment.run",
            "experiment.succeeded", "report.download", "experiment.clone"} <= actions


def test_biosignal_workflow_pseudonymised_and_valid_frequency_only():
    _, tok, _ = account("bio")
    pid = call("POST", "/projects", tok, body={"name": f"HRV {uuid.uuid4().hex[:6]}", "platform": "BIOSIGNAL",
                                               "research_question": "Normal vs exam day HRV (demo)?"})[1]["id"]
    rr = upload(tok, pid, "rr", "BIOSIGNAL", csv(dd.biosignal_demo(6)), "rr.csv")
    st, e = call("POST", f"/projects/{pid}/experiments", tok, body={
        "name": "hrv", "platform": "BIOSIGNAL", "dataset_version_id": rr, "compare": ["NORMAL_DAY", "EXAM_DAY"],
        "window_s": 60, "ml": {"algorithms": ["LOGISTIC_REGRESSION"], "positive_class": "EXAM_DAY", "cv_folds": 3}})
    assert st == 201, e
    call("POST", f"/projects/{pid}/experiments/{e['id']}/run", tok)
    assert wait(tok, pid, e["id"])["status"] == "SUCCEEDED"
    res = call("GET", f"/projects/{pid}/experiments/{e['id']}/results", tok)[1]
    assert "student_" not in json.dumps(res)
    for s in res["result"]["sessions"]:
        assert s["n_valid"] + s["n_excluded"] == s["n_total"]
        if not s["frequency_domain_valid"]:
            assert s.get("lf_hf_ratio") is None
    assert res["result"]["comparisons"] and res["result"]["ml"]["split"]["strategy"] == "PARTICIPANT"


def test_project_isolation_and_roles():
    _, owner, _ = account("owner")
    email_b, outsider, _ = account("outsider")
    pid = call("POST", "/projects", owner, body={"name": f"Private {uuid.uuid4().hex[:6]}", "platform": "GENERAL",
                                                 "research_question": "Private question", "privacy": "CONFIDENTIAL"})[1]["id"]
    for path in (f"/projects/{pid}", f"/projects/{pid}/datasets", f"/projects/{pid}/experiments", f"/projects/{pid}/audit"):
        assert call("GET", path, outsider)[0] == 404, path
    assert pid not in [p["id"] for p in call("GET", "/projects", outsider)[1]]
    assert call("POST", f"/projects/{pid}/members", owner, body={"email": email_b, "project_role": "VIEWER"})[0] == 201
    assert call("GET", f"/projects/{pid}", outsider)[0] == 200
    assert call("POST", f"/projects/{pid}/datasets", outsider, files={"file": ("x.csv", b"a,b\n1,2\n")},
                fields={"name": "x", "domain": "GENERAL"})[0] == 403
    assert call("POST", f"/projects/{pid}/members", outsider, body={"email": email_b, "project_role": "OWNER"})[0] == 403


def test_upload_validation_errors_and_collaboration():
    _, tok, _ = account("up")
    pid = call("POST", "/projects", tok, body={"name": f"Up {uuid.uuid4().hex[:6]}", "platform": "GENERAL",
                                               "research_question": "Upload checks"})[1]["id"]
    for fname, data in (("x.xlsx", b"a,b\n1,2\n"), ("x.csv", b"PK\x03\x04zip"), ("x.csv", b"a,b\n1,2,3\n")):
        st, r = call("POST", f"/projects/{pid}/datasets", tok, files={"file": (fname, data)},
                     fields={"name": f"d{uuid.uuid4().hex[:4]}", "domain": "GENERAL"})
        assert st == 422, (fname, r)
    tid = call("POST", f"/projects/{pid}/tasks", tok, body={"title": "Write methods"})[1]["id"]
    assert call("PATCH", f"/projects/{pid}/tasks/{tid}", tok, body={"status": "FINISHED"})[0] == 422
    assert call("PATCH", f"/projects/{pid}/tasks/{tid}", tok, body={"status": "DONE"})[1]["status"] == "DONE"
    assert call("POST", f"/projects/{pid}/comments", tok, body={"target_type": "PROJECT", "target_id": pid, "body": "hello"})[0] == 201
    assert call("GET", f"/projects/{pid}/comments?target_type=PROJECT", tok)[1][0]["body"] == "hello"
    st, team = call("POST", "/teams", tok, body={"name": f"Team {uuid.uuid4().hex[:4]}", "discipline": "AI_ML"})
    assert st == 201 and any(t["id"] == team["id"] for t in call("GET", "/teams", tok)[1])


def test_audit_log_is_append_only_in_sqlite():
    import sqlite3
    from local import db as dbm
    _server()  # tests may run in any order
    from local import server
    CFG = server.CFG
    c = dbm.connect(CFG.db_path)
    try:
        c.execute("INSERT INTO audit_logs (occurred_at, action, resource_type) VALUES ('t', 'x', 'y')")
        for stmt in ("UPDATE audit_logs SET action='tampered'", "DELETE FROM audit_logs"):
            try:
                c.execute(stmt)
                raise AssertionError(f"{stmt} was allowed")
            except sqlite3.DatabaseError as exc:
                assert "append-only" in str(exc)
        try:
            c.execute("INSERT INTO model_runs VALUES ('m','nope','RF','ROW',1,'SMOTE','NOT_APPLICABLE','{}','t')")
            raise AssertionError("SMOTE outside training folds was stored")
        except sqlite3.IntegrityError:
            pass
    finally:
        c.close()
