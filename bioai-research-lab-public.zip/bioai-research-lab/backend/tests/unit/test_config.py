import pytest

from app.core.config import Settings


def test_missing_secret_fails_closed(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "sqlite://")
    monkeypatch.delenv("SECRET_KEY", raising=False)
    with pytest.raises(RuntimeError):
        Settings()
