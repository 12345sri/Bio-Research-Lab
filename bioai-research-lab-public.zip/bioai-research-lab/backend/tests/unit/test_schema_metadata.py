"""Schema checks that need SQLAlchemy but no database."""
import re

import pytest
from sqlalchemy.dialects import postgresql
from sqlalchemy.schema import CreateIndex, CreateTable

import app.models as models
from app.db.base import Base

PG = postgresql.dialect()
TABLES = Base.metadata.tables


def test_all_required_tables_defined():
    missing = models.REQUIRED_TABLES - set(TABLES)
    assert not missing, f"missing tables: {sorted(missing)}"


def test_no_unexpected_tables():
    extra = set(TABLES) - models.REQUIRED_TABLES - models.SUPPORTING_TABLES
    assert not extra, f"undocumented tables: {sorted(extra)}"


@pytest.mark.parametrize("table", sorted(TABLES))
def test_every_foreign_key_declares_ondelete(table):
    for fk in TABLES[table].foreign_keys:
        assert fk.ondelete in {"CASCADE", "SET NULL", "RESTRICT"}, f"{table}.{fk.parent.name} lacks ondelete"


@pytest.mark.parametrize("table", sorted(TABLES))
def test_ddl_compiles_and_names_fit_postgres(table):
    ddl = str(CreateTable(TABLES[table]).compile(dialect=PG))
    names = re.findall(r"CONSTRAINT (\w+)", ddl)
    for idx in TABLES[table].indexes:
        names += re.findall(r"INDEX (\w+)", str(CreateIndex(idx).compile(dialect=PG)))
    too_long = [n for n in names if len(n) > 63]
    assert not too_long, f"identifiers over 63 chars: {too_long}"


def test_constraint_names_unique_across_schema():
    seen: dict[str, str] = {}
    for name, table in TABLES.items():
        ddl = str(CreateTable(table).compile(dialect=PG))
        for c in re.findall(r"CONSTRAINT (\w+)", ddl):
            assert c not in seen, f"{c} defined in both {seen[c]} and {name}"
            seen[c] = name


@pytest.mark.parametrize("table", ["users", "consents", "biosignal_sessions"])
def test_no_unnecessary_personal_data_columns(table):
    forbidden = {"phone", "address", "government_id", "national_id", "passport", "date_of_birth", "full_name"}
    assert not forbidden & set(TABLES[table].columns.keys())


def test_timestamps_present():
    exempt = {"audit_logs"}  # uses occurred_at
    for name, table in TABLES.items():
        if name not in exempt:
            assert "created_at" in table.columns, f"{name} has no created_at"


def test_scientific_guard_constraints_exist():
    """Rules from CLAUDE.md that the database itself must enforce."""
    expected = {
        "model_runs": "smote_training_only",
        "hrv_results": "freq_domain_only_when_valid",
        "validation_runs": "external_is_independent",
        "features": "importance_is_explanation",
        "gene_networks": "correlation_has_threshold",
        "biosignal_sessions": "observations_accounted",
        "pathways": "gene_count_matches",
    }
    for table, fragment in expected.items():
        ddl = str(CreateTable(TABLES[table]).compile(dialect=PG))
        assert fragment in ddl, f"{table} missing constraint containing '{fragment}'"
