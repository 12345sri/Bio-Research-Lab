import os
import pathlib

from alembic.config import Config

BACKEND = pathlib.Path(__file__).resolve().parents[2]


def alembic_config(url: str) -> Config:
    os.environ["DATABASE_URL"] = url
    cfg = Config(str(BACKEND / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND / "alembic"))
    return cfg
