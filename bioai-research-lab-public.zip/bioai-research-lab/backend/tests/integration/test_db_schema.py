"""Runs against real PostgreSQL after `alembic upgrade head`."""
import hashlib
import uuid
from datetime import datetime, timezone

import pytest
from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext
from sqlalchemy import create_engine, inspect, select, text
from sqlalchemy.exc import DBAPIError, IntegrityError

import app.models as m
from app.db.base import Base
from app.models.enums import (Algorithm, ConsentStatus, EvidenceLabel, FileType, Platform, Privacy,
                              PublicationStatus, Resampling, ResamplingScope, RoleName, SignalType,
                              SplitStrategy, ValidationType)

from tests.integration.helpers import alembic_config

pytestmark = pytest.mark.integration
NOW = datetime.now(timezone.utc)


# ---------------------------------------------------------------- helpers
def seed(s):
    org = m.Organization(name=f"Org {uuid.uuid4().hex[:6]}", slug=uuid.uuid4().hex[:10])
    role = s.scalar(select(m.Role).where(m.Role.name == RoleName.RESEARCHER))
    if role is None:
        role = m.Role(name=RoleName.RESEARCHER)
    s.add_all([org, role]); s.flush()
    user = m.User(email=f"{uuid.uuid4().hex[:8]}@example.org", password_hash="x", organization_id=org.id, role_id=role.id)
    s.add(user); s.flush()
    project = m.Project(organization_id=org.id, name="P", research_question="Q?", platform=Platform.BIOSIGNAL,
                        principal_researcher_id=user.id)
    s.add(project); s.flush()
    ds = m.Dataset(project_id=project.id, name="D", domain=Platform.BIOSIGNAL, privacy=Privacy.INTERNAL, is_synthetic=True)
    s.add(ds); s.flush()
    v1 = m.DatasetVersion(dataset_id=ds.id, version=1, storage_key=f"k/{uuid.uuid4()}", file_type=FileType.CSV,
                          size_bytes=10, sha256=hashlib.sha256(b"a").hexdigest())
    s.add(v1); s.flush()
    exp = m.Experiment(project_id=project.id, dataset_version_id=v1.id, researcher_id=user.id, name="E",
                       platform=Platform.BIOSIGNAL, analysis_type="hrv", random_seed=42, code_version="test")
    s.add(exp); s.flush()
    return dict(org=org, role=role, user=user, project=project, dataset=ds, v1=v1, exp=exp)


def expect_integrity(s, obj):
    s.add(obj)
    with pytest.raises(IntegrityError):
        s.flush()
    s.rollback()


# ---------------------------------------------------------------- migrations
def test_all_tables_created(migrated_engine):
    tables = set(inspect(migrated_engine).get_table_names())
    assert m.REQUIRED_TABLES | m.SUPPORTING_TABLES <= tables
    assert tables - m.REQUIRED_TABLES - m.SUPPORTING_TABLES == {"alembic_version"}


def test_migrations_match_models_no_drift(migrated_engine):
    with migrated_engine.connect() as conn:
        ctx = MigrationContext.configure(conn, opts={"compare_type": True, "compare_server_default": False})
        diff = compare_metadata(ctx, Base.metadata)
    assert diff == [], f"models and migrations differ: {diff}"


def test_downgrade_and_upgrade_round_trip(db_url, migrated_engine):
    cfg = alembic_config(db_url)
    command.downgrade(cfg, "base")
    engine = create_engine(db_url)
    assert set(inspect(engine).get_table_names()) <= {"alembic_version"}
    command.upgrade(cfg, "head")
    assert m.REQUIRED_TABLES <= set(inspect(engine).get_table_names())
    engine.dispose()


# ---------------------------------------------------------------- happy path
def test_full_object_graph_inserts(session):
    d = seed(session)
    session.add(m.ProjectMember(project_id=d["project"].id, user_id=d["user"].id, project_role="OWNER",
                                contributions=["SOFTWARE", "ANALYSIS"]))
    consent = m.Consent(project_id=d["project"].id, participant_code="P001", consent_version="v1",
                        status=ConsentStatus.GRANTED, granted_at=NOW)
    session.add(consent); session.flush()
    bs = m.BiosignalSession(project_id=d["project"].id, dataset_version_id=d["v1"].id, consent_id=consent.id,
                            participant_code="P001", session_code="S1", signal_type=SignalType.RR_INTERVAL,
                            n_total=100, n_valid=97, n_excluded=3, exclusion_reasons={"out_of_range": 3})
    session.add(bs); session.flush()
    session.add(m.HrvResult(session_id=bs.id, experiment_id=d["exp"].id, window_length_s=300, n_beats=97,
                            sdnn_ms=22.1, rmssd_ms=25.0, frequency_domain_valid=True,
                            lf_power_ms2=400, hf_power_ms2=300, lf_hf_ratio=1.33))
    session.add(m.ExperimentResult(experiment_id=d["exp"].id, result_type="hrv_summary",
                                   evidence_label=EvidenceLabel.DATA, payload={"n": 97}))
    session.flush()


# ---------------------------------------------------------------- integrity rules
def test_email_unique_case_insensitive(session):
    d = seed(session)
    expect_integrity(session, m.User(email=d["user"].email.upper(), password_hash="x", role_id=d["role"].id))


def test_project_delete_cascades_membership_tasks_comments_consents(session):
    d = seed(session)
    p2 = m.Project(organization_id=d["org"].id, name="Disposable", research_question="Q", platform=Platform.GENERAL,
                   principal_researcher_id=d["user"].id)
    session.add(p2); session.flush()
    session.add_all([
        m.ProjectMember(project_id=p2.id, user_id=d["user"].id, project_role="LEAD"),
        m.Task(project_id=p2.id, title="t"),
        m.Comment(project_id=p2.id, target_type="PROJECT", target_id=p2.id, body="hi"),
        m.Consent(project_id=p2.id, participant_code="X", consent_version="v1", status="GRANTED", granted_at=NOW),
    ]); session.flush()
    session.execute(text("DELETE FROM projects WHERE id = :i"), {"i": p2.id})
    for table in ("project_members", "tasks", "comments", "consents"):
        assert session.execute(text(f"SELECT count(*) FROM {table} WHERE project_id = :i"), {"i": p2.id}).scalar() == 0


def test_project_with_data_cannot_be_hard_deleted(session):
    d = seed(session)
    with pytest.raises(IntegrityError):
        session.execute(text("DELETE FROM projects WHERE id = :i"), {"i": d["project"].id})
    session.rollback()


def test_dataset_version_used_by_experiment_is_protected(session):
    d = seed(session)
    with pytest.raises(IntegrityError):
        session.execute(text("DELETE FROM dataset_versions WHERE id = :i"), {"i": d["v1"].id})
    session.rollback()


def test_invalid_vocabulary_rejected_by_database(session):
    d = seed(session)
    with pytest.raises(IntegrityError):
        session.execute(text("UPDATE projects SET status = 'CURED' WHERE id = :i"), {"i": d["project"].id})
    session.rollback()


def test_invalid_contribution_rejected(session):
    d = seed(session)
    expect_integrity(session, m.ProjectMember(project_id=d["project"].id, user_id=d["user"].id,
                                              project_role="OWNER", contributions=["FIRST_AUTHOR"]))


def test_smote_must_be_training_folds_only(session):
    d = seed(session)
    model = m.Model(project_id=d["project"].id, name="xgb", algorithm=Algorithm.XGBOOST)
    session.add(model); session.flush()
    expect_integrity(session, m.ModelRun(model_id=model.id, experiment_id=d["exp"].id,
                                         split_strategy=SplitStrategy.STRATIFIED_ROW, random_seed=1,
                                         resampling=Resampling.SMOTE, resampling_scope=ResamplingScope.NOT_APPLICABLE))


def test_frequency_domain_blocked_when_invalid(session):
    d = seed(session)
    bs = m.BiosignalSession(project_id=d["project"].id, dataset_version_id=d["v1"].id, participant_code="P2",
                            session_code="S", signal_type=SignalType.RR_INTERVAL)
    session.add(bs); session.flush()
    expect_integrity(session, m.HrvResult(session_id=bs.id, experiment_id=d["exp"].id, window_length_s=30,
                                          n_beats=30, frequency_domain_valid=False,
                                          frequency_domain_note="too short", lf_hf_ratio=2.0))


def test_observations_must_be_accounted_for(session):
    d = seed(session)
    expect_integrity(session, m.BiosignalSession(project_id=d["project"].id, dataset_version_id=d["v1"].id,
                                                 participant_code="P3", session_code="S",
                                                 signal_type=SignalType.RR_INTERVAL,
                                                 n_total=100, n_valid=90, n_excluded=0))


def test_ecg_requires_sampling_rate(session):
    d = seed(session)
    expect_integrity(session, m.BiosignalSession(project_id=d["project"].id, dataset_version_id=d["v1"].id,
                                                 participant_code="P4", session_code="S", signal_type=SignalType.ECG))


def test_external_validation_requires_different_dataset(session):
    d = seed(session)
    model = m.Model(project_id=d["project"].id, name="lr", algorithm=Algorithm.LOGISTIC_REGRESSION)
    session.add(model); session.flush()
    run = m.ModelRun(model_id=model.id, experiment_id=d["exp"].id, split_strategy=SplitStrategy.PARTICIPANT,
                     random_seed=1, resampling=Resampling.NONE, resampling_scope=ResamplingScope.NOT_APPLICABLE)
    session.add(run); session.flush()
    expect_integrity(session, m.ValidationRun(model_run_id=run.id, validation_type=ValidationType.EXTERNAL,
                                              train_dataset_version_id=d["v1"].id,
                                              validation_dataset_version_id=d["v1"].id))


def test_feature_importance_cannot_be_labelled_biological(session):
    d = seed(session)
    model = m.Model(project_id=d["project"].id, name="rf", algorithm=Algorithm.RANDOM_FOREST)
    session.add(model); session.flush()
    run = m.ModelRun(model_id=model.id, experiment_id=d["exp"].id, split_strategy=SplitStrategy.ROW,
                     random_seed=1, resampling=Resampling.NONE, resampling_scope=ResamplingScope.NOT_APPLICABLE)
    session.add(run); session.flush()
    expect_integrity(session, m.Feature(model_run_id=run.id, name="RMSSD", feature_type="HRV_METRIC",
                                        importance_method="SHAP", importance=0.3,
                                        evidence_label=EvidenceLabel.INTERPRETATION))


def test_correlation_network_requires_threshold(session):
    d = seed(session)
    expect_integrity(session, m.GeneNetwork(experiment_id=d["exp"].id, edge_type="CORRELATION",
                                            method="pearson", n_nodes=5, n_edges=3))


def test_pathway_requires_adjusted_p_and_consistent_counts(session):
    d = seed(session)
    expect_integrity(session, m.Pathway(experiment_id=d["exp"].id, database="KEGG", pathway_id="hsa05224",
                                        name="Breast cancer", genes=["ERBB2", "PIK3CA"], gene_count=3,
                                        background_size=20000, p_value=0.01, p_adjusted=0.04,
                                        correction_method="BH"))


def test_published_requires_venue_and_year(session):
    d = seed(session)
    expect_integrity(session, m.Publication(organization_id=d["org"].id, title="T", status=PublicationStatus.PUBLISHED))


def test_audit_log_is_append_only(session):
    d = seed(session)
    log = m.AuditLog(actor_id=d["user"].id, organization_id=d["org"].id, action="dataset.upload",
                     resource_type="dataset", resource_id=str(d["dataset"].id), ip_address="127.0.0.1")
    session.add(log); session.flush()
    for stmt in ("UPDATE audit_logs SET action = 'tampered' WHERE id = :i", "DELETE FROM audit_logs WHERE id = :i"):
        with pytest.raises(DBAPIError):
            session.execute(text(stmt), {"i": log.id})
        session.rollback()


def test_deleting_user_anonymises_audit_trail(session):
    d = seed(session)
    temp = m.User(email=f"{uuid.uuid4().hex[:8]}@example.org", password_hash="x", role_id=d["role"].id)
    session.add(temp); session.flush()
    log = m.AuditLog(actor_id=temp.id, action="login", resource_type="user")
    session.add(log); session.flush()
    session.execute(text("DELETE FROM users WHERE id = :i"), {"i": temp.id})
    row = session.execute(text("SELECT actor_id, action FROM audit_logs WHERE id = :i"), {"i": log.id}).one()
    assert row.actor_id is None and row.action == "login"
