"""Integration fixtures. Require a real PostgreSQL in TEST_DATABASE_URL.

Without it the tests are skipped, unless REQUIRE_DB=1, in which case they fail.
scripts/step2_verify.sh sets REQUIRE_DB=1 so skips can never be reported as passes.
"""
import os

import pytest
from alembic import command
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from tests.integration.helpers import alembic_config


def _url():
    url = os.environ.get("TEST_DATABASE_URL")
    if not url or not url.startswith("postgresql"):
        if os.environ.get("REQUIRE_DB") == "1":
            pytest.fail("REQUIRE_DB=1 but TEST_DATABASE_URL is not a PostgreSQL URL")
        pytest.skip("TEST_DATABASE_URL not set; integration tests need PostgreSQL")
    return url


@pytest.fixture(scope="session")
def db_url():
    return _url()


@pytest.fixture(scope="session")
def migrated_engine(db_url):
    cfg = alembic_config(db_url)
    command.downgrade(cfg, "base")
    command.upgrade(cfg, "head")
    engine = create_engine(db_url, future=True)
    yield engine
    engine.dispose()


@pytest.fixture()
def session(migrated_engine):
    """Each test runs in a transaction that is rolled back afterwards."""
    conn = migrated_engine.connect()
    outer = conn.begin()
    s = Session(bind=conn, join_transaction_mode="create_savepoint")
    try:
        yield s
    finally:
        s.close()
        outer.rollback()
        conn.close()
