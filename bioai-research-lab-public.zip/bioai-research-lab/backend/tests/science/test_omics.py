import numpy as np
import pandas as pd

from app.science.common import ScienceError
from app.science.omics.preprocess import AmbiguousOrientation, differential_expression, integrate_layers, orient, preprocess
from tests.science._util import raises


def matrix():
    rng = np.random.default_rng(0)
    return pd.DataFrame(rng.normal(5, 1, (6, 12)), index=[f"g{i}" for i in range(6)], columns=[f"s{i}" for i in range(12)])


def test_orientation_inferred_both_ways_and_ambiguity_raises():
    m = matrix()
    ids = [f"s{i}" for i in range(12)]
    a, info = orient(m, ids)
    assert a.shape == (12, 6) and info["orientation"] == "GENES_AS_ROWS" and not info["orientation_confirmed"]
    b, info2 = orient(m.T, ids)
    assert b.shape == (12, 6) and info2["orientation"] == "SAMPLES_AS_ROWS"
    with raises(AmbiguousOrientation):
        orient(m, ["unknown"])
    c, info3 = orient(m, ["unknown"], orientation="GENES_AS_ROWS")
    assert info3["orientation_confirmed"]


def test_preprocess_lists_every_removed_feature():
    x = orient(matrix(), [f"s{i}" for i in range(12)])[0]
    x["g0"] = np.nan
    x["g1"] = 3.0
    out, log = preprocess(x, max_missing=0.2)
    assert log["removed"]["missing_above_threshold"] == ["g0"] and log["removed"]["zero_variance"] == ["g1"]
    assert log["original_features"] - log["filtered_features"] == 2


def test_duplicate_samples_rejected():
    x = orient(matrix(), [f"s{i}" for i in range(12)])[0]
    with raises(ScienceError, "Duplicate sample"):
        preprocess(pd.concat([x, x.iloc[:1]]))


def test_differential_expression_finds_planted_feature():
    rng = np.random.default_rng(1)
    x = pd.DataFrame(rng.normal(0, 1, (40, 30)), columns=[f"g{i}" for i in range(30)])
    grp = pd.Series(["A"] * 20 + ["B"] * 20)
    x.loc[20:, "g5"] += 3
    de = differential_expression(x, grp, "A", "B")
    assert de.iloc[0].feature == "g5" and de.iloc[0].log2_fold_change > 2 and de.iloc[0].significant
    assert (de.p_adjusted >= de.p_value).all()


def test_integration_reports_unshared_samples():
    a = pd.DataFrame(np.ones((8, 2)), index=[f"s{i}" for i in range(8)], columns=["x", "y"])
    b = pd.DataFrame(np.ones((7, 2)), index=[f"s{i}" for i in range(1, 8)], columns=["x", "y"])
    m, rep = integrate_layers({"rna": a, "meth": b})
    assert m.shape == (7, 4) and rep["layers"]["rna"]["samples_not_shared"] == ["s0"]
    assert "rna::x" in m.columns and "meth::x" in m.columns
