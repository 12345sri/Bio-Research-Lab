import numpy as np
import pandas as pd
from scipy import stats

from app.science.common import ScienceError
from app.science.explain.explainer import explain, linear_shap
from app.science.ml.engine import FoldPipeline
from app.science.network.networks import correlation_network, edge_list_network
from app.science.pathway.enrichment import enrich, parse_gmt
from tests.science._util import raises


def fitted_lr(seed=0):
    rng = np.random.default_rng(seed)
    X = pd.DataFrame(rng.normal(size=(200, 5)), columns=list("abcde"))
    y = (X.a * 2 - X.b + rng.normal(0, 1, 200) > 0).astype(int).to_numpy()
    return FoldPipeline("LOGISTIC_REGRESSION", {}, seed).fit(X, y), X, y


def test_linear_shap_is_exactly_additive():
    pipe, X, _ = fitted_lr()
    sh = linear_shap(pipe, X)
    logit = pipe.model_.decision_function(pipe.transform(X))
    assert np.allclose(sh["base_value"] + sh["values"].sum(axis=1), logit)


def test_explanations_carry_caveat_and_label():
    pipe, X, y = fitted_lr(1)
    e = explain(pipe, X, y, seed=0)
    assert e["evidence_label"] == "EXPLANATION"
    assert e["global"]["label"] == "MODEL FEATURE IMPORTANCE"
    assert "not establish biological" in e["global"]["caveat"]
    assert e["global"]["ranking"][0]["feature"] == "a"


def test_non_linear_model_without_shap_library_is_honest():
    rng = np.random.default_rng(2)
    X = pd.DataFrame(rng.normal(size=(120, 4)), columns=list("wxyz"))
    y = (X.w > 0).astype(int).to_numpy()
    pipe = FoldPipeline("RANDOM_FOREST", {"params": {"RANDOM_FOREST": {"n_estimators": 50}}}, 0).fit(X, y)
    e = explain(pipe, X, y, seed=0)
    try:
        import shap  # noqa: F401
        assert e["shap_available"]
    except ImportError:
        assert e["shap_available"] is False and "not installed" in e["shap_unavailable_reason"]
        assert e["permutation"]["ranking"][0]["feature"] == "w"


def test_correlation_network_edges_are_labelled_correlation():
    rng = np.random.default_rng(3)
    base = rng.normal(size=100)
    X = pd.DataFrame({"g1": base, "g2": base + rng.normal(0, 0.1, 100), "g3": rng.normal(size=100),
                      "g4": rng.normal(size=100)})
    n = correlation_network(X, threshold=0.8)
    assert n["n_edges"] == 1 and n["edges"][0]["edge_type"] == "CORRELATION"
    assert "not regulation" in n["edge_meaning"]
    with raises(ScienceError):
        correlation_network(X, [])


def test_curated_edges_must_cite_source():
    e = pd.DataFrame({"source_node": ["A"], "target_node": ["B"]})
    with raises(ScienceError, "cite"):
        edge_list_network(e, "KNOWN_INTERACTION", "")
    assert edge_list_network(e, "KNOWN_INTERACTION", "user-supplied PPI v1")["n_edges"] == 1


def test_enrichment_matches_manual_hypergeometric_and_is_adjusted():
    bg = [f"G{i}" for i in range(100)]
    sets = parse_gmt("S1\tset one\t" + "\t".join(f"G{i}" for i in range(10)) + "\n"
                     "S2\tset two\t" + "\t".join(f"G{i}" for i in range(50, 60)))
    r = enrich([f"G{i}" for i in range(8)] + ["G70", "G71"], bg, sets, database="TEST")
    t = r["table"].set_index("pathway_id")
    assert abs(t.loc["S1", "p_value"] - stats.hypergeom.sf(7, 100, 10, 10)) < 1e-15
    assert t.loc["S1", "gene_count"] == len(t.loc["S1", "genes"]) == 8
    assert (t.p_adjusted >= t.p_value).all() and set(t.correction_method) == {"Benjamini-Hochberg"}
    with raises(ScienceError, "background"):
        enrich(["NOT_MEASURED"], bg, sets, database="TEST")
