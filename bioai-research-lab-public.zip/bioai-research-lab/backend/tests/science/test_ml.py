"""Machine-learning integrity: leakage, grouping, reproducibility, warnings, external validation."""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score

from app.science.ml.engine import FoldPipeline, train_and_evaluate
from app.science.ml.metrics import binary_metrics
from app.science.ml.smote import smote
from app.science.validation.external import NotIndependent, check_independence
from tests.science._util import raises


def noise_data(n=150, p=15, minority=0.2, seed=0):
    rng = np.random.default_rng(seed)
    X = pd.DataFrame(rng.normal(size=(n, p)), columns=[f"f{i}" for i in range(p)], index=[f"s{i}" for i in range(n)])
    y = pd.Series(np.where(rng.random(n) < minority, "POS", "NEG"), index=X.index)
    return X, y


def test_smote_inside_folds_does_not_inflate_performance_on_noise():
    """Pure-noise features: the correct pipeline must be near chance; SMOTE-before-split must look better.

    This demonstrates the leakage the platform prevents (and the flaw in resampling before splitting).
    """
    X, y = noise_data()
    cfg = {"positive_class": "POS", "algorithms": ["RANDOM_FOREST"], "resampling": "SMOTE", "cv_folds": 5,
           "random_seed": 0, "params": {"RANDOM_FOREST": {"n_estimators": 100}}}
    safe = train_and_evaluate(X, y, cfg)["models"]["RANDOM_FOREST"]["cv"]["roc_auc"]["mean"]
    Xs, ys, _ = smote(X.to_numpy(), (y == "POS").astype(int).to_numpy(), seed=0)  # WRONG: before splitting
    leaky = cross_val_score(RandomForestClassifier(n_estimators=100, random_state=0), Xs, ys,
                            cv=StratifiedKFold(5, shuffle=True, random_state=0), scoring="roc_auc").mean()
    assert 0.3 < safe < 0.7, safe
    assert leaky > safe + 0.15, (leaky, safe)


def test_resampling_recorded_as_training_only_and_test_untouched():
    X, y = noise_data(seed=1)
    r = train_and_evaluate(X, y, {"positive_class": "POS", "algorithms": ["LOGISTIC_REGRESSION"],
                                  "resampling": "SMOTE", "cv_folds": 3, "random_seed": 1})
    res = r["models"]["LOGISTIC_REGRESSION"]["resampling"]["final"]
    assert res["scope"] == "TRAINING_FOLDS_ONLY" and res["synthetic"] > 0
    d = r["split"]["distribution"]
    assert r["models"]["LOGISTIC_REGRESSION"]["test"]["n"] == d["test"]["positive"] + d["test"]["negative"]
    assert not set(r["split"]["train_ids"]) & set(r["split"]["test_ids"])


def test_participant_grouped_split_never_shares_participants():
    rng = np.random.default_rng(2)
    groups = np.repeat([f"P{i}" for i in range(20)], 6)
    X = pd.DataFrame(rng.normal(size=(120, 4)), columns=list("abcd"), index=[f"w{i}" for i in range(120)])
    y = pd.Series(np.tile(["A", "A", "A", "B", "B", "B"], 20), index=X.index)
    r = train_and_evaluate(X, y, {"positive_class": "B", "algorithms": ["LOGISTIC_REGRESSION"], "cv_folds": 4,
                                  "random_seed": 2}, groups=groups)
    g = pd.Series(groups, index=X.index)
    assert not set(g[r["split"]["train_ids"]]) & set(g[r["split"]["test_ids"]])
    assert r["split"]["strategy"] == "PARTICIPANT"


def test_same_seed_reproduces_exactly():
    X, y = noise_data(seed=3)
    cfg = {"positive_class": "POS", "algorithms": ["RANDOM_FOREST", "LOGISTIC_REGRESSION"], "cv_folds": 3,
           "random_seed": 11, "resampling": "SMOTE", "params": {"RANDOM_FOREST": {"n_estimators": 50}}}
    a, b = train_and_evaluate(X, y, cfg), train_and_evaluate(X, y, cfg)
    for algo in cfg["algorithms"]:
        assert a["models"][algo]["test"]["roc_auc"] == b["models"][algo]["test"]["roc_auc"]
        assert a["models"][algo]["cv"] == b["models"][algo]["cv"]


def test_imputation_statistics_come_from_training_data_only():
    X, y = noise_data(seed=4)
    X.iloc[:5, 0] = np.nan
    tr = X.iloc[:100]
    pipe = FoldPipeline("LOGISTIC_REGRESSION", {}, 0).fit(tr, (y.iloc[:100] == "POS").astype(int).to_numpy())
    assert np.allclose(pipe.imputer_.statistics_, tr.median().to_numpy())


def test_majority_class_predictions_are_flagged():
    y = np.array([0] * 83 + [1] * 17)
    m = binary_metrics(y, np.full(100, 0.1) + np.linspace(0, 0.01, 100))
    assert any("baseline" in w for w in m["warnings"])
    assert any("one class" in w for w in m["warnings"])


def test_smote_synthetics_lie_between_minority_neighbours():
    rng = np.random.default_rng(5)
    X = np.vstack([rng.normal(0, 1, (40, 2)), rng.normal(10, 0.1, (8, 2))])
    y = np.array([0] * 40 + [1] * 8)
    Xr, yr, info = smote(X, y, seed=0)
    assert info["after"] == {"0": 40, "1": 40}
    assert np.all(np.abs(Xr[48:] - 10) < 1)  # synthetic points stay in the minority region


def test_external_validation_rejects_reused_data():
    X, _ = noise_data(seed=6)
    with raises(NotIndependent, "same dataset"):
        check_independence(X, X.copy(), "ds1", "ds1")
    with raises(NotIndependent, "sample IDs"):
        check_independence(X.iloc[:100], X.iloc[90:])
    renamed = X.iloc[:10].copy(); renamed.index = [f"new{i}" for i in range(10)]
    with raises(NotIndependent, "identical"):
        check_independence(X, renamed)
