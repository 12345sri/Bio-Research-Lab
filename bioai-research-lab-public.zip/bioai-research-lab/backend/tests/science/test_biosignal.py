import numpy as np

from app.science.biosignal.ecg import detect_r_peaks
from app.science.biosignal.hrv import frequency_domain, time_domain
from app.science.biosignal.pseudonymize import pseudonymize
from app.science.biosignal.qc import qc_rr
from app.science.common import ScienceError
from app.science.demo_data import synthetic_ecg, synthetic_rr
from tests.science._util import raises

KEY = "k" * 32


def test_pseudonym_deterministic_keyed_and_opaque():
    a = pseudonymize("student_01", KEY)
    assert a == pseudonymize("student_01", KEY)
    assert a != pseudonymize("student_01", "x" * 32)
    assert "student" not in a and a.startswith("P-")
    with raises(ScienceError):
        pseudonymize("student_01", "short")


def test_qc_classifies_every_observation():
    rr = [800, 810, 805, "bad", np.nan, 5000, 800, 1400, 795, 805] + [800] * 30
    q = qc_rr(rr)
    assert q["n_valid"] + q["n_excluded"] == q["n_total"] == len(rr)
    assert len(q["reasons"]) == len(rr)
    assert q["reasons"][3] == "non_numeric" and q["reasons"][4] == "missing"
    assert q["reasons"][5] == "out_of_range" and q["reasons"][7] == "artifact"
    assert sum(q["exclusion_reasons"].values()) == q["n_excluded"]


def test_time_domain_matches_hand_calculation():
    rr = np.array([800.0, 820, 780, 800, 810])
    td = time_domain(rr, np.ones(5, bool))
    assert abs(td["mean_rr_ms"] - 802) < 1e-9
    assert abs(td["sdnn_ms"] - np.std(rr, ddof=1)) < 1e-9
    assert abs(td["rmssd_ms"] - np.sqrt(np.mean(np.diff(rr) ** 2))) < 1e-9
    assert abs(td["max_hr_bpm"] - 60000 / 780) < 1e-9


def test_rmssd_ignores_pairs_spanning_excluded_beats():
    v = np.array([800.0, 810, 2500, 805, 815])
    m = np.array([True, True, False, True, True])
    td = time_domain(v, m)
    assert td["n_successive_pairs"] == 2
    assert abs(td["rmssd_ms"] - np.sqrt((10 ** 2 + 10 ** 2) / 2)) < 1e-9


def test_frequency_bands_follow_the_signal():
    rng = np.random.default_rng(0)
    lf = synthetic_rr(400, 850, 40, 5, 2, rng)
    hf = synthetic_rr(400, 850, 5, 40, 2, rng)
    ok = np.ones(400, bool)
    assert frequency_domain(lf, ok)["lf_hf_ratio"] > 3
    assert frequency_domain(hf, ok)["lf_hf_ratio"] < 0.33


def test_frequency_domain_refused_when_invalid():
    rng = np.random.default_rng(1)
    short = synthetic_rr(100, 850, 20, 20, 5, rng)  # about 85 s
    r = frequency_domain(short, np.ones(100, bool))
    assert r["frequency_domain_valid"] is False
    assert r["lf_hf_ratio"] is None and r["lf_power_ms2"] is None and r["hf_power_ms2"] is None
    assert "shorter" in r["frequency_domain_note"]
    long = synthetic_rr(400, 850, 20, 20, 5, rng)
    mask = np.ones(400, bool); mask[::10] = False  # 10% excluded
    r2 = frequency_domain(long, mask)
    assert r2["frequency_domain_valid"] is False and "excluded" in r2["frequency_domain_note"]


def test_ecg_rpeak_detection_recovers_rr():
    rng = np.random.default_rng(3)
    true_rr = synthetic_rr(70, 820, 30, 20, 5, rng)
    out = detect_r_peaks(synthetic_ecg(true_rr, fs=250), fs=250)
    det = out["rr_ms"]
    n = min(len(det), len(true_rr) - 1)
    assert abs(len(det) - (len(true_rr) - 1)) <= 1
    assert np.median(np.abs(det[:n] - true_rr[1:n + 1])) < 8  # within two samples at 250 Hz
    assert out["signal_type_validated"]


def test_non_ecg_signal_rejected():
    rng = np.random.default_rng(4)
    with raises(ScienceError):
        detect_r_peaks(rng.standard_normal(250 * 30), fs=250)
    with raises(ScienceError, "at least 100 Hz"):
        detect_r_peaks(np.zeros(5000), fs=50)
