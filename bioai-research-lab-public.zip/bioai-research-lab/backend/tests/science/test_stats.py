import numpy as np
from scipy import stats

from app.science.common import ScienceError
from app.science.stats.tests import bh_adjust, compare_independent, compare_paired
from tests.science._util import raises


def test_bh_known_values():
    p = [0.01, 0.04, 0.03, 0.005]
    # sorted: .005 .01 .03 .04 -> *4/rank: .02 .02 .04 .04
    assert np.allclose(bh_adjust(p), [0.02, 0.04, 0.04, 0.02])
    assert np.all(bh_adjust(np.random.default_rng(0).random(50)) <= 1)


def test_paired_t_matches_scipy_and_reports_everything():
    rng = np.random.default_rng(1)
    a = rng.normal(0, 1, 30); b = a + 0.5 + rng.normal(0, 0.5, 30)
    r = compare_paired(a, b, method="paired_t", override_reason="pre-registered")
    assert abs(r["p_value"] - stats.ttest_rel(b, a).pvalue) < 1e-12
    for k in ("test", "reason", "n", "statistic", "p_value", "effect_size", "ci_low", "ci_high", "assumptions"):
        assert r[k] is not None
    assert r["ci_low"] < r["estimate"] < r["ci_high"] and r["researcher_override"]


def test_auto_selects_nonparametric_for_skewed_differences():
    rng = np.random.default_rng(2)
    a = rng.normal(0, 1, 25); b = a + rng.exponential(1, 25) ** 3
    assert compare_paired(a, b)["test"].startswith("Wilcoxon")


def test_override_requires_reason():
    with raises(ScienceError, "reason"):
        compare_paired([1, 2, 3, 4], [2, 3, 4, 6], method="paired_t")


def test_independent_welch():
    rng = np.random.default_rng(3)
    a, b = rng.normal(0, 1, 40), rng.normal(1, 2, 40)
    r = compare_independent(a, b, method="welch", override_reason="normal by design")
    assert abs(r["p_value"] - stats.ttest_ind(b, a, equal_var=False).pvalue) < 1e-12
    assert r["effect_size_type"] == "Hedges' g"
