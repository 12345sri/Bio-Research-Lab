"""The full demonstration workflow exports every report format, is reproducible and stays honest."""
import importlib.util
import json
import pathlib
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[3]


def _run_demo(out):
    spec = importlib.util.spec_from_file_location("run_demo", ROOT / "scripts/run_demo.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.main(out)


def _strip_times(d):
    if isinstance(d, dict):
        return {k: _strip_times(v) for k, v in d.items() if k != "generated_at"}
    if isinstance(d, list):
        return [_strip_times(x) for x in d]
    return d


def test_demo_exports_all_formats_reproducibly_with_honest_labels():
    with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
        s1, s2 = _run_demo(a), _run_demo(b)
        assert s1["config_hashes"] == s2["config_hashes"]
        for platform in ("biosignal", "omics"):
            for fmt, path in s1[platform].items():
                p = pathlib.Path(path)
                assert p.is_file() and p.stat().st_size > 0, (platform, fmt)
            r1 = json.loads(pathlib.Path(s1[platform]["json"]).read_text())
            r2 = json.loads(pathlib.Path(s2[platform]["json"]).read_text())
            assert _strip_times(r1) == _strip_times(r2), f"{platform} report not reproducible"
            assert r1["demo"] is True
            html = pathlib.Path(s1[platform]["html"]).read_text().lower()
            assert "demonstration" in html or "demo" in html
            assert "not a diagnosis" in html
        omics_html = pathlib.Path(s1["omics"]["html"]).read_text()
        assert omics_html.count("Models are ranked by cross-validated ROC-AUC") == 1
        assert "not regulation or causation" in omics_html
