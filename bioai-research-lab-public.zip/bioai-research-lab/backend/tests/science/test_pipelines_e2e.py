"""End-to-end scientific workflow on DEMONSTRATION DATA."""
import json

from app.science import demo_data as dd
from app.science.common import EVIDENCE_LABELS, clean
from app.science.pipelines import run_biosignal, run_omics

KEY = "demo-key-not-secret-0123456789"
BIO_CFG = {"random_seed": 7, "window_s": 60,
           "ml": {"algorithms": ["LOGISTIC_REGRESSION"], "positive_class": "EXAM_DAY", "cv_folds": 3, "test_size": 0.25}}
OMICS_CFG = {"group_column": "stage", "positive_class": "LATE", "negative_class": "EARLY", "random_seed": 42,
             "ml": {"algorithms": ["LOGISTIC_REGRESSION"], "resampling": "SMOTE", "select_k_best": 30, "cv_folds": 3},
             "network": {"threshold": 0.4}, "dataset_id": "train", "external_dataset_id": "external"}


def _serialise(res):
    return json.dumps(clean({k: (v.to_dict("records") if hasattr(v, "to_dict") else v)
                             for k, v in res.items() if not k.startswith("_")}), default=str)


def test_biosignal_workflow_pseudonymised_labelled_reproducible():
    df = dd.biosignal_demo(n_participants=6)
    a = run_biosignal(df, BIO_CFG, KEY)
    b = run_biosignal(df, BIO_CFG, KEY)
    s = _serialise(a)
    assert "student_" not in s  # raw identifiers never appear in results
    assert all(f["evidence_label"] in EVIDENCE_LABELS for f in a["findings"])
    assert (a["sessions"].n_valid + a["sessions"].n_excluded == a["sessions"].n_total).all()
    assert a["provenance"]["config_hash"] == b["provenance"]["config_hash"]
    assert a["provenance"]["input_hashes"] == b["provenance"]["input_hashes"]
    assert [c.get("p_value") for c in a["comparisons"]] == [c.get("p_value") for c in b["comparisons"]]
    invalid = a["sessions"][~a["sessions"].frequency_domain_valid]
    assert invalid.lf_hf_ratio.isna().all()


def test_omics_workflow_through_external_validation():
    expr, meta = dd.omics_demo(n_samples=120, n_genes=150)
    eexpr, emeta = dd.omics_demo(n_samples=60, n_genes=150, seed=99, prefix="V")
    r = run_omics(expr, meta, OMICS_CFG, gmt_text=dd.gene_sets_demo(150), external=(eexpr, emeta))
    assert r["external_validation"]["independence"]["independent"]
    assert r["external_validation"]["role"] == "EXTERNAL_VALIDATION"
    lr = r["ml"]["models"]["LOGISTIC_REGRESSION"]
    assert lr["resampling"]["final"]["scope"] == "TRAINING_FOLDS_ONLY"
    assert r["network"]["edge_type"] == "CORRELATION"
    if r["pathway"] is not None:
        assert (r["pathway"]["table"].p_adjusted >= r["pathway"]["table"].p_value).all()
    assert any(f["evidence_label"] == "HYPOTHESIS" for f in r["findings"])
    assert "diagnos" not in " ".join(f["statement"].lower() for f in r["findings"] if f["evidence_label"] != "HYPOTHESIS")


def test_copilot_review_works_on_results_reloaded_from_storage():
    """The API feeds the copilot JSON results from the database, not in-memory DataFrames."""
    from app.science.copilot.copilot import evidence, review
    df = dd.biosignal_demo(n_participants=4)
    stored = json.loads(_serialise(run_biosignal(df, BIO_CFG, KEY)))
    codes = {i["code"] for i in review(stored)}
    assert "SMALL_SAMPLE" in codes
    assert evidence(stored)
    expr, meta = dd.omics_demo(n_samples=80, n_genes=60)
    stored = json.loads(_serialise(run_omics(expr, meta, {**OMICS_CFG, "external_dataset_id": None})))
    assert "NO_EXTERNAL_VALIDATION" in {i["code"] for i in review(stored)}


def test_copilot_accepts_grounded_and_withholds_fabricated_answers_on_stored_results():
    """verify() is the real guard; the language model is replaced by fixed text so the guard itself is tested."""
    from app.science.copilot.copilot import answer, evidence
    expr, meta = dd.omics_demo(n_samples=80, n_genes=60)
    stored = json.loads(_serialise(run_omics(expr, meta, {**OMICS_CFG, "external_dataset_id": None})))
    ev = evidence(stored)
    grounded = f"[INTERPRETATION] {ev[-1]['statement']} ({ev[-1]['id']})"
    ok = answer("limitations?", stored, llm=lambda prompt: grounded)
    assert ok["status"] == "GROUNDED" and ok["answer"] == grounded
    fabricated = "[MODEL] The model reached ROC-AUC 0.9731 and proves the gene causes late stage."
    bad = answer("performance?", stored, llm=lambda prompt: fabricated)
    assert bad["status"] == "REJECTED_UNGROUNDED" and bad["answer"] is None
    assert any("0.9731" in p for p in bad["verification"]["problems"])
    assert any("prove" in p.lower() or "cause" in p.lower() for p in bad["verification"]["problems"])
    unlabelled = answer("x?", stored, llm=lambda prompt: "The results look good.")
    assert unlabelled["status"] == "REJECTED_UNGROUNDED"


def test_nested_tables_serialise_as_row_records_not_strings():
    """Stored results must keep nested tables (e.g. pathway enrichment) as lists of rows for the API and UI."""
    import pandas as pd
    from app.science.common import clean
    out = json.loads(json.dumps(clean({"pathway": {"table": pd.DataFrame({"a": [1, 2], "b": [0.5, float("nan")]})}}), default=str))
    assert out["pathway"]["table"] == [{"a": 1, "b": 0.5}, {"a": 2, "b": None}]
    expr, meta = dd.omics_demo()
    stored = json.loads(_serialise(run_omics(expr, meta, {**OMICS_CFG, "external_dataset_id": None}, gmt_text=dd.gene_sets_demo())))
    assert stored["pathway"] is not None and isinstance(stored["pathway"]["table"], list)
    assert all(isinstance(r, dict) and "p_adjusted" in r for r in stored["pathway"]["table"])
