import contextlib


@contextlib.contextmanager
def raises(exc, match: str | None = None):
    try:
        yield
    except exc as e:
        if match and match.lower() not in str(e).lower():
            raise AssertionError(f"expected message containing {match!r}, got {e!r}")
        return
    raise AssertionError(f"{exc.__name__} not raised")
