from app.services.permissions import ACTIONS, can, can_create_project, can_view_individual_physiology
from tests.science._util import raises


def test_founders_and_admin_have_org_wide_access_only_in_their_org():
    for role in ("FOUNDER", "CO_FOUNDER", "ADMIN"):
        for action in ACTIONS:
            assert can(action, org_role=role, same_org=True, project_role=None, project_privacy="CONFIDENTIAL")
        assert not can("dataset.read", org_role=role, same_org=False, project_role=None,
                       project_privacy="CONFIDENTIAL")


def test_non_members_cannot_touch_private_projects():
    for action in ACTIONS:
        for privacy in ("INTERNAL", "CONFIDENTIAL", "RESTRICTED_HUMAN_DATA"):
            assert not can(action, org_role="RESEARCHER", same_org=True, project_role=None, project_privacy=privacy)


def test_public_projects_expose_results_never_data():
    assert can("report.read", org_role="RESEARCHER", same_org=False, project_role=None, project_privacy="PUBLIC")
    for action in ("dataset.read", "dataset.download", "experiment.run", "comment.create", "audit.read"):
        assert not can(action, org_role="RESEARCHER", same_org=False, project_role=None, project_privacy="PUBLIC")


def test_project_role_ladder():
    kw = dict(org_role="RESEARCHER", same_org=True, project_privacy="INTERNAL")
    assert not can("experiment.run", project_role="VIEWER", **kw)
    assert not can("dataset.upload", project_role="REVIEWER", **kw)
    assert can("report.approve", project_role="REVIEWER", **kw)
    assert can("experiment.run", project_role="CONTRIBUTOR", **kw)
    assert not can("member.manage", project_role="CONTRIBUTOR", **kw)
    assert can("member.manage", project_role="LEAD", **kw)
    assert not can("project.archive", project_role="LEAD", **kw)
    assert can("project.archive", project_role="OWNER", **kw)


def test_org_viewer_never_gains_write_through_project_role():
    assert not can("experiment.run", org_role="VIEWER", same_org=True, project_role="OWNER", project_privacy="INTERNAL")
    assert can("report.read", org_role="VIEWER", same_org=True, project_role="OWNER", project_privacy="INTERNAL")
    assert not can_create_project("VIEWER") and can_create_project("RESEARCHER")


def test_employers_never_see_individual_physiology():
    assert not can_view_individual_physiology(org_role="FOUNDER", same_org=True, project_role="OWNER",
                                              requester_is_employer_context=True)


def test_unknown_action_rejected():
    with raises(ValueError):
        can("dataset.steal", org_role="ADMIN", same_org=True, project_role=None, project_privacy="PUBLIC")
