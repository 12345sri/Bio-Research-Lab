from datetime import timedelta

from app.core.security import (AuthError, create_token, decode_token, hash_one_time_token, hash_password,
                               needs_rehash, new_one_time_token, validate_password_strength, verify_password)
from tests.science._util import raises

SECRET = "x" * 48


def test_password_hash_roundtrip_salted_and_not_plaintext():
    h1, h2 = hash_password("Correct-Horse-9"), hash_password("Correct-Horse-9")
    assert h1 != h2 and "Correct-Horse-9" not in h1
    assert verify_password("Correct-Horse-9", h1)
    assert not verify_password("correct-horse-9", h1)
    assert not verify_password("anything", "garbage")
    assert not needs_rehash(h1)
    assert needs_rehash("scrypt$1024$8$1$aa$bb")


def test_password_policy():
    for bad in ("Short1a", "alllowercase123", "ALLUPPERCASE123", "NoDigitsHereAtAll", "Tanjidul2026Pass"):
        with raises(ValueError):
            validate_password_strength(bad, "tanjidul@example.org")
    validate_password_strength("Research-Lab-2026", "tanjidul@example.org")


def test_tokens_typed_expiring_and_tamper_evident():
    t = create_token("user-1", "access", SECRET, timedelta(minutes=5), role="RESEARCHER")
    assert decode_token(t, SECRET, "access")["role"] == "RESEARCHER"
    with raises(AuthError):
        decode_token(t, SECRET, "refresh")          # type confusion blocked
    with raises(AuthError):
        decode_token(t, "y" * 48, "access")          # wrong secret
    with raises(AuthError):
        decode_token(t[:-2] + "aa", SECRET, "access")  # tampered signature
    expired = create_token("user-1", "access", SECRET, timedelta(seconds=-1))
    with raises(AuthError):
        decode_token(expired, SECRET, "access")
    with raises(ValueError):
        create_token("u", "access", "short", timedelta(minutes=1))


def test_one_time_tokens_store_only_hash():
    token, stored = new_one_time_token()
    assert token != stored and len(stored) == 64
    assert hash_one_time_token(token) == stored
