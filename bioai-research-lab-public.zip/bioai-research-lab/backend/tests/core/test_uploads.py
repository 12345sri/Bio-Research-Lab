from app.services.uploads import UploadRejected, csv_safe, safe_filename, validate_upload
from tests.science._util import raises


def test_valid_csv_schema_and_hash():
    info = validate_upload("../../etc/rr data.csv", b"participant,condition,rr_ms\nA,NORMAL,812\nA,NORMAL,830\n")
    assert info.safe_filename == "rr_data.csv" and info.file_type == "CSV"
    assert (info.n_rows, info.n_columns) == (2, 3)
    assert info.column_schema == {"participant": "text", "condition": "text", "rr_ms": "numeric"}
    assert len(info.sha256) == 64


def test_single_column_txt_rr_file_accepted_with_warning():
    info = validate_upload("rr.txt", b"812\n845\n830\n")
    assert info.n_rows == 3 and info.n_columns == 1 and info.warnings


def test_rejections():
    cases = [("x.xlsx", b"a,b\n1,2\n"), ("x.csv", b""), ("x.csv", b"PK\x03\x04rest"), ("x.csv", b"%PDF-1.4"),
             ("x.csv", b"a,b\n1,2\x00\n"), ("x.csv", "a,b\n1,\xe9\n".encode("latin-1")),
             ("x.csv", b"a,b\n1,2,3\n"), ("x.csv", b"a,a\n1,2\n"), ("x.csv", b"a,b\n")]
    for name, data in cases:
        with raises(UploadRejected):
            validate_upload(name, data)
    with raises(UploadRejected):
        validate_upload("big.csv", b"a\n" + b"1\n" * 100, max_bytes=50)


def test_formula_injection_neutralised_but_negative_numbers_kept():
    assert csv_safe("=HYPERLINK(\"http://x\")").startswith("'")
    assert csv_safe("@SUM(A1)").startswith("'")
    assert csv_safe("-3.5") == "-3.5"
    assert csv_safe(None) == ""


def test_safe_filename():
    assert safe_filename("..\\..\\evil.csv") == "evil.csv"
    assert safe_filename("") == "upload"


def test_gene_set_gmt_files_validated_as_gene_sets():
    gmt = b"SET_A\tdemo set\tG1\tG2\tG3\nSET_B\tdemo\tG4\tG5\n"
    for name in ("sets.gmt", "sets.txt"):
        info = validate_upload(name, gmt)
        assert info.n_rows == 2 and info.column_schema["format"] == "GMT"
    with raises(UploadRejected):
        validate_upload("sets.gmt", b"SET_A\tdesc\n")            # no genes
    with raises(UploadRejected):
        validate_upload("sets.gmt", b"S\td\tG1\nS\td\tG2\n")     # duplicate set name
