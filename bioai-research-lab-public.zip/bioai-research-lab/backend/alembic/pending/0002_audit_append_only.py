"""Make audit_logs append-only.

Revision ID: 0002_audit_append_only
Revises: 0001_initial_schema
"""
from alembic import op

revision = "0002_audit_append_only"
down_revision = "0001_initial_schema"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
        CREATE OR REPLACE FUNCTION audit_logs_block_mutation() RETURNS trigger AS $$
        BEGIN
            -- Allow only the FK-driven anonymisation (ON DELETE SET NULL of actor/organization);
            -- every other field must stay identical.
            IF TG_OP = 'UPDATE'
               AND (NEW.actor_id IS NULL OR NEW.actor_id = OLD.actor_id)
               AND (NEW.organization_id IS NULL OR NEW.organization_id = OLD.organization_id)
               AND (to_jsonb(NEW) - 'actor_id' - 'organization_id')
                   = (to_jsonb(OLD) - 'actor_id' - 'organization_id') THEN
                RETURN NEW;
            END IF;
            RAISE EXCEPTION 'audit_logs is append-only (% blocked)', TG_OP
                USING ERRCODE = 'insufficient_privilege';
        END;
        $$ LANGUAGE plpgsql;
    """)
    op.execute("""
        CREATE TRIGGER audit_logs_no_update_delete
        BEFORE UPDATE OR DELETE ON audit_logs
        FOR EACH ROW EXECUTE FUNCTION audit_logs_block_mutation();
    """)
    op.execute("""
        CREATE TRIGGER audit_logs_no_truncate
        BEFORE TRUNCATE ON audit_logs
        FOR EACH STATEMENT EXECUTE FUNCTION audit_logs_block_mutation();
    """)


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS audit_logs_no_truncate ON audit_logs")
    op.execute("DROP TRIGGER IF EXISTS audit_logs_no_update_delete ON audit_logs")
    op.execute("DROP FUNCTION IF EXISTS audit_logs_block_mutation()")
