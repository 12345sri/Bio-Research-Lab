"use client";
import { useEffect, useState } from "react";
import Shell from "@/components/Shell";
import { Button, Card, ErrorBox, Field, inputCls } from "@/components/ui";
import { api, post } from "@/lib/api";

const DISCIPLINES = ["BIOMEDICAL_SCIENCE", "BIOINFORMATICS", "AI_ML", "STATISTICS", "SOFTWARE_ENGINEERING"];

function Teams() {
  const [teams, setTeams] = useState<any[]>([]);
  const [form, setForm] = useState({ name: "", discipline: "BIOMEDICAL_SCIENCE", description: "" });
  const [emails, setEmails] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const load = () => api("/teams").then(setTeams).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Research teams</h1>
      <ErrorBox error={error} />
      <Card title="Create a team">
        <form className="grid gap-4 md:grid-cols-3" onSubmit={async (e) => { e.preventDefault(); setError(null); try { await post("/teams", form); setForm({ ...form, name: "", description: "" }); load(); } catch (err: any) { setError(err.message); } }}>
          <Field label="Team name"><input className={inputCls} required minLength={2} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Discipline"><select className={inputCls} value={form.discipline} onChange={(e) => setForm({ ...form, discipline: e.target.value })}>{DISCIPLINES.map((d) => <option key={d}>{d}</option>)}</select></Field>
          <Field label="Description"><input className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          <div><Button type="submit">Create team</Button></div>
        </form>
      </Card>
      {teams.map((t) => (
        <Card key={t.id} title={t.name} actions={<span className="text-xs text-muted">{t.discipline}</span>}>
          {t.description && <p className="mb-2 text-sm text-muted">{t.description}</p>}
          <ul className="mb-3 text-sm">{t.members.map((m: any) => <li key={m.user_id}>{m.display_name}</li>)}</ul>
          <form className="flex gap-2" onSubmit={async (e) => { e.preventDefault(); setError(null); try { await post(`/teams/${t.id}/members`, { email: emails[t.id] }); load(); } catch (err: any) { setError(err.message); } }}>
            <input className={inputCls} type="email" placeholder="colleague@institution.edu" required value={emails[t.id] || ""} onChange={(e) => setEmails({ ...emails, [t.id]: e.target.value })} />
            <Button type="submit" variant="secondary">Add</Button>
          </form>
        </Card>
      ))}
    </div>
  );
}

export default function Page() {
  return <Shell><Teams /></Shell>;
}
