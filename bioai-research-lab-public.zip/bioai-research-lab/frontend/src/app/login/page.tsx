"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button, ErrorBox, Field, inputCls } from "@/components/ui";
import { post, tokens } from "@/lib/api";
import DemoButton from "@/components/DemoButton";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const t = await post("/auth/login", { email, password });
      tokens.set(t.access_token, t.refresh_token);
      router.push("/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto max-w-sm px-6 py-20">
      <h1 className="text-2xl font-semibold">Sign in</h1>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <Field label="Email"><input className={inputCls} type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" /></Field>
        <Field label="Password"><input className={inputCls} type="password" required value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></Field>
        <ErrorBox error={error} />
        <Button type="submit" disabled={busy} className="w-full">{busy ? "Signing in…" : "Sign in"}</Button>
      </form>
      <div className="mt-6 rounded-md border border-line bg-white p-4 text-sm">
        <p className="mb-2 text-muted">No account yet? Look around with synthetic demonstration data.</p>
        <DemoButton className="w-full rounded-md border border-omics px-4 py-2 font-medium text-omics" label="Open the demo account" />
      </div>
      <p className="mt-4 text-sm"><Link className="underline" href="/register">Create an account</Link> · <Link className="underline" href="/forgot-password">Forgot password</Link></p>
    </main>
  );
}
