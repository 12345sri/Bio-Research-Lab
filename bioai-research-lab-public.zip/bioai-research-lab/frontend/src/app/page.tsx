import Link from "next/link";
import DemoButton from "@/components/DemoButton";

const AREAS = ["Biomedical signal processing", "Physiological AI", "Bioinformatics", "Computational biology",
  "Cancer research", "Explainable AI", "Biomarker discovery", "Network biology"];

export default function Landing() {
  return (
    <main className="mx-auto max-w-5xl px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-widest text-omics">BioAI Research Lab</p>
      <h1 className="mt-3 text-4xl font-semibold leading-tight md:text-5xl">Explainable AI for Biomedical Research</h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">
        Transform complex physiological and molecular data into reproducible, interpretable research insights.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <DemoButton className="rounded-md bg-omics px-5 py-2.5 font-medium text-white hover:bg-omics/90" />
        <Link href="/register" className="rounded-md bg-ink px-5 py-2.5 font-medium text-white">Start a research project</Link>
        <Link href="/login" className="rounded-md border border-line bg-white px-5 py-2.5 font-medium">Sign in</Link>
      </div>
      <p className="mt-3 text-sm text-muted">The demo opens a project with synthetic data already analysed: HRV comparison, models,
        explanations, gene network, pathways, external validation and reports. Demonstration data only, not research findings.</p>

      <div className="mt-14 grid gap-6 md:grid-cols-2">
        <section className="rounded-lg border border-line bg-white p-6">
          <h2 className="text-xl font-semibold">BioSignal AI</h2>
          <p className="mt-2 text-sm text-muted">ECG and RR-interval research: quality control that accounts for every beat,
            HRV with frequency analysis only when the recording supports it, paired condition comparisons and
            participant-safe machine learning.</p>
        </section>
        <section className="rounded-lg border border-line bg-white p-6">
          <h2 className="text-xl font-semibold">BioOmics AI</h2>
          <p className="mt-2 text-sm text-muted">Gene expression and multi-omics research: preprocessing with full exclusion
            logs, differential expression with FDR control, leakage-safe models, explanations, gene networks, pathway
            enrichment and external validation.</p>
        </section>
      </div>

      <h2 className="mt-14 text-xl font-semibold">Research areas</h2>
      <ul className="mt-3 flex flex-wrap gap-2">
        {AREAS.map((a) => <li key={a} className="rounded-full border border-line bg-white px-3 py-1 text-sm">{a}</li>)}
      </ul>

      <h2 className="mt-14 text-xl font-semibold">Leadership</h2>
      <div className="mt-3 grid gap-4 sm:grid-cols-2">
        <div className="border-t-2 border-ink pt-3"><p className="font-semibold">Tanjidul Huda</p><p className="text-sm text-muted">Founder / Research Lead</p></div>
        <div className="border-t-2 border-ink pt-3"><p className="font-semibold">Sriporna Biswas Srima</p><p className="text-sm text-muted">Co-Founder / Research &amp; Development</p></div>
      </div>

      <p className="mt-16 text-xs text-muted">Research infrastructure only. Not a medical device, not a diagnostic service and not a
        treatment recommendation system. Correlation and model importance do not establish causation.</p>
    </main>
  );
}
