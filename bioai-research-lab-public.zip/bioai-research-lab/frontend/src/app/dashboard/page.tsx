"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import Shell, { useMe } from "@/components/Shell";
import { Card, ErrorBox, StatusPill } from "@/components/ui";
import { api } from "@/lib/api";

function Dashboard() {
  const me = useMe();
  const [projects, setProjects] = useState<any[] | null>(null);
  const [experiments, setExperiments] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<any[]>("/projects").then(async (ps) => {
      setProjects(ps);
      const lists = await Promise.all(ps.filter((p) => p.my_role).map((p) =>
        api<any[]>(`/projects/${p.id}/experiments`).then((es) => es.map((e) => ({ ...e, project: p.name }))).catch(() => [])));
      setExperiments(lists.flat().sort((a, b) => (b.created_at > a.created_at ? 1 : -1)));
    }).catch((e) => setError(e.message));
  }, []);

  const counts = [
    ["Projects", projects?.length ?? "…"],
    ["Experiments", experiments.length],
    ["Succeeded", experiments.filter((e) => e.status === "SUCCEEDED").length],
    ["Running or queued", experiments.filter((e) => ["RUNNING", "QUEUED"].includes(e.status)).length],
  ];
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Welcome{me?.display_name ? `, ${me.display_name}` : ""}</h1>
      <ErrorBox error={error} />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
        {counts.map(([k, v]) => (
          <div key={k as string} className="rounded-lg border border-line bg-white p-4">
            <p className="text-sm text-muted">{k}</p><p className="text-3xl font-semibold">{v}</p>
          </div>
        ))}
      </div>
      <Card title="Recent experiments" actions={<Link className="text-sm underline" href="/projects">All projects</Link>}>
        {experiments.length === 0 ? <p className="text-sm text-muted">No experiments yet. Create a project, upload a dataset and configure an experiment.</p> : (
          <ul className="divide-y divide-line">
            {experiments.slice(0, 10).map((e) => (
              <li key={e.id} className="flex flex-wrap items-center justify-between gap-2 py-3 text-sm">
                <div className="min-w-0">
                  <Link className="font-medium underline" href={`/projects/${e.project_id}/experiments/${e.id}`}>{e.name}</Link>
                  <p className="text-xs text-muted">{e.project}</p>
                </div>
                <StatusPill status={e.status} />
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

export default function Page() {
  return <Shell><Dashboard /></Shell>;
}
