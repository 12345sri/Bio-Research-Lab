import "./globals.css";
import type { ReactNode } from "react";

export const metadata = {
  title: "BioAI Research Lab",
  description: "Explainable and reproducible AI infrastructure for biomedical research.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-paper text-ink antialiased">{children}</body>
    </html>
  );
}
