"use client";
import Link from "next/link";
import { useState } from "react";
import { Button, ErrorBox, Field, inputCls } from "@/components/ui";
import { post } from "@/lib/api";

export default function Forgot() {
  const [email, setEmail] = useState("");
  const [res, setRes] = useState<{ message: string; reset_token?: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  return (
    <main className="mx-auto max-w-sm px-6 py-20">
      <h1 className="text-2xl font-semibold">Reset your password</h1>
      {res ? (
        <div className="mt-4 text-sm">
          <p>{res.message}</p>
          {res.reset_token && <p className="mt-3 rounded-md bg-amber-50 p-3">Reset link: <Link className="underline" href={`/reset-password?token=${encodeURIComponent(res.reset_token)}`}>set a new password</Link></p>}
        </div>
      ) : (
        <form className="mt-6 space-y-4" onSubmit={async (e) => { e.preventDefault(); try { setRes(await post("/auth/password-reset/request", { email })); } catch (err: any) { setError(err.message); } }}>
          <Field label="Email"><input className={inputCls} type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          <ErrorBox error={error} />
          <Button type="submit" className="w-full">Send reset link</Button>
        </form>
      )}
    </main>
  );
}
