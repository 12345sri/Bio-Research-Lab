"use client";
import Link from "next/link";
import { useState } from "react";
import { Button, ErrorBox, Field, inputCls } from "@/components/ui";
import { post } from "@/lib/api";

export default function Register() {
  const [form, setForm] = useState({ email: "", password: "", display_name: "" });
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ message: string; verification_token?: string } | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      setDone(await post("/auth/register", form));
    } catch (err: any) {
      setError(err.message);
    }
  }

  if (done)
    return (
      <main className="mx-auto max-w-md px-6 py-20">
        <h1 className="text-2xl font-semibold">Check your email</h1>
        <p className="mt-3 text-sm">{done.message}</p>
        {done.verification_token && (
          <p className="mt-4 rounded-md bg-amber-50 p-3 text-sm">
            This server does not send email, so confirm your address here:{" "}
            <Link className="font-medium underline" href={`/verify?token=${encodeURIComponent(done.verification_token)}`}>verify my email</Link>
          </p>
        )}
      </main>
    );

  return (
    <main className="mx-auto max-w-sm px-6 py-20">
      <h1 className="text-2xl font-semibold">Create a researcher account</h1>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <Field label="Name (shown to collaborators)"><input className={inputCls} value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} /></Field>
        <Field label="Email"><input className={inputCls} type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
        <Field label="Password" hint="At least 12 characters, upper- and lower-case letters and a digit.">
          <input className={inputCls} type="password" required minLength={12} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} autoComplete="new-password" />
        </Field>
        <ErrorBox error={error} />
        <Button type="submit" className="w-full">Create account</Button>
      </form>
      <p className="mt-4 text-sm">Already registered? <Link className="underline" href="/login">Sign in</Link></p>
    </main>
  );
}
