"use client";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import Shell from "@/components/Shell";
import { Button, Card, ErrorBox, Field, StatusPill, Table, Tabs, inputCls } from "@/components/ui";
import { api, download, post } from "@/lib/api";

const TABS = ["Overview", "Datasets", "Experiments", "New experiment", "Members", "Tasks & comments", "Audit history"];
const ALGOS = ["LOGISTIC_REGRESSION", "SVM", "RANDOM_FOREST", "XGBOOST"];
const CONTRIB = ["CONCEPTUALIZATION", "DATA_COLLECTION", "DATA_CURATION", "SOFTWARE", "METHODOLOGY", "ANALYSIS", "VISUALIZATION", "SUPERVISION", "WRITING"];

function Datasets({ pid, datasets, reload }: { pid: string; datasets: any[]; reload: () => void }) {
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState<any>(null);

  async function upload(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setError(null); setBusy(true);
    const form = e.currentTarget;  // React clears currentTarget once the handler yields
    try { await post(`/projects/${pid}/datasets`, new FormData(form)); form.reset(); reload(); }
    catch (err: any) { setError(err.message); } finally { setBusy(false); }
  }
  async function newVersion(e: React.FormEvent<HTMLFormElement>, did: string) {
    e.preventDefault(); setError(null);
    const form = e.currentTarget;
    try { await post(`/projects/${pid}/datasets/${did}/versions`, new FormData(form)); form.reset(); reload(); }
    catch (err: any) { setError(err.message); }
  }
  return (
    <div className="space-y-6">
      <Card title="Upload a dataset">
        <form onSubmit={upload} className="grid gap-4 md:grid-cols-2">
          <Field label="Name"><input name="name" className={inputCls} required minLength={2} /></Field>
          <Field label="Domain"><select name="domain" className={inputCls}><option value="BIOSIGNAL">BioSignal</option><option value="BIOOMICS">BioOmics</option><option value="GENERAL">General</option></select></Field>
          <Field label="Privacy"><select name="privacy" className={inputCls}><option value="INTERNAL">Internal</option><option value="CONFIDENTIAL">Confidential</option><option value="RESTRICTED_HUMAN_DATA">Restricted human data</option></select></Field>
          <Field label="File" hint="CSV, TSV, TXT or GMT gene sets. RR tables need participant_id, session_id, condition, rr_ms columns.">
            <input name="file" type="file" accept=".csv,.tsv,.txt,.gmt" required className="text-sm" /></Field>
          <div className="md:col-span-2"><Field label="Description"><input name="description" className={inputCls} /></Field></div>
          <label className="text-sm"><input type="checkbox" name="is_synthetic" value="true" className="mr-2" />Synthetic / demonstration data</label>
          <div className="md:col-span-2"><ErrorBox error={error} /><Button type="submit" disabled={busy}>{busy ? "Validating and uploading…" : "Upload"}</Button></div>
        </form>
      </Card>
      {datasets.map((d) => (
        <Card key={d.id} title={d.name} actions={<span className="text-xs text-muted">{d.domain} · {d.privacy}{d.is_synthetic ? " · SYNTHETIC" : ""}</span>}>
          <Table rows={d.versions.map((v: any) => ({ version: v.version, file: v.original_filename, rows: v.n_rows, columns: v.n_columns, validation: v.validation_status, sha256: v.sha256.slice(0, 12), note: v.change_note }))} />
          <div className="mt-3 flex flex-wrap gap-2">
            {d.versions.map((v: any) => (
              <span key={v.id} className="flex gap-2">
                <Button variant="secondary" onClick={() => api(`/projects/${pid}/dataset-versions/${v.id}/preview`).then((p) => setPreview({ ...p, title: `${d.name} v${v.version}` })).catch((e) => setError(e.message))}>Preview v{v.version}</Button>
                <Button variant="secondary" onClick={() => download(`/projects/${pid}/dataset-versions/${v.id}/download`, v.original_filename)}>Download v{v.version}</Button>
              </span>
            ))}
          </div>
          <form onSubmit={(e) => newVersion(e, d.id)} className="mt-4 flex flex-wrap items-end gap-2">
            <Field label="New version"><input name="file" type="file" required className="text-sm" /></Field>
            <input name="change_note" required minLength={3} placeholder="What changed?" className={`${inputCls} max-w-xs`} />
            <Button type="submit" variant="secondary">Upload version</Button>
          </form>
        </Card>
      ))}
      {preview && <Card title={`Preview: ${preview.title}`} actions={<Button variant="secondary" onClick={() => setPreview(null)}>Close</Button>}>
        <Table rows={preview.rows.map((r: any[]) => Object.fromEntries(preview.columns.map((c: string, i: number) => [c, r[i]])))} />
      </Card>}
    </div>
  );
}

function versionOptions(datasets: any[]) {
  return datasets.flatMap((d) => d.versions.map((v: any) => ({ id: v.id, label: `${d.name} · v${v.version} (${v.original_filename})`, dataset: d.id })));
}

function Builder({ pid, datasets }: { pid: string; datasets: any[] }) {
  const router = useRouter();
  const opts = versionOptions(datasets);
  const [platform, setPlatform] = useState("BIOSIGNAL");
  const [f, setF] = useState<any>({ name: "", dataset_version_id: "", random_seed: 42, compare_a: "NORMAL_DAY", compare_b: "EXAM_DAY", window_s: 60,
    metadata_version_id: "", sample_column: "sample_id", group_column: "stage", negative_class: "EARLY", positive_class: "LATE", orientation: "",
    gene_sets_version_id: "", external_expression_version_id: "", external_metadata_version_id: "", threshold: 0.5, log2_transform: false, max_missing: 0.2,
    algorithms: ["LOGISTIC_REGRESSION", "RANDOM_FOREST"], resampling: "NONE", cv_folds: 5, test_size: 0.2, select_k_best: "", ml_positive: "EXAM_DAY", use_ml: true });
  const [error, setError] = useState<string | null>(null);
  const set = (k: string, v: any) => setF({ ...f, [k]: v });
  const Sel = ({ k, optional }: { k: string; optional?: boolean }) => (
    <select className={inputCls} value={f[k]} onChange={(e) => set(k, e.target.value)} required={!optional}>
      <option value="">{optional ? "None" : "Choose a dataset version"}</option>
      {opts.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
    </select>
  );

  async function submit(e: React.FormEvent, runNow: boolean) {
    e.preventDefault(); setError(null);
    const ml = { algorithms: f.algorithms, resampling: f.resampling, cv_folds: Number(f.cv_folds), test_size: Number(f.test_size),
      select_k_best: f.select_k_best ? Number(f.select_k_best) : null, positive_class: platform === "BIOSIGNAL" ? f.ml_positive : f.positive_class };
    const body: any = { name: f.name, platform, dataset_version_id: f.dataset_version_id, random_seed: Number(f.random_seed) };
    if (platform === "BIOSIGNAL") {
      Object.assign(body, { compare: [f.compare_a, f.compare_b], window_s: f.use_ml ? Number(f.window_s) : null, ml: f.use_ml ? ml : null });
    } else {
      Object.assign(body, { metadata_version_id: f.metadata_version_id, sample_column: f.sample_column, group_column: f.group_column,
        positive_class: f.positive_class, negative_class: f.negative_class, orientation: f.orientation || null,
        preprocess: { max_missing: Number(f.max_missing), log2_transform: f.log2_transform }, network: { threshold: Number(f.threshold) },
        gene_sets_version_id: f.gene_sets_version_id || null, external_expression_version_id: f.external_expression_version_id || null,
        external_metadata_version_id: f.external_metadata_version_id || null, ml });
    }
    try {
      const exp = await post(`/projects/${pid}/experiments`, body);
      if (runNow) await post(`/projects/${pid}/experiments/${exp.id}/run`);
      router.push(`/projects/${pid}/experiments/${exp.id}`);
    } catch (err: any) { setError(err.message); }
  }

  if (!opts.length) return <Card><p className="text-sm">Upload a dataset first.</p></Card>;
  return (
    <Card title="Experiment builder">
      <form onSubmit={(e) => submit(e, true)} className="space-y-6">
        <div className="grid gap-4 md:grid-cols-3">
          <Field label="Experiment name"><input className={inputCls} required minLength={3} value={f.name} onChange={(e) => set("name", e.target.value)} /></Field>
          <Field label="Analysis">
            <select className={inputCls} value={platform} onChange={(e) => setPlatform(e.target.value)}>
              <option value="BIOSIGNAL">Biosignal: QC, HRV, condition comparison</option><option value="BIOOMICS">Omics: DE, ML, SHAP, network, pathways</option>
            </select>
          </Field>
          <Field label="Random seed" hint="Recorded for exact reproduction."><input className={inputCls} type="number" min={0} value={f.random_seed} onChange={(e) => set("random_seed", e.target.value)} /></Field>
        </div>

        {platform === "BIOSIGNAL" ? (
          <div className="grid gap-4 md:grid-cols-3">
            <div className="md:col-span-3"><Field label="RR interval dataset (participant_id, session_id, condition, rr_ms)"><Sel k="dataset_version_id" /></Field></div>
            <Field label="Condition A (reference)"><input className={inputCls} value={f.compare_a} onChange={(e) => set("compare_a", e.target.value)} /></Field>
            <Field label="Condition B (comparison)"><input className={inputCls} value={f.compare_b} onChange={(e) => set("compare_b", e.target.value)} /></Field>
            <label className="self-end text-sm"><input type="checkbox" checked={f.use_ml} onChange={(e) => set("use_ml", e.target.checked)} className="mr-2" />Train models on HRV windows (participant-grouped split)</label>
            {f.use_ml && <>
              <Field label="Window length (s)"><input className={inputCls} type="number" min={30} value={f.window_s} onChange={(e) => set("window_s", e.target.value)} /></Field>
              <Field label="Condition to predict"><input className={inputCls} value={f.ml_positive} onChange={(e) => set("ml_positive", e.target.value)} /></Field>
            </>}
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-3">
            <div className="md:col-span-3"><Field label="Expression matrix (first column = gene or sample ID)"><Sel k="dataset_version_id" /></Field></div>
            <div className="md:col-span-3"><Field label="Sample metadata"><Sel k="metadata_version_id" /></Field></div>
            <Field label="Sample ID column"><input className={inputCls} value={f.sample_column} onChange={(e) => set("sample_column", e.target.value)} /></Field>
            <Field label="Group column"><input className={inputCls} value={f.group_column} onChange={(e) => set("group_column", e.target.value)} /></Field>
            <Field label="Orientation" hint="Leave on auto unless inference fails.">
              <select className={inputCls} value={f.orientation} onChange={(e) => set("orientation", e.target.value)}><option value="">Infer from sample IDs</option><option value="GENES_AS_ROWS">Genes as rows</option><option value="SAMPLES_AS_ROWS">Samples as rows</option></select></Field>
            <Field label="Reference group"><input className={inputCls} value={f.negative_class} onChange={(e) => set("negative_class", e.target.value)} /></Field>
            <Field label="Comparison / positive group"><input className={inputCls} value={f.positive_class} onChange={(e) => set("positive_class", e.target.value)} /></Field>
            <Field label="Max missing fraction per gene"><input className={inputCls} type="number" step="0.05" min={0} max={1} value={f.max_missing} onChange={(e) => set("max_missing", e.target.value)} /></Field>
            <label className="self-end text-sm"><input type="checkbox" checked={f.log2_transform} onChange={(e) => set("log2_transform", e.target.checked)} className="mr-2" />Apply log2(x+1)</label>
            <Field label="Network correlation threshold"><input className={inputCls} type="number" step="0.05" min={0} max={1} value={f.threshold} onChange={(e) => set("threshold", e.target.value)} /></Field>
            <Field label="Gene sets (GMT) for pathway enrichment"><Sel k="gene_sets_version_id" optional /></Field>
            <div className="rounded-md border border-amber-300 bg-amber-50 p-3 text-sm md:col-span-3">
              <p className="font-medium">External validation (independent dataset)</p>
              <p className="mb-2 text-muted">Must come from datasets never used for training. The platform rejects a version of a training dataset.</p>
              <div className="grid gap-3 md:grid-cols-2"><Field label="External expression"><Sel k="external_expression_version_id" optional /></Field><Field label="External metadata"><Sel k="external_metadata_version_id" optional /></Field></div>
            </div>
          </div>
        )}

        {(platform === "BIOOMICS" || f.use_ml) && (
          <div className="grid gap-4 md:grid-cols-4">
            <div className="md:col-span-4 text-sm font-medium">Models (compared on the same leak-free split; no model is declared a biological winner)</div>
            {ALGOS.map((a) => (
              <label key={a} className="text-sm"><input type="checkbox" className="mr-2" checked={f.algorithms.includes(a)}
                onChange={(e) => set("algorithms", e.target.checked ? [...f.algorithms, a] : f.algorithms.filter((x: string) => x !== a))} />{a}</label>
            ))}
            <Field label="Class imbalance" hint="SMOTE is applied inside training folds only.">
              <select className={inputCls} value={f.resampling} onChange={(e) => set("resampling", e.target.value)}><option value="NONE">None</option><option value="CLASS_WEIGHT">Class weighting</option><option value="SMOTE">SMOTE</option></select></Field>
            <Field label="CV folds"><input className={inputCls} type="number" min={2} max={20} value={f.cv_folds} onChange={(e) => set("cv_folds", e.target.value)} /></Field>
            <Field label="Test fraction"><input className={inputCls} type="number" step="0.05" min={0.1} max={0.45} value={f.test_size} onChange={(e) => set("test_size", e.target.value)} /></Field>
            {platform === "BIOOMICS" && <Field label="Select k best genes (in folds)"><input className={inputCls} type="number" min={1} value={f.select_k_best} onChange={(e) => set("select_k_best", e.target.value)} placeholder="all" /></Field>}
          </div>
        )}
        <ErrorBox error={error} />
        <div className="flex gap-3"><Button type="submit">Create and run</Button><Button type="button" variant="secondary" onClick={(e: any) => submit(e, false)}>Save as draft</Button></div>
      </form>
    </Card>
  );
}

function Members({ pid }: { pid: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [f, setF] = useState<any>({ email: "", project_role: "CONTRIBUTOR", contributions: [] });
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(() => api(`/projects/${pid}/members`).then(setRows).catch((e) => setError(e.message)), [pid]);
  useEffect(() => { load(); }, [load]);
  return (
    <Card title="Members and contributions" actions={<span className="text-xs text-muted">Contributions are recorded; authorship is never assigned automatically.</span>}>
      <Table rows={rows.map((r) => ({ name: r.display_name, role: r.project_role, contributions: r.contributions.join(", ") }))} />
      <form className="mt-4 grid gap-3 md:grid-cols-3" onSubmit={async (e) => { e.preventDefault(); setError(null); try { await post(`/projects/${pid}/members`, f); load(); } catch (err: any) { setError(err.message); } }}>
        <Field label="Researcher email"><input className={inputCls} type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
        <Field label="Project role"><select className={inputCls} value={f.project_role} onChange={(e) => setF({ ...f, project_role: e.target.value })}>{["VIEWER", "REVIEWER", "CONTRIBUTOR", "LEAD", "OWNER"].map((r) => <option key={r}>{r}</option>)}</select></Field>
        <Field label="Contributions"><select multiple className={inputCls} value={f.contributions} onChange={(e) => setF({ ...f, contributions: Array.from(e.target.selectedOptions).map((o) => o.value) })}>{CONTRIB.map((c) => <option key={c}>{c}</option>)}</select></Field>
        <div className="md:col-span-3"><ErrorBox error={error} /><Button type="submit">Add or update member</Button></div>
      </form>
    </Card>
  );
}

function Collaboration({ pid }: { pid: string }) {
  const [tasks, setTasks] = useState<any[]>([]);
  const [comments, setComments] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(() => {
    api(`/projects/${pid}/tasks`).then(setTasks).catch((e) => setError(e.message));
    api(`/projects/${pid}/comments?target_type=PROJECT`).then(setComments).catch(() => {});
  }, [pid]);
  useEffect(() => { load(); }, [load]);
  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card title="Tasks">
        <ul className="mb-3 space-y-2 text-sm">
          {tasks.map((t) => (
            <li key={t.id} className="flex items-center justify-between gap-2">
              <span>{t.title}</span>
              <select className="rounded border border-line text-xs" value={t.status} onChange={async (e) => { try { await api(`/projects/${pid}/tasks/${t.id}`, { method: "PATCH", body: JSON.stringify({ status: e.target.value }) }); } catch (err: any) { setError(err.message); } load(); }}>
                {["TODO", "IN_PROGRESS", "IN_REVIEW", "DONE"].map((s) => <option key={s}>{s}</option>)}
              </select>
            </li>
          ))}
        </ul>
        <form className="flex gap-2" onSubmit={async (e) => { e.preventDefault(); try { await post(`/projects/${pid}/tasks`, { title }); setTitle(""); load(); } catch (err: any) { setError(err.message); } }}>
          <input className={inputCls} required minLength={2} placeholder="New task" value={title} onChange={(e) => setTitle(e.target.value)} /><Button type="submit">Add</Button>
        </form>
      </Card>
      <Card title="Discussion">
        <ul className="mb-3 space-y-3 text-sm">{comments.map((c) => <li key={c.id}><span className="font-medium">{c.author}</span> <span className="text-xs text-muted">{new Date(c.created_at).toLocaleString()}</span><p>{c.body}</p></li>)}</ul>
        <form className="space-y-2" onSubmit={async (e) => { e.preventDefault(); try { await post(`/projects/${pid}/comments`, { target_type: "PROJECT", target_id: pid, body }); setBody(""); load(); } catch (err: any) { setError(err.message); } }}>
          <textarea className={inputCls} rows={3} required value={body} onChange={(e) => setBody(e.target.value)} /><Button type="submit">Comment</Button>
        </form>
      </Card>
      <div className="md:col-span-2"><ErrorBox error={error} /></div>
    </div>
  );
}

function Audit({ pid }: { pid: string }) {
  const [rows, setRows] = useState<any[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { api(`/projects/${pid}/audit`).then(setRows).catch((e) => setError(e.message)); }, [pid]);
  return (
    <Card title="Audit history" actions={<span className="text-xs text-muted">Append-only. Participant identifiers are never recorded.</span>}>
      <ErrorBox error={error} />
      {rows && <Table max={200} rows={rows.map((r) => ({ when: new Date(r.when).toLocaleString(), who: r.who, action: r.action, resource: `${r.resource_type} ${r.resource_id || ""}`, details: r.details }))} />}
    </Card>
  );
}

function Workspace() {
  const { id } = useParams<{ id: string }>();
  const [project, setProject] = useState<any>(null);
  const [datasets, setDatasets] = useState<any[]>([]);
  const [experiments, setExperiments] = useState<any[]>([]);
  const [tab, setTab] = useState("Overview");
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(() => {
    api(`/projects/${id}`).then(setProject).catch((e) => setError(e.message));
    api(`/projects/${id}/datasets`).then(setDatasets).catch(() => {});
    api(`/projects/${id}/experiments`).then(setExperiments).catch(() => {});
  }, [id]);
  useEffect(() => { load(); }, [load]);
  if (error) return <ErrorBox error={error} />;
  if (!project) return <p className="text-sm text-muted">Loading…</p>;
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-muted">{project.platform} · {project.status} · {project.privacy} · your role {project.my_role || "viewer"}</p>
      <h1 className="mb-4 mt-1 text-2xl font-semibold">{project.name}</h1>
      <Tabs tabs={TABS} active={tab} onChange={setTab} />
      {tab === "Overview" && (
        <div className="grid gap-6 md:grid-cols-2">
          <Card title="Research question"><p className="text-sm">{project.research_question}</p>{project.hypothesis && <><h3 className="mt-4 text-sm font-semibold">Hypothesis</h3><p className="text-sm">{project.hypothesis}</p></>}</Card>
          <Card title="Summary"><ul className="text-sm"><li>{datasets.length} datasets, {datasets.reduce((n, d) => n + d.versions.length, 0)} versions</li><li>{experiments.length} experiments ({experiments.filter((e) => e.status === "SUCCEEDED").length} succeeded)</li></ul></Card>
        </div>
      )}
      {tab === "Datasets" && <Datasets pid={id} datasets={datasets} reload={load} />}
      {tab === "Experiments" && (
        <Card title="Experiment history">
          {experiments.length === 0 ? <p className="text-sm text-muted">No experiments yet.</p> : (
            <ul className="divide-y divide-line">{experiments.map((e) => (
              <li key={e.id} className="flex items-center justify-between py-2 text-sm">
                <Link className="underline" href={`/projects/${id}/experiments/${e.id}`}>{e.name}</Link>
                <span className="flex items-center gap-3 text-muted">{e.platform} · seed {e.random_seed}{e.parent_experiment_id ? " · re-run" : ""}<StatusPill status={e.status} /></span>
              </li>))}
            </ul>)}
        </Card>
      )}
      {tab === "New experiment" && <Builder pid={id} datasets={datasets} />}
      {tab === "Members" && <Members pid={id} />}
      {tab === "Tasks & comments" && <Collaboration pid={id} />}
      {tab === "Audit history" && <Audit pid={id} />}
    </div>
  );
}

export default function Page() {
  return <Shell><Workspace /></Shell>;
}
