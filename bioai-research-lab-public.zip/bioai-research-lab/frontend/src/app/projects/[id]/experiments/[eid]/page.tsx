"use client";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import Shell from "@/components/Shell";
import { Button, Card, ErrorBox, EvidenceBadge, Field, Findings, ProtectedImage, StatusPill, Table, Tabs, inputCls } from "@/components/ui";
import { api, blobUrl, download, post } from "@/lib/api";

const byLabel = (findings: any[], ...labels: string[]) => (findings || []).filter((f) => labels.includes(f.evidence_label));

function Figures({ base, names }: { base: string; names: string[] }) {
  if (!names.length) return null;
  return <div className="mt-4 grid gap-4 md:grid-cols-2">{names.map((n) => <ProtectedImage key={n} path={`${base}/figures/${n}`} alt={n} />)}</div>;
}

function ConfusionMatrix({ cm, positive }: { cm: any; positive?: string }) {
  if (!cm) return <p className="text-xs text-muted">Not available.</p>;
  const cell = (v: number, good: boolean) => <td className={`border border-line px-3 py-2 text-center font-mono ${good ? "bg-green-100" : "bg-red-50"}`}>{v}</td>;
  return (
    <table className="text-xs">
      <thead><tr><th></th><th className="px-2 text-muted">predicted −</th><th className="px-2 text-muted">predicted +</th></tr></thead>
      <tbody>
        <tr><th className="pr-2 text-left text-muted">actual −</th>{cell(cm.tn, true)}{cell(cm.fp, false)}</tr>
        <tr><th className="pr-2 text-left text-muted">actual +</th>{cell(cm.fn, false)}{cell(cm.tp, true)}</tr>
      </tbody>
      {positive && <caption className="mt-1 text-left text-muted" style={{ captionSide: "bottom" }}>positive class: {positive}</caption>}
    </table>
  );
}

function MLView({ ml }: { ml: any }) {
  if (!ml) return <p className="text-sm text-muted">No machine-learning step in this experiment.</p>;
  const rows = Object.entries(ml.models).map(([algo, r]: any) => ({
    model: algo, cv_roc_auc: r.cv?.roc_auc?.mean, cv_roc_auc_sd: r.cv?.roc_auc?.sd, test_roc_auc: r.test.roc_auc, test_pr_auc: r.test.pr_auc,
    balanced_accuracy: r.test.balanced_accuracy, accuracy: r.test.accuracy, majority_baseline: r.test.majority_class_baseline_accuracy,
    precision: r.test.precision, recall: r.test.recall, f1: r.test.f1, brier: r.test.brier, resampling_scope: r.resampling?.final?.scope,
  }));
  return (
    <div className="space-y-4">
      <p className="text-sm"><EvidenceBadge label="MODEL" />Split: {ml.split.strategy}. Models are compared on predictive performance on this dataset only, not biological relevance.</p>
      <Table rows={rows} />
      {ml.comparison?.notes?.map((n: string) => <p key={n} className="text-sm text-muted">{n}</p>)}
      <h3 className="font-semibold">Data roles</h3>
      <Table rows={Object.entries(ml.split.distribution).map(([role, d]: any) => ({ role: role.toUpperCase(), ...d }))} />
      <h3 className="font-semibold">Confusion matrices (test set)</h3>
      <div className="grid gap-4 md:grid-cols-3">
        {Object.entries(ml.models).map(([algo, r]: any) => (
          <div key={algo} className="rounded border border-line p-3 text-sm"><p className="mb-2 font-medium">{algo}</p><ConfusionMatrix cm={r.test.confusion_matrix} positive={ml.positive_class} />
            {r.test.warnings?.map((w: string) => <p key={w} className="mt-1 text-xs text-signal">{w}</p>)}</div>
        ))}
      </div>
      {Object.keys(ml.unavailable_models || {}).map((m) => <p key={m} className="rounded bg-amber-50 px-3 py-2 text-sm"><b>{m}</b> is an optional model that is not enabled on this server, so it was not included in this comparison.</p>)}
    </div>
  );
}

function Explain({ ex }: { ex: any }) {
  if (!ex || !Object.keys(ex).length) return <p className="text-sm text-muted">No model explanations.</p>;
  return (
    <div className="space-y-6">
      {Object.entries(ex).map(([algo, e]: any) => (
        <div key={algo}>
          <h3 className="font-semibold">{algo}</h3>
          {e.shap_available ? (<>
            <p className="my-2 text-sm"><EvidenceBadge label="EXPLANATION" />{e.global.caveat}</p>
            <Table rows={e.global.ranking} max={20} />
            {e.local_examples?.length > 0 && <><h4 className="mt-3 text-sm font-semibold">Local explanations (individual test samples)</h4><Table rows={e.local_examples.map((l: any) => ({ sample: l.sample_id, model_output: l.output, units: l.units, base_value: l.base_value, top_contributions: l.contributions?.slice?.(0, 5) }))} /></>}
          </>) : (<>
            <p className="my-2 text-sm"><EvidenceBadge label="EXPLANATION" />SHAP values for this model type use an optional component that is not enabled on this server, so permutation importance is shown instead. {e.permutation?.caveat}</p>
            <Table rows={e.permutation?.ranking || []} max={20} />
          </>)}
        </div>
      ))}
    </div>
  );
}

function Copilot({ base }: { base: string }) {
  const [q, setQ] = useState("What are the main limitations and what should be validated next?");
  const [out, setOut] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <div className="space-y-4">
      <form className="flex gap-2" onSubmit={async (e) => { e.preventDefault(); setBusy(true); setError(null); try { setOut(await post(`${base}/copilot`, { question: q })); } catch (err: any) { setError(err.message); } finally { setBusy(false); } }}>
        <input className={inputCls} value={q} onChange={(e) => setQ(e.target.value)} minLength={3} required /><Button type="submit" disabled={busy}>{busy ? "Thinking…" : "Ask"}</Button>
      </form>
      <ErrorBox error={error} />
      {out && (
        <div className="space-y-4 text-sm">
          {out.note && <p className="rounded bg-amber-50 p-3">{out.note}</p>}
          {out.answer && <Card title="Answer (verified against recorded evidence)"><p className="whitespace-pre-wrap">{out.answer}</p></Card>}
          {out.status === "REJECTED_UNGROUNDED" && <Card title="Answer withheld: not grounded in the recorded evidence">
            <ul className="list-disc pl-5 text-signal">{out.verification.problems.map((p: string, i: number) => <li key={i}>{p}</li>)}</ul>
            <details className="mt-2"><summary className="cursor-pointer text-muted">Show the rejected draft</summary><p className="mt-2 whitespace-pre-wrap text-muted">{out.raw_answer}</p></details></Card>}
          {out.review && <Card title="Automated review"><ul className="space-y-1">{out.review.map((r: any, i: number) => <li key={i}><span className="font-mono text-xs">[{r.severity}]</span> {r.message}</li>)}</ul></Card>}
          {out.evidence && <Card title="Evidence the copilot may use"><Findings items={out.evidence} /></Card>}
        </div>
      )}
    </div>
  );
}

function Results() {
  const { id, eid } = useParams<{ id: string; eid: string }>();
  const router = useRouter();
  const base = `/projects/${id}/experiments/${eid}`;
  const [exp, setExp] = useState<any>(null);
  const [data, setData] = useState<any>(null);
  const [tab, setTab] = useState("Summary");
  const [error, setError] = useState<string | null>(null);        // page could not load
  const [actionError, setActionError] = useState<string | null>(null);  // a button action failed; page stays usable
  const [reportUrl, setReportUrl] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const e = await api(base);
      setExp(e);
      if (e.status === "SUCCEEDED") setData(await api(`${base}/results`));
    } catch (err: any) { setError(err.message); }
  }, [base]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {  // poll while the background worker is processing
    if (!exp || !["QUEUED", "RUNNING"].includes(exp.status)) return;
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [exp, load]);

  if (error) return <ErrorBox error={error} />;
  if (!exp) return <p className="text-sm text-muted">Loading…</p>;
  const r = data?.result;
  const figs: string[] = (data?.report?.formats || []).filter((f: string) => f.startsWith("figure:")).map((f: string) => f.slice(7));
  const isBio = exp.platform === "BIOSIGNAL";
  const tabs = isBio ? ["Summary", "Sessions & QC", "Statistics", "Machine learning", "Explainability", "Report", "Copilot", "Reproducibility"]
    : ["Summary", "Preprocessing", "Differential expression", "Machine learning", "Explainability", "Network", "Pathways", "Validation", "Report", "Copilot", "Reproducibility"];

  return (
    <div>
      <p className="text-sm"><Link className="underline" href={`/projects/${id}`}>← Project</Link></p>
      <div className="mt-2 flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-semibold">{exp.name}</h1><StatusPill status={exp.status} />
        <div className="ml-auto flex gap-2">
          {exp.status === "DRAFT" || exp.status === "FAILED" ? <Button onClick={async () => { setActionError(null); try { await post(`${base}/run`); load(); } catch (e: any) { setActionError(e.message); } }}>Run</Button> : null}
          <Button variant="secondary" onClick={async () => { setActionError(null); try { const c = await post(`${base}/clone`); router.push(`/projects/${id}/experiments/${c.id}`); } catch (e: any) { setActionError(e.message); } }}>Clone for re-run</Button>
        </div>
      </div>
      {actionError && <div className="mt-3"><ErrorBox error={actionError} /></div>}
      {["QUEUED", "RUNNING"].includes(exp.status) && <p className="mt-4 rounded bg-blue-50 p-3 text-sm">The analysis is running on the background worker. This page updates automatically.</p>}
      {exp.status === "FAILED" && <p className="mt-4 rounded bg-red-50 p-3 text-sm">Analysis failed: {exp.error_message}</p>}
      {r && (
        <div className="mt-6">
          {r.provenance?.config?.demo && <p className="mb-4 rounded bg-amber-100 p-3 text-sm font-semibold">DEMONSTRATION DATA: synthetic values, not biomedical evidence.</p>}
          <Tabs tabs={tabs} active={tab} onChange={setTab} />
          {tab === "Summary" && <div className="space-y-6"><Card title="Findings"><Findings items={r.findings} /></Card>
            <Card title="Automated review"><ul className="space-y-1 text-sm">{data.review.map((i: any, k: number) => <li key={k}><span className="font-mono text-xs">[{i.severity}]</span> {i.message}</li>)}</ul></Card>
            <p className="text-xs text-muted">{r.disclaimer}</p></div>}
          {tab === "Sessions & QC" && <Card title="Sessions (pseudonymised participants)"><p className="mb-3 text-sm"><EvidenceBadge label="DATA" />Every RR interval is classified valid or excluded; LF/HF appears only where frequency analysis was valid.</p><Table rows={r.sessions} max={100} /></Card>}
          {tab === "Statistics" && <Card title="Condition comparison"><Findings items={byLabel(r.findings, "STATISTICS")} /><div className="mt-4"><Table rows={r.comparisons} /></div><Figures base={base} names={figs.filter((f) => f.startsWith("paired_"))} /></Card>}
          {tab === "Preprocessing" && <Card title="Orientation, QC and preprocessing"><pre className="overflow-x-auto text-xs">{JSON.stringify({ orientation: r.orientation, qc: r.qc, preprocessing: r.preprocessing, samples_without_metadata: r.samples_without_metadata, integration: r.integration }, null, 2)}</pre></Card>}
          {tab === "Differential expression" && <Card title="Differential expression"><Findings items={byLabel(r.findings, "STATISTICS").slice(0, 1)} /><div className="mt-3"><Table rows={r.differential_expression} max={100} /></div></Card>}
          {tab === "Machine learning" && <Card title="Model evaluation"><MLView ml={r.ml} /><Figures base={base} names={figs.filter((f) => ["roc", "calibration"].includes(f))} /></Card>}
          {tab === "Explainability" && <Card title="Model explanations"><Explain ex={r.explanations || r.ml?.explanations} /><Figures base={base} names={figs.filter((f) => f.startsWith("shap_") || f.startsWith("perm_"))} /></Card>}
          {tab === "Network" && r.network && <Card title="Gene network"><p className="text-sm"><EvidenceBadge label={r.network.statement.evidence_label} />{r.network.statement.statement}</p>
            <p className="mt-2 text-sm">Hub genes: {r.network.hub_genes.join(", ") || "none"}</p><div className="mt-3"><Table rows={r.network.nodes} /></div><h3 className="mt-4 font-semibold">Edges ({r.network.edge_meaning})</h3><Table rows={r.network.edges} /><Figures base={base} names={figs.filter((f) => f === "network")} /></Card>}
          {tab === "Pathways" && <Card title="Pathway enrichment">{r.pathway ? <><p className="text-sm"><EvidenceBadge label={r.pathway.statement.evidence_label} />{r.pathway.statement.statement}</p><div className="mt-3"><Table rows={r.pathway.table} columns={["pathway_id", "name", "gene_count", "set_size", "fold_enrichment", "p_value", "p_adjusted", "genes"].filter((c) => r.pathway.table[0] && c in r.pathway.table[0])} /></div><Figures base={base} names={figs.filter((f) => f === "pathways")} /></> : <p className="text-sm text-muted">No gene-set file was provided, or no genes were significant.</p>}</Card>}
          {tab === "Validation" && <Card title="External validation">{r.external_validation ? <><p className="text-sm"><EvidenceBadge label="MODEL" />{r.external_validation.statement.statement}</p>
            <p className="mt-2 text-sm">Role: <b>{r.external_validation.role}</b> · independence: {JSON.stringify(r.external_validation.independence)}</p>
            <div className="mt-3"><Table rows={Object.entries(r.external_validation.models).map(([m, v]: any) => ({ model: m, ...Object.fromEntries(Object.entries(v).filter(([k]) => !["roc_curve", "pr_curve", "calibration"].includes(k))) }))} /></div></>
            : <p className="text-sm text-muted">No independent dataset was provided. Performance may not generalise beyond this dataset.</p>}</Card>}
          {tab === "Report" && <Card title="Research report" actions={<div className="flex flex-wrap gap-2">
              {["pdf", "html", "json", "csv"].filter((f) => data.report?.formats.includes(f)).map((f) => <Button key={f} variant="secondary" onClick={() => download(`${base}/report.${f}`, `report-${eid}.${f === "csv" ? "zip" : f}`)}>{f.toUpperCase()}</Button>)}
              <Button onClick={async () => setReportUrl(await blobUrl(`${base}/report.html`))}>View</Button></div>}>
            <p className="text-sm text-muted">16 sections, evidence-labelled, with figures, tables and the machine-readable configuration (JSON).</p>
            {reportUrl && <iframe title="report" src={reportUrl} className="mt-4 h-[80vh] w-full rounded border border-line" sandbox="" />}</Card>}
          {tab === "Copilot" && <Card title="Research copilot"><Copilot base={base} /></Card>}
          {tab === "Reproducibility" && <Card title="Reproducibility record"><pre className="overflow-x-auto text-xs">{JSON.stringify({ experiment: { id: exp.id, dataset_version_id: exp.dataset_version_id, random_seed: exp.random_seed, code_version: exp.code_version, parent: exp.parent_experiment_id, started_at: exp.started_at, finished_at: exp.finished_at }, provenance: r.provenance }, null, 2)}</pre></Card>}
        </div>
      )}
    </div>
  );
}

export default function Page() {
  return <Shell><Results /></Shell>;
}
