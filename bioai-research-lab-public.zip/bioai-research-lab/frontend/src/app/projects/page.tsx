"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Shell from "@/components/Shell";
import { Button, Card, ErrorBox, Field, inputCls } from "@/components/ui";
import { api, post } from "@/lib/api";

function Projects() {
  const router = useRouter();
  const [projects, setProjects] = useState<any[]>([]);
  const [teams, setTeams] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ name: "", research_question: "", hypothesis: "", platform: "BIOSIGNAL", privacy: "INTERNAL", team_id: "" });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api("/projects").then(setProjects).catch((e) => setError(e.message));
    api("/teams").then(setTeams).catch(() => {});
  }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault(); setError(null);
    try {
      const body = { ...form, team_id: form.team_id || null, hypothesis: form.hypothesis || null };
      const p = await post("/projects", body);
      router.push(`/projects/${p.id}`);
    } catch (err: any) { setError(err.message); }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Research projects</h1>
        <Button onClick={() => setOpen(!open)}>{open ? "Cancel" : "New project"}</Button>
      </div>
      {open && (
        <Card title="New research project">
          <form onSubmit={create} className="grid gap-4 md:grid-cols-2">
            <Field label="Project name"><input className={inputCls} required minLength={3} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Platform">
              <select className={inputCls} value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value })}>
                <option value="BIOSIGNAL">BioSignal AI (ECG / RR / HRV)</option>
                <option value="BIOOMICS">BioOmics AI (expression / multi-omics)</option>
                <option value="GENERAL">Both / general</option>
              </select>
            </Field>
            <div className="md:col-span-2"><Field label="Research question"><textarea className={inputCls} required minLength={5} rows={2} value={form.research_question} onChange={(e) => setForm({ ...form, research_question: e.target.value })} /></Field></div>
            <div className="md:col-span-2"><Field label="Hypothesis (optional)"><textarea className={inputCls} rows={2} value={form.hypothesis} onChange={(e) => setForm({ ...form, hypothesis: e.target.value })} /></Field></div>
            <Field label="Privacy classification">
              <select className={inputCls} value={form.privacy} onChange={(e) => setForm({ ...form, privacy: e.target.value })}>
                <option value="INTERNAL">Internal</option><option value="CONFIDENTIAL">Confidential</option>
                <option value="RESTRICTED_HUMAN_DATA">Restricted human data</option><option value="PUBLIC">Public (results only)</option>
              </select>
            </Field>
            <Field label="Team (optional)">
              <select className={inputCls} value={form.team_id} onChange={(e) => setForm({ ...form, team_id: e.target.value })}>
                <option value="">No team</option>{teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </Field>
            <div className="md:col-span-2"><ErrorBox error={error} /><Button type="submit" className="mt-2">Create project</Button></div>
          </form>
        </Card>
      )}
      <ErrorBox error={!open ? error : null} />
      <div className="grid gap-4 md:grid-cols-2">
        {projects.map((p) => (
          <Link key={p.id} href={`/projects/${p.id}`} className="rounded-lg border border-line bg-white p-5 hover:border-ink">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted">{p.platform} · {p.status} · {p.privacy}</p>
            <p className="mt-1 font-semibold">{p.name}</p>
            <p className="mt-1 line-clamp-2 text-sm text-muted">{p.research_question}</p>
            <p className="mt-2 text-xs text-muted">Your role: {p.my_role || "public viewer"}</p>
          </Link>
        ))}
        {projects.length === 0 && <p className="text-sm text-muted">No projects yet.</p>}
      </div>
    </div>
  );
}

export default function Page() {
  return <Shell><Projects /></Shell>;
}
