"use client";
import { useState } from "react";
import Shell, { useMe } from "@/components/Shell";
import { Button, Card, ErrorBox, Field, inputCls } from "@/components/ui";
import { patch } from "@/lib/api";

function Settings() {
  const me = useMe();
  const [name, setName] = useState(me?.display_name || "");
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  return (
    <div className="max-w-xl space-y-6">
      <h1 className="text-2xl font-semibold">Settings</h1>
      <Card title="Researcher profile">
        <p className="mb-4 text-sm text-muted">{me?.email} · role {me?.role}</p>
        <form className="space-y-3" onSubmit={async (e) => { e.preventDefault(); setError(null); try { await patch("/auth/me", { display_name: name || null }); setMsg("Saved"); } catch (err: any) { setError(err.message); } }}>
          <Field label="Display name"><input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} /></Field>
          <ErrorBox error={error} />{msg && <p className="text-sm text-green-700">{msg}</p>}
          <Button type="submit">Save</Button>
        </form>
      </Card>
      <Card title="Password"><p className="text-sm">Use <a className="underline" href="/forgot-password">password reset</a> to change your password.</p></Card>
    </div>
  );
}

export default function Page() {
  return <Shell><Settings /></Shell>;
}
