"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { post } from "@/lib/api";

function Verify() {
  const token = useSearchParams().get("token");
  const [state, setState] = useState<"working" | "ok" | string>("working");
  useEffect(() => {
    if (!token) { setState("Missing token"); return; }
    post("/auth/verify-email", { token }).then(() => setState("ok")).catch((e) => setState(e.message));
  }, [token]);
  return (
    <main className="mx-auto max-w-md px-6 py-20">
      <h1 className="text-2xl font-semibold">Email verification</h1>
      <p className="mt-4 text-sm">
        {state === "working" ? "Verifying…" : state === "ok" ? <>Your email is verified. <Link className="underline" href="/login">Sign in</Link></> : state}
      </p>
    </main>
  );
}

export default function Page() {
  return <Suspense><Verify /></Suspense>;
}
