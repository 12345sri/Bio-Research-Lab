"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { Button, ErrorBox, Field, inputCls } from "@/components/ui";
import { post } from "@/lib/api";

function Reset() {
  const token = useSearchParams().get("token") || "";
  const [pw, setPw] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  if (done) return <p className="mt-4 text-sm">Password updated. <Link className="underline" href="/login">Sign in</Link></p>;
  return (
    <form className="mt-6 space-y-4" onSubmit={async (e) => { e.preventDefault(); try { await post("/auth/password-reset/confirm", { token, new_password: pw }); setDone(true); } catch (err: any) { setError(err.message); } }}>
      <Field label="New password" hint="At least 12 characters, mixed case and a digit."><input className={inputCls} type="password" required minLength={12} value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
      <ErrorBox error={error} />
      <Button type="submit" className="w-full">Set password</Button>
    </form>
  );
}

export default function Page() {
  return <main className="mx-auto max-w-sm px-6 py-20"><h1 className="text-2xl font-semibold">Choose a new password</h1><Suspense><Reset /></Suspense></main>;
}
