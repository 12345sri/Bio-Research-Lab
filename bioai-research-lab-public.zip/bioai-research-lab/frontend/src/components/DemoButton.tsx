"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { post, tokens } from "@/lib/api";

// Signs in to the public demonstration account (synthetic data only).
export default function DemoButton({ className = "", label = "Explore the live demo" }: { className?: string; label?: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <span className="inline-block">
      <button type="button" disabled={busy} className={className}
        onClick={async () => {
          setBusy(true); setError(null);
          try {
            const t = await post("/auth/demo-login");
            tokens.set(t.access_token, t.refresh_token);
            router.push("/dashboard");
          } catch (e: any) { setError(e.message); } finally { setBusy(false); }
        }}>
        {busy ? "Opening demo…" : label}
      </button>
      {error && <span role="alert" className="mt-2 block text-sm text-signal">{error}</span>}
    </span>
  );
}
