"use client";
import { ReactNode, useEffect, useState } from "react";
import { blobUrl } from "@/lib/api";

export function Card({ title, children, actions }: { title?: string; children: ReactNode; actions?: ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-white p-5 shadow-sm">
      {(title || actions) && (
        <div className="mb-3 flex items-center justify-between gap-3">
          {title && <h2 className="text-lg font-semibold">{title}</h2>}
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}

export function Button({ children, variant = "primary", ...p }: any) {
  const cls =
    variant === "primary"
      ? "bg-ink text-white hover:bg-ink/90"
      : variant === "danger"
      ? "bg-signal text-white"
      : "border border-line bg-white hover:bg-paper";
  return (
    <button {...p} className={`rounded-md px-4 py-2 text-sm font-medium disabled:opacity-50 ${cls} ${p.className || ""}`}>
      {children}
    </button>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-medium">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}

export const inputCls = "w-full rounded-md border border-line bg-white px-3 py-2 text-sm focus:border-omics focus:outline-none";

export function ErrorBox({ error }: { error?: string | null }) {
  if (!error) return null;
  return <p role="alert" className="rounded-md bg-signal/10 px-3 py-2 text-sm text-signal">{error}</p>;
}

const LABEL_COLORS: Record<string, string> = {
  DATA: "bg-slate-200 text-slate-800",
  STATISTICS: "bg-blue-100 text-blue-800",
  MODEL: "bg-violet-100 text-violet-800",
  EXPLANATION: "bg-teal-100 text-teal-800",
  LITERATURE: "bg-amber-100 text-amber-800",
  INTERPRETATION: "bg-orange-100 text-orange-800",
  HYPOTHESIS: "bg-rose-100 text-rose-800",
};

export function EvidenceBadge({ label }: { label: string }) {
  return (
    <span className={`mr-2 inline-block rounded px-2 py-0.5 text-[11px] font-bold tracking-wide ${LABEL_COLORS[label] || "bg-gray-100"}`}>
      {label}
    </span>
  );
}

export function Findings({ items }: { items: { evidence_label: string; statement: string }[] }) {
  if (!items?.length) return <p className="text-sm text-muted">No findings recorded.</p>;
  return (
    <ul className="space-y-2">
      {items.map((f, i) => (
        <li key={i} className="text-sm leading-relaxed">
          <EvidenceBadge label={f.evidence_label} />
          {f.statement}
        </li>
      ))}
    </ul>
  );
}

function fmt(v: any): string {
  if (v === null || v === undefined) return "—";
  if (typeof v === "number") return Math.abs(v) >= 1000 || v === Math.round(v) ? String(v) : Math.abs(v) < 0.001 ? v.toExponential(2) : v.toFixed(3);
  if (typeof v === "boolean") return v ? "yes" : "no";
  if (Array.isArray(v)) return v.every((x) => typeof x !== "object") ? (v.length ? v.join(", ") : "—") : JSON.stringify(v);
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

export function Table({ rows, columns, max = 50 }: { rows: any[]; columns?: string[]; max?: number }) {
  if (!rows?.length) return <p className="text-sm text-muted">No rows.</p>;
  const cols = columns || Object.keys(rows[0]).filter((c) => !c.startsWith("_"));
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-line text-left text-muted">
            {cols.map((c) => <th key={c} className="px-2 py-2 font-medium">{c}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.slice(0, max).map((r, i) => (
            <tr key={i} className="border-b border-line/60">
              {cols.map((c) => <td key={c} className="px-2 py-1.5 font-mono text-xs">{fmt(r[c])}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length > max && <p className="mt-2 text-xs text-muted">Showing {max} of {rows.length} rows. Full table in the CSV export.</p>}
    </div>
  );
}

export function ProtectedImage({ path, alt }: { path: string; alt: string }) {
  const [src, setSrc] = useState<string | null>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    let url: string | null = null;
    blobUrl(path).then((u) => { url = u; setSrc(u); }).catch(() => setErr(true));
    return () => { if (url) URL.revokeObjectURL(url); };
  }, [path]);
  if (err) return <p className="text-sm text-muted">Figure not available.</p>;
  return src ? <img src={src} alt={alt} className="max-w-full rounded border border-line" /> : <p className="text-sm text-muted">Loading figure…</p>;
}

export function StatusPill({ status }: { status: string }) {
  const c: Record<string, string> = {
    SUCCEEDED: "bg-green-100 text-green-800", FAILED: "bg-red-100 text-red-800", RUNNING: "bg-blue-100 text-blue-800",
    QUEUED: "bg-amber-100 text-amber-800", DRAFT: "bg-gray-100 text-gray-700",
  };
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${c[status] || "bg-gray-100"}`}>{status}</span>;
}

export function Tabs({ tabs, active, onChange }: { tabs: string[]; active: string; onChange: (t: string) => void }) {
  return (
    <div role="tablist" className="mb-5 flex flex-wrap gap-1 border-b border-line">
      {tabs.map((t) => (
        <button key={t} role="tab" aria-selected={t === active} onClick={() => onChange(t)}
          className={`-mb-px border-b-2 px-3 py-2 text-sm ${t === active ? "border-ink font-semibold" : "border-transparent text-muted hover:text-ink"}`}>
          {t}
        </button>
      ))}
    </div>
  );
}
