"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ReactNode, createContext, useContext, useEffect, useState } from "react";
import { api, tokens } from "@/lib/api";

type Me = { id: string; email: string; display_name: string | null; role: string; is_demo?: boolean };
const MeContext = createContext<Me | null>(null);
export const useMe = () => useContext(MeContext);

const NAV = [
  ["Dashboard", "/dashboard"],
  ["Projects", "/projects"],
  ["Teams", "/teams"],
  ["Settings", "/settings"],
];

export default function Shell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const path = usePathname();
  const [me, setMe] = useState<Me | null>(null);

  useEffect(() => {
    if (!tokens.access) {
      router.replace("/login");
      return;
    }
    api<Me>("/auth/me").then(setMe).catch(() => router.replace("/login"));
  }, [router]);

  if (!me) return <div className="p-10 text-sm text-muted">Loading…</div>;
  return (
    <MeContext.Provider value={me}>
      <div className="min-h-screen">
        <header className="border-b border-line bg-white">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3 md:gap-6 md:px-6">
            <Link href="/dashboard" className="font-semibold tracking-tight">BioAI Research Lab</Link>
            <nav className="flex gap-4 text-sm">
              {NAV.map(([label, href]) => (
                <Link key={href} href={href} className={path?.startsWith(href) ? "font-semibold" : "text-muted hover:text-ink"}>{label}</Link>
              ))}
            </nav>
            <div className="ml-auto flex flex-wrap items-center gap-3 text-sm">
              <span className="text-muted">{me.display_name || me.email} · {me.role}</span>
              <button className="underline" onClick={() => { tokens.clear(); router.push("/login"); }}>Sign out</button>
            </div>
          </div>
        </header>
        {me.is_demo && (
          <div className="border-b border-amber-300 bg-amber-50 px-6 py-2 text-center text-sm">
            <b>Read-only demo.</b> All data here is synthetic DEMONSTRATION DATA; results illustrate the workflow and are not research findings.{" "}
            <Link className="underline" href="/register">Create a free account</Link> to upload data and run your own analyses.
          </div>
        )}
        <main className="mx-auto max-w-7xl px-4 py-8 md:px-6">{children}</main>
        <footer className="mx-auto max-w-7xl px-6 pb-8 text-xs text-muted">
          Research software. Not a medical device; results are not diagnoses and associations do not establish causation.
        </footer>
      </div>
    </MeContext.Provider>
  );
}
