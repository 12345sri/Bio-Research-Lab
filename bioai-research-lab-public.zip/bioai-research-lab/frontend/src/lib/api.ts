// Typed client for the BioAI API. Tokens live in sessionStorage (cleared when the tab closes).
export const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

const ACCESS = "bioai.access";
const REFRESH = "bioai.refresh";

export const tokens = {
  get access() {
    return typeof window === "undefined" ? null : sessionStorage.getItem(ACCESS);
  },
  set(access: string, refresh: string) {
    sessionStorage.setItem(ACCESS, access);
    sessionStorage.setItem(REFRESH, refresh);
  },
  clear() {
    sessionStorage.removeItem(ACCESS);
    sessionStorage.removeItem(REFRESH);
  },
  get refresh() {
    return typeof window === "undefined" ? null : sessionStorage.getItem(REFRESH);
  },
};

async function refreshTokens(): Promise<boolean> {
  const rt = tokens.refresh;
  if (!rt) return false;
  const r = await fetch(`${API}/auth/refresh`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: rt }),
  });
  if (!r.ok) return false;
  const t = await r.json();
  tokens.set(t.access_token, t.refresh_token);
  return true;
}

function message(detail: unknown): string {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) return detail.map((d: any) => `${(d.loc || []).slice(1).join(".")}: ${d.msg}`).join("; ");
  return "Request failed";
}

export async function raw(path: string, init: RequestInit = {}, retry = true): Promise<Response> {
  const headers = new Headers(init.headers);
  if (tokens.access) headers.set("Authorization", `Bearer ${tokens.access}`);
  if (init.body && !(init.body instanceof FormData) && !headers.has("Content-Type"))
    headers.set("Content-Type", "application/json");
  const r = await fetch(`${API}${path}`, { ...init, headers });
  if (r.status === 401 && retry && (await refreshTokens())) return raw(path, init, false);
  if (r.status === 401 && typeof window !== "undefined" && !path.startsWith("/auth/")) {
    tokens.clear();
    window.location.href = "/login";
  }
  if (!r.ok) {
    let detail: unknown = r.statusText;
    try {
      detail = (await r.json()).detail;
    } catch {}
    throw new ApiError(r.status, message(detail));
  }
  return r;
}

export async function api<T = any>(path: string, init: RequestInit = {}): Promise<T> {
  const r = await raw(path, init);
  return r.status === 204 ? (undefined as T) : r.json();
}

export const post = <T = any>(path: string, body?: unknown) =>
  api<T>(path, { method: "POST", body: body instanceof FormData ? body : JSON.stringify(body ?? {}) });
export const patch = <T = any>(path: string, body: unknown) =>
  api<T>(path, { method: "PATCH", body: JSON.stringify(body) });

// Fetch a protected file and hand back an object URL (images, HTML report) or trigger a download.
export async function blobUrl(path: string): Promise<string> {
  const r = await raw(path);
  return URL.createObjectURL(await r.blob());
}

export async function download(path: string, filename: string) {
  const url = await blobUrl(path);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
