#!/usr/bin/env python3
"""Generate CSS for the Tailwind utility classes used in the source (local build without the Tailwind compiler).

Scans every string in frontend/src and frontend/local, emits CSS for recognised utilities, and fails if a
class-like token is not recognised, so no class silently goes unstyled.
"""
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
COLORS = {
    "ink": "#1B2140", "signal": "#B4122B", "omics": "#0B7A78", "paper": "#F6F7F9", "line": "#E2E5EA", "muted": "#5B6275",
    "white": "#ffffff", "black": "#000000", "transparent": "transparent",
    "amber-50": "#fffbeb", "amber-100": "#fef3c7", "amber-300": "#fcd34d", "amber-800": "#92400e",
    "blue-50": "#eff6ff", "blue-100": "#dbeafe", "blue-800": "#1e40af", "red-50": "#fef2f2", "red-100": "#fee2e2",
    "red-800": "#991b1b", "green-100": "#dcfce7", "green-700": "#15803d", "green-800": "#166534", "gray-100": "#f3f4f6",
    "gray-700": "#374151", "slate-200": "#e2e8f0", "slate-800": "#1e293b", "violet-100": "#ede9fe", "violet-800": "#5b21b6",
    "teal-100": "#ccfbf1", "teal-800": "#115e59", "orange-100": "#ffedd5", "orange-800": "#9a3412", "rose-100": "#ffe4e6",
    "rose-800": "#9f1239", "emerald-50": "#ecfdf5", "emerald-700": "#047857",
}
TEXT = {"xs": ("0.75rem", "1rem"), "sm": ("0.875rem", "1.25rem"), "base": ("1rem", "1.5rem"), "lg": ("1.125rem", "1.75rem"),
        "xl": ("1.25rem", "1.75rem"), "2xl": ("1.5rem", "2rem"), "3xl": ("1.875rem", "2.25rem"), "4xl": ("2.25rem", "2.5rem"),
        "5xl": ("3rem", "1.1")}
MAXW = {"xs": "20rem", "sm": "24rem", "md": "28rem", "lg": "32rem", "xl": "36rem", "2xl": "42rem", "3xl": "48rem",
        "4xl": "56rem", "5xl": "64rem", "6xl": "72rem", "7xl": "80rem", "full": "100%"}
BP = {"sm": "640px", "md": "768px", "lg": "1024px"}
SIDES = {"p": ["padding"], "px": ["padding-left", "padding-right"], "py": ["padding-top", "padding-bottom"],
         "pt": ["padding-top"], "pb": ["padding-bottom"], "pl": ["padding-left"], "pr": ["padding-right"],
         "m": ["margin"], "mx": ["margin-left", "margin-right"], "my": ["margin-top", "margin-bottom"], "mt": ["margin-top"],
         "mb": ["margin-bottom"], "ml": ["margin-left"], "mr": ["margin-right"]}
STATIC = {
    "block": "display:block", "inline-block": "display:inline-block", "inline-flex": "display:inline-flex", "flex": "display:flex",
    "grid": "display:grid", "hidden": "display:none", "flex-wrap": "flex-wrap:wrap", "flex-col": "flex-direction:column",
    "flex-1": "flex:1 1 0%", "flex-none": "flex:none", "items-center": "align-items:center", "items-end": "align-items:flex-end",
    "items-start": "align-items:flex-start", "justify-between": "justify-content:space-between", "justify-center": "justify-content:center",
    "justify-end": "justify-content:flex-end", "self-end": "align-self:flex-end", "self-start": "align-self:flex-start",
    "w-full": "width:100%", "h-full": "height:100%", "min-h-screen": "min-height:100vh", "min-w-full": "min-width:100%", "min-w-0": "min-width:0",
    "h-[80vh]": "height:80vh", "mx-auto": "margin-left:auto;margin-right:auto", "ml-auto": "margin-left:auto",
    "-mb-px": "margin-bottom:-1px", "font-bold": "font-weight:700", "font-semibold": "font-weight:600", "font-medium": "font-weight:500",
    "font-mono": "font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace", "uppercase": "text-transform:uppercase",
    "underline": "text-decoration-line:underline;text-underline-offset:2px", "leading-relaxed": "line-height:1.625",
    "leading-tight": "line-height:1.25", "tracking-tight": "letter-spacing:-0.025em", "tracking-wide": "letter-spacing:0.025em",
    "tracking-widest": "letter-spacing:0.1em", "text-left": "text-align:left", "text-center": "text-align:center",
    "text-right": "text-align:right", "whitespace-pre-wrap": "white-space:pre-wrap", "whitespace-nowrap": "white-space:nowrap",
    "truncate": "overflow:hidden;text-overflow:ellipsis;white-space:nowrap", "break-all": "word-break:break-all",
    "overflow-x-auto": "overflow-x:auto", "overflow-hidden": "overflow:hidden", "cursor-pointer": "cursor:pointer",
    "list-disc": "list-style-type:disc", "antialiased": "-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale",
    "line-clamp-2": "overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2",
    "border": "border-width:1px;border-style:solid", "border-b": "border-bottom-width:1px;border-bottom-style:solid",
    "border-t": "border-top-width:1px;border-top-style:solid", "border-b-2": "border-bottom-width:2px;border-bottom-style:solid",
    "border-t-2": "border-top-width:2px;border-top-style:solid", "border-l-4": "border-left-width:4px;border-left-style:solid",
    "rounded": "border-radius:0.25rem", "rounded-md": "border-radius:0.375rem", "rounded-lg": "border-radius:0.5rem",
    "rounded-xl": "border-radius:0.75rem", "rounded-full": "border-radius:9999px",
    "shadow-sm": "box-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05)", "shadow": "box-shadow:0 1px 3px 0 rgb(0 0 0 / .1),0 1px 2px -1px rgb(0 0 0 / .1)",
    "opacity-50": "opacity:.5", "outline-none": "outline:2px solid transparent;outline-offset:2px", "sticky": "position:sticky", "top-0": "top:0", "z-10": "z-index:10", "relative": "position:relative",
    "text-[11px]": "font-size:11px;line-height:1rem", "max-w-full": "max-width:100%", "shrink-0": "flex-shrink:0",
    "divide-y": None, "sr-only": "position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0",
}


def hexa(color: str, alpha: str | None) -> str:
    c = COLORS[color]
    if alpha is None or c == "transparent":
        return c
    a = int(alpha) / 100
    r, g, b = (int(c[i:i + 2], 16) for i in (1, 3, 5))
    return f"rgb({r} {g} {b} / {a})"


def spacing(v: str) -> str | None:
    if v == "px":
        return "1px"
    if v == "auto":
        return "auto"
    try:
        return f"{float(v) * 0.25:g}rem" if float(v) else "0"
    except ValueError:
        return None


def rule(base: str) -> tuple[str, str] | None:
    """Return (selector-suffix, declarations) for a utility without variant prefix."""
    if base in STATIC:
        if base == "divide-y":
            return (" > * + *", "border-top-width:1px;border-top-style:solid")
        return ("", STATIC[base])
    m = re.fullmatch(r"(p|px|py|pt|pb|pl|pr|m|mx|my|mt|mb|ml|mr)-([\d.]+|px|auto)", base)
    if m and spacing(m.group(2)):
        return ("", ";".join(f"{p}:{spacing(m.group(2))}" for p in SIDES[m.group(1)]))
    m = re.fullmatch(r"gap-([\d.]+)", base)
    if m:
        return ("", f"gap:{spacing(m.group(1))}")
    m = re.fullmatch(r"space-y-([\d.]+)", base)
    if m:
        return (" > * + *", f"margin-top:{spacing(m.group(1))}")
    m = re.fullmatch(r"(w|h)-([\d.]+)", base)
    if m:
        return ("", f"{'width' if m.group(1) == 'w' else 'height'}:{spacing(m.group(2))}")
    m = re.fullmatch(r"grid-cols-(\d+)", base)
    if m:
        return ("", f"grid-template-columns:repeat({m.group(1)},minmax(0,1fr))")
    m = re.fullmatch(r"col-span-(\d+)", base)
    if m:
        return ("", f"grid-column:span {m.group(1)} / span {m.group(1)}")
    m = re.fullmatch(r"max-w-(\w+)", base)
    if m and m.group(1) in MAXW:
        return ("", f"max-width:{MAXW[m.group(1)]}")
    m = re.fullmatch(r"text-(xs|sm|base|lg|xl|2xl|3xl|4xl|5xl)", base)
    if m:
        s, lh = TEXT[m.group(1)]
        return ("", f"font-size:{s};line-height:{lh}")
    m = re.fullmatch(r"(bg|text|border|divide)-([a-z]+(?:-\d+)?)(?:/(\d+))?", base)
    if m and m.group(2) in COLORS:
        prop = {"bg": "background-color", "text": "color", "border": "border-color"}.get(m.group(1))
        if m.group(1) == "divide":
            return (" > * + *", f"border-color:{hexa(m.group(2), m.group(3))}")
        return ("", f"{prop}:{hexa(m.group(2), m.group(3))}")
    return None


def esc(cls: str) -> str:
    return re.sub(r"([:/.\[\]])", r"\\\1", cls)


TOKEN = re.compile(r"^(?:(sm|md|lg|hover|focus|disabled):)*-?[a-z0-9][a-z0-9./\[\]-]*$")
UTILITY_SHAPE = re.compile(r"^-?(p|px|py|pt|pb|pl|pr|m|mx|my|mt|mb|ml|mr|bg|text|border|rounded|font|w|h|gap|grid|flex|space|divide|max|min|leading|tracking|col|items|justify|self|overflow|shadow|opacity|line|whitespace|list|cursor|inline|block|hidden|underline|uppercase|truncate|top|z|outline|sr)(-|$)")
STRINGS = re.compile(r'"([^"\n]*)"|`([^`]*)`')


def collect() -> set[str]:
    toks = set()
    for f in list((ROOT / "src").rglob("*.tsx")) + list((ROOT / "local").rglob("*.tsx")) + [ROOT / "local/index.html"]:
        for m in STRINGS.finditer(f.read_text()):
            s = (m.group(1) or m.group(2) or "")
            s = re.sub(r"\$\{[^}]*\}", " ", s)
            toks.update(t for t in s.split() if TOKEN.match(t))
    return toks


def generate() -> tuple[str, list[str]]:
    out, unknown = [], []
    responsive: dict[str, list[str]] = {bp: [] for bp in BP}
    for tok in sorted(collect()):
        parts = tok.split(":")
        base, variants = parts[-1], parts[:-1]
        r = rule(base)
        if r is None:
            if variants or UTILITY_SHAPE.match(base):
                unknown.append(tok)  # class-shaped but unsupported: fail the build
            continue
        suffix, decl = r
        pseudo = "".join({"hover": ":hover", "focus": ":focus", "disabled": ":disabled"}.get(v, "") for v in variants)
        css = f".{esc(tok)}{pseudo}{suffix}{{{decl}}}"
        bp = next((v for v in variants if v in BP), None)
        (responsive[bp] if bp else out).append(css)
    for bp, rules in responsive.items():
        if rules:
            out.append(f"@media (min-width:{BP[bp]}){{{''.join(rules)}}}")
    return "\n".join(out), unknown


BASE = """*,*::before,*::after{box-sizing:border-box;border:0 solid #E2E5EA}
html{-webkit-text-size-adjust:100%;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;line-height:1.5}
body{margin:0}h1,h2,h3,h4,p,ul,ol,figure,pre{margin:0}ul,ol{padding:0;list-style:none}ul.list-disc{padding-left:1.25rem}
a{color:inherit;text-decoration:inherit}button,input,select,textarea{font:inherit;color:inherit;margin:0}
button{background:transparent;cursor:pointer}button:disabled{cursor:not-allowed}img,svg,iframe{display:block;max-width:100%}
table{border-collapse:collapse}th{font-weight:inherit}pre{white-space:pre-wrap;word-break:break-word}
:focus-visible{outline:2px solid #0B7A78;outline-offset:2px}select[multiple]{min-height:7rem}
details>summary{cursor:pointer}
"""

if __name__ == "__main__":
    css, unknown = generate()
    dist = ROOT / "dist-local"
    dist.mkdir(exist_ok=True)
    (dist / "app.css").write_text(BASE + css + "\n")
    if unknown:
        print("Unrecognised utility classes:", " ".join(unknown))
        sys.exit(1)
    print(f"app.css: {css.count('{') - css.count('@media')} utility rules")
