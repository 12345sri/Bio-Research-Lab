// Minimal client-side router providing the subset of next/navigation and next/link used by the pages,
// so the same page components run as a single-page app in local mode.
import React, { createContext, useContext, useSyncExternalStore } from "react";

const EVT = "bioai:navigate";
function subscribe(cb: () => void) {
  window.addEventListener("popstate", cb);
  window.addEventListener(EVT, cb);
  return () => { window.removeEventListener("popstate", cb); window.removeEventListener(EVT, cb); };
}
const snapshot = () => window.location.pathname + window.location.search;

export function navigate(to: string, replace = false) {
  if (replace) window.history.replaceState(null, "", to); else window.history.pushState(null, "", to);
  window.dispatchEvent(new Event(EVT));
  if (!replace) window.scrollTo(0, 0);
}

export function useLocationKey() {
  return useSyncExternalStore(subscribe, snapshot, snapshot);
}

export const ParamsContext = createContext<Record<string, string>>({});

export function useRouter() {
  return { push: (to: string) => navigate(to), replace: (to: string) => navigate(to, true), back: () => window.history.back(), refresh: () => window.dispatchEvent(new Event(EVT)) };
}
export function usePathname() {
  useLocationKey();
  return window.location.pathname;
}
export function useSearchParams() {
  useLocationKey();
  return new URLSearchParams(window.location.search);
}
export function useParams<T = Record<string, string>>(): T {
  return useContext(ParamsContext) as T;
}

export default function Link({ href, children, onClick, ...rest }: any) {
  return (
    <a href={href} {...rest} onClick={(e) => {
      onClick?.(e);
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || rest.target) return;
      if (typeof href === "string" && href.startsWith("/")) { e.preventDefault(); navigate(href); }
    }}>{children}</a>
  );
}
