// Local production build without Next.js: bundles the same page components into a single-page app.
// Finds esbuild and React in the project's node_modules or the global npm installation.
const path = require("path");
const fs = require("fs");
const { execSync } = require("child_process");

const root = path.resolve(__dirname, "..");
const globalRoot = execSync("npm root -g").toString().trim();
const roots = [path.join(root, "node_modules"), globalRoot, path.join(globalRoot, "tsx", "node_modules")];
function find(mod) {
  for (const r of roots) if (fs.existsSync(path.join(r, mod, "package.json"))) return path.join(r, mod);
  throw new Error(`Cannot find ${mod}; install it with npm (npm i -D ${mod}) or globally`);
}
const esbuild = require(find("esbuild"));
const reactDir = find("react"), reactDomDir = find("react-dom");
const out = path.join(root, "dist-local");
fs.mkdirSync(out, { recursive: true });

esbuild.build({
  entryPoints: [path.join(__dirname, "main.tsx")],
  bundle: true,
  minify: true,
  sourcemap: false,
  target: ["es2020"],
  outfile: path.join(out, "app.js"),
  jsx: "automatic",
  loader: { ".tsx": "tsx", ".ts": "ts" },
  alias: {
    "next/link": path.join(__dirname, "shims/router.tsx"),
    "next/navigation": path.join(__dirname, "shims/router.tsx"),
    "@": path.join(root, "src"),
    react: reactDir,
    "react-dom": reactDomDir,
  },
  nodePaths: roots,
  define: { "process.env.NEXT_PUBLIC_API_URL": '"/api/v1"', "process.env.NODE_ENV": '"production"' },
  logLevel: "warning",
}).then(() => {
  fs.copyFileSync(path.join(__dirname, "index.html"), path.join(out, "index.html"));
  const kb = (fs.statSync(path.join(out, "app.js")).size / 1024).toFixed(0);
  console.log(`dist-local/app.js ${kb} KB, index.html, app.css`);
}).catch((e) => { console.error(e.message); process.exit(1); });
