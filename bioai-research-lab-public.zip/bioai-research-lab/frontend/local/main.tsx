import React from "react";
import { createRoot } from "react-dom/client";
import Link, { ParamsContext, useLocationKey } from "next/link";

import Landing from "../src/app/page";
import Login from "../src/app/login/page";
import Register from "../src/app/register/page";
import Verify from "../src/app/verify/page";
import Forgot from "../src/app/forgot-password/page";
import Reset from "../src/app/reset-password/page";
import Dashboard from "../src/app/dashboard/page";
import Projects from "../src/app/projects/page";
import Workspace from "../src/app/projects/[id]/page";
import Results from "../src/app/projects/[id]/experiments/[eid]/page";
import Teams from "../src/app/teams/page";
import Settings from "../src/app/settings/page";

const ROUTES: [string, () => JSX.Element][] = [
  ["/", Landing], ["/login", Login], ["/register", Register], ["/verify", Verify], ["/forgot-password", Forgot],
  ["/reset-password", Reset], ["/dashboard", Dashboard], ["/projects", Projects], ["/projects/:id", Workspace],
  ["/projects/:id/experiments/:eid", Results], ["/teams", Teams], ["/settings", Settings],
];

function match(pattern: string, path: string): Record<string, string> | null {
  const a = pattern.split("/").filter(Boolean), b = path.split("/").filter(Boolean);
  if (a.length !== b.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(":")) params[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

function NotFound() {
  return (
    <main className="mx-auto max-w-md px-6 py-20">
      <h1 className="text-2xl font-semibold">Page not found</h1>
      <p className="mt-3 text-sm text-muted">There is no page at this address.</p>
      <p className="mt-4 text-sm"><Link className="underline" href="/dashboard">Go to the dashboard</Link></p>
    </main>
  );
}

function App() {
  useLocationKey();
  const path = window.location.pathname.replace(/\/+$/, "") || "/";
  for (const [pattern, Page] of ROUTES) {
    const params = match(pattern, path);
    if (params) return <ParamsContext.Provider value={params}><Page key={path} /></ParamsContext.Provider>;
  }
  return <NotFound />;
}

createRoot(document.getElementById("root")!).render(<App />);
