# Instructions for AI coding assistants working in this repository

Read `docs/scientific-rules.md` and `docs/progress.md` before changing anything.

## Non-negotiable rules
1. Research tool, never a diagnostic device. No diagnosis, individual disease prediction or treatment advice in code, UI copy or docs.
2. Never hard-code scientific findings. Engines compute results from data; tests use synthetic data with known ground truth.
3. Never fabricate results, citations, publications, users, affiliations or metrics.
4. Label every analytical output with an evidence type: DATA, STATISTICS, MODEL, EXPLANATION, LITERATURE, INTERPRETATION, HYPOTHESIS.
5. Resampling (SMOTE) and any fitted preprocessing happen only inside training folds. Never before splitting.
6. Longitudinal or repeated-measures data is split by participant, never by row.
7. Never silently drop observations, samples or genes. Every exclusion is counted and has a reason.
8. Correlation edges are labelled "correlation", never "regulation". SHAP is "model feature importance", never "biological importance".
9. Internal validation is never called external validation.
10. Secrets only from environment variables. Private datasets are never publicly reachable.
11. Display only the founder information in README.md. Do not invent qualifications.

## Workflow
- Follow the 20-step execution order in `docs/progress.md`.
- After each step: run `make verify` and `pytest`, fix failures, update `docs/progress.md`.
- Do not start the next step while core functionality of the current one is broken.
- Heavy analyses run in the Celery worker, never inside a request handler.
