#!/usr/bin/env python3
"""Step 1 verification. Needs only the Python standard library (plus PyYAML if present)."""
import json
import pathlib
import py_compile
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
errors: list[str] = []


def check(cond: bool, msg: str) -> None:
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        errors.append(msg)


REQUIRED = [
    "README.md", "CLAUDE.md", ".gitignore", ".env.example", "docker-compose.yml", "Makefile",
    "docs/architecture.md", "docs/scientific-rules.md", "docs/progress.md",
    "backend/Dockerfile", "backend/pyproject.toml", "backend/app/main.py", "backend/app/core/config.py",
    "backend/app/workers/celery_app.py", "backend/tests/conftest.py",
    "frontend/Dockerfile", "frontend/package.json", "frontend/tsconfig.json",
    "frontend/src/app/layout.tsx", "frontend/src/app/page.tsx",
    # Step 2
    "backend/alembic.ini", "backend/alembic/env.py", "backend/alembic/script.py.mako",
    "backend/alembic/pending/0002_audit_append_only.py", "backend/app/db/base.py", "backend/app/db/session.py",
    "backend/app/models/__init__.py", "backend/app/models/enums.py",
    "backend/tests/unit/test_schema_metadata.py", "backend/tests/integration/test_db_schema.py",
    "scripts/step2_verify.sh", "scripts/verify_schema_static.py",
]
for rel in REQUIRED:
    check((ROOT / rel).is_file(), f"file exists: {rel}")

for mod in ["biosignal", "omics", "stats", "ml", "explain", "network", "pathway", "validation", "copilot", "reports"]:
    check((ROOT / f"backend/app/science/{mod}/__init__.py").is_file(), f"science package: {mod}")

for py in (ROOT / "backend").rglob("*.py"):
    try:
        py_compile.compile(str(py), doraise=True)
    except py_compile.PyCompileError as e:
        check(False, f"python syntax: {py.relative_to(ROOT)} ({e.msg})")
print(f"PASS python syntax checked for {len(list((ROOT / 'backend').rglob('*.py')))} files")

try:
    import yaml
    compose = yaml.safe_load((ROOT / "docker-compose.yml").read_text())
    services = set(compose.get("services", {}))
    for s in ["frontend", "backend", "worker", "db", "redis", "minio"]:
        check(s in services, f"compose service: {s}")
except ImportError:
    print("SKIP compose parse (PyYAML not installed)")

for rel in ["frontend/package.json", "frontend/tsconfig.json"]:
    try:
        json.loads((ROOT / rel).read_text())
        check(True, f"valid JSON: {rel}")
    except json.JSONDecodeError as e:
        check(False, f"valid JSON: {rel} ({e})")

check(".env" in (ROOT / ".gitignore").read_text().split(), ".env is git-ignored")
secret_pattern = re.compile(r"(AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----|sk-[A-Za-z0-9]{20,})")
leaks = [str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts
         and secret_pattern.search(p.read_text(errors="ignore"))]
check(not leaks, "no credential-like strings in files" + (f": {leaks}" if leaks else ""))

print(f"\n{'ALL CHECKS PASSED' if not errors else f'{len(errors)} CHECK(S) FAILED'}")
sys.exit(1 if errors else 0)
