#!/usr/bin/env bash
# Step 2 verification against a REAL PostgreSQL. Run from the repository root.
# Output is saved to docs/step2_verification.log as evidence.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] || { echo "ERROR: create .env from .env.example first"; exit 1; }
set -a; . ./.env; set +a
LOG=docs/step2_verification.log
exec > >(tee "$LOG") 2>&1
echo "== Step 2 verification $(date -u +%FT%TZ)"

echo "== 1. Start PostgreSQL"
docker compose up -d db
for i in $(seq 1 30); do
  docker compose exec -T db pg_isready -U "$POSTGRES_USER" -d "$POSTGRES_DB" >/dev/null 2>&1 && break
  sleep 2; [ "$i" = 30 ] && { echo "ERROR: PostgreSQL did not become ready"; exit 1; }
done
docker compose exec -T db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -tc \
  "SELECT 1 FROM pg_database WHERE datname='bioai_test'" | grep -q 1 || \
  docker compose exec -T db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "CREATE DATABASE bioai_test"

docker compose build backend
TEST_URL="postgresql+psycopg://${POSTGRES_USER}:${POSTGRES_PASSWORD}@db:5432/bioai_test"
RUN=(docker compose run --rm --no-deps --user "$(id -u):$(id -g)" -v "$PWD/backend:/srv"
     -e HOME=/tmp -e DATABASE_URL="$TEST_URL" -e TEST_DATABASE_URL="$TEST_URL" -e REQUIRE_DB=1 backend)

echo "== 2. Migrations"
if [ ! -f backend/alembic/versions/0001_initial_schema.py ]; then
  echo "-- generating initial migration from models (review and commit it)"
  "${RUN[@]}" alembic revision --autogenerate -m "initial schema" --rev-id 0001_initial_schema
  cp backend/alembic/pending/0002_audit_append_only.py backend/alembic/versions/
fi
"${RUN[@]}" alembic upgrade head
"${RUN[@]}" alembic current
"${RUN[@]}" alembic check   # fails if models and migrations have drifted

echo "== 3-5. pytest (unit + api + integration; integration may not skip)"
"${RUN[@]}" pytest -q -rs

echo "== 4. Structure and static schema checks"
python3 scripts/verify_structure.py
python3 scripts/verify_schema_static.py

echo "== STEP 2 VERIFICATION PASSED"
