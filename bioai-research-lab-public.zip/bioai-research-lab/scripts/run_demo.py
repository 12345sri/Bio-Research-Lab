#!/usr/bin/env python3
"""Run the complete DEMONSTRATION workflow and export reports.

    python3 scripts/run_demo.py [output_dir]

Everything here uses synthetic DEMONSTRATION DATA generated with fixed seeds.
It is not biomedical evidence. Running twice produces identical results (same config and input hashes).
"""
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "backend"))

from app.science import demo_data as dd  # noqa: E402
from app.science.copilot.copilot import review  # noqa: E402
from app.science.pipelines import run_biosignal, run_omics  # noqa: E402
from app.science.reports import builder  # noqa: E402

KEY = "demo-pseudonymisation-key-not-for-real-data"
BIO_CFG = {"demo": True, "random_seed": 7, "window_s": 60, "compare": ["NORMAL_DAY", "EXAM_DAY"],
           "ml": {"algorithms": ["LOGISTIC_REGRESSION", "RANDOM_FOREST"], "positive_class": "EXAM_DAY",
                  "cv_folds": 3, "test_size": 0.25}}
OMICS_CFG = {"demo": True, "group_column": "stage", "positive_class": "LATE", "negative_class": "EARLY", "random_seed": 42,
             "ml": {"algorithms": ["LOGISTIC_REGRESSION", "SVM", "RANDOM_FOREST"], "resampling": "SMOTE",
                    "select_k_best": 30, "cv_folds": 5},
             "network": {"threshold": 0.4}, "dataset_id": "demo-train-v1", "external_dataset_id": "demo-external-v1"}


def main(out_dir: str) -> dict:
    out = pathlib.Path(out_dir)
    summary = {}

    bio_df = dd.biosignal_demo(n_participants=12)
    bio = run_biosignal(bio_df, BIO_CFG, KEY)
    bio_rep = builder.build(bio, {"name": "DEMO: Resting vs exam-day HRV (synthetic)",
                                  "research_question": "Do HRV metrics differ between a normal day and an exam day "
                                                       "within the same (synthetic) participants?",
                                  "principal_researcher": "Demonstration", "demo": True}, review(bio))
    summary["biosignal"] = builder.export_all(bio_rep, bio, out, "demo_biosignal_report")

    expr, meta = dd.omics_demo()
    ext = dd.omics_demo(n_samples=100, seed=99, prefix="V")
    layer2 = dd.second_layer_demo(meta)
    om = run_omics(expr, meta, OMICS_CFG, gmt_text=dd.gene_sets_demo(), external=ext,
                   extra_layers={"METHYLATION_DEMO": layer2})
    om_rep = builder.build(om, {"name": "DEMO: Early vs late stage classification (synthetic expression)",
                                "research_question": "Can synthetic expression profiles separate early from late "
                                                     "stage, and does performance hold on an independent dataset?",
                                "principal_researcher": "Demonstration", "demo": True}, review(om))
    summary["omics"] = builder.export_all(om_rep, om, out, "demo_omics_report")
    summary["config_hashes"] = {"biosignal": bio["provenance"]["config_hash"], "omics": om["provenance"]["config_hash"]}
    (out / "demo_summary.json").write_text(json.dumps(summary, indent=2))
    return summary


if __name__ == "__main__":
    print(json.dumps(main(sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "demo_output")), indent=2))
