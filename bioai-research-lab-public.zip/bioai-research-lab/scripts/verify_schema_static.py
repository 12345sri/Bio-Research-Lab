#!/usr/bin/env python3
"""Static schema checks from source (standard library only; no database, no SQLAlchemy).

Complements, never replaces, the PostgreSQL integration tests.
"""
import ast
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
MODELS = ROOT / "backend/app/models"
REQUIRED = {
    "users", "organizations", "roles", "projects", "project_members", "datasets", "dataset_versions",
    "experiments", "experiment_results", "models", "model_runs", "features", "statistics_results",
    "biosignal_sessions", "hrv_results", "omics_datasets", "gene_results", "gene_networks", "pathways",
    "validation_runs", "reports", "publications", "teams", "tasks", "comments", "audit_logs", "consents",
}
SUPPORTING = {"team_members", "user_tokens"}
FORBIDDEN_COLUMNS = {"phone", "address", "government_id", "national_id", "passport", "date_of_birth", "full_name"}
GUARDS = {  # CLAUDE.md rules the database must enforce: table -> check constraint name
    "model_runs": "smote_training_only", "hrv_results": "freq_domain_only_when_valid",
    "validation_runs": "external_is_independent", "features": "importance_is_explanation",
    "gene_networks": "correlation_has_threshold", "biosignal_sessions": "observations_accounted",
    "pathways": "gene_count_matches", "statistics_results": "padj_has_method",
    "publications": "published_has_venue",
}
errors: list[str] = []


def check(ok: bool, msg: str):
    print(("PASS " if ok else "FAIL ") + msg)
    if not ok:
        errors.append(msg)


tables: dict[str, dict] = {}
for path in sorted(MODELS.glob("*.py")):
    tree = ast.parse(path.read_text(), filename=str(path))
    for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
        info = {"file": path.name, "fks": [], "checks": [], "columns": []}
        for stmt in cls.body:
            if isinstance(stmt, ast.Assign) and any(getattr(t, "id", None) == "__tablename__" for t in stmt.targets):
                info["name"] = stmt.value.value
            if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.target, ast.Name):
                info["columns"].append(stmt.target.id)
        for node in ast.walk(cls):
            if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "ForeignKey":
                target = node.args[0].value
                ondelete = next((k.value.value for k in node.keywords if k.arg == "ondelete"), None)
                info["fks"].append((target, ondelete))
            if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "CheckConstraint":
                name = next((k.value.value for k in node.keywords if k.arg == "name"), None)
                info["checks"].append(name)
        if "name" in info:
            tables[info["name"]] = info

defined = set(tables)
check(REQUIRED <= defined, f"all {len(REQUIRED)} required tables defined" +
      ("" if REQUIRED <= defined else f"; missing {sorted(REQUIRED - defined)}"))
check(defined - REQUIRED <= SUPPORTING, "no undocumented tables" +
      ("" if defined - REQUIRED <= SUPPORTING else f": {sorted(defined - REQUIRED - SUPPORTING)}"))

fk_total = 0
for name, info in sorted(tables.items()):
    for target, ondelete in info["fks"]:
        fk_total += 1
        ref = target.split(".")[0]
        if ref not in defined:
            check(False, f"{name}: FK target {target} exists")
        if ondelete not in {"CASCADE", "SET NULL", "RESTRICT"}:
            check(False, f"{name}: FK to {target} declares ondelete")
    unnamed = [c for c in info["checks"] if not c]
    if unnamed:
        check(False, f"{name}: every CheckConstraint is named")
    bad = FORBIDDEN_COLUMNS & set(info["columns"])
    if bad:
        check(False, f"{name}: no unnecessary personal-data columns ({sorted(bad)})")
print(f"PASS {fk_total} foreign keys all reference defined tables and declare ondelete")

for table, guard in GUARDS.items():
    check(guard in tables.get(table, {}).get("checks", []), f"guard constraint {table}.{guard}")

trigger = ROOT / "backend/alembic/pending/0002_audit_append_only.py"
check(trigger.is_file() and "BEFORE UPDATE OR DELETE ON audit_logs" in trigger.read_text(),
      "audit_logs append-only trigger migration present")

print(f"\n{'ALL STATIC SCHEMA CHECKS PASSED' if not errors else f'{len(errors)} CHECK(S) FAILED'}")
print("NOTE: static checks do not replace running migrations and integration tests on PostgreSQL.")
sys.exit(1 if errors else 0)
