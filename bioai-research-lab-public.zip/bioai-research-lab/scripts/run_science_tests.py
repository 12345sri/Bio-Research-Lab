#!/usr/bin/env python3
"""Run backend/tests/science, tests/core and tests/local (local-mode server) without pytest (for minimal environments). pytest runs the same files."""
import importlib
import pathlib
import sys
import time
import traceback

BACKEND = pathlib.Path(__file__).resolve().parent.parent / "backend"
sys.path.insert(0, str(BACKEND))
passed, failed = 0, []
for path in sorted((BACKEND / "tests/science").glob("test_*.py")) + sorted((BACKEND / "tests/core").glob("test_*.py")) \
        + sorted((BACKEND / "tests/local").glob("test_*.py")):
    mod = importlib.import_module(f"tests.{path.parent.name}.{path.stem}")
    for name in sorted(n for n in dir(mod) if n.startswith("test_")):
        t = time.time()
        try:
            getattr(mod, name)()
            passed += 1
            print(f"PASS {path.stem}::{name} ({time.time() - t:.1f}s)")
        except Exception:
            failed.append(f"{path.stem}::{name}")
            print(f"FAIL {path.stem}::{name}\n{traceback.format_exc()}")
print(f"\n{passed} passed, {len(failed)} failed")
sys.exit(1 if failed else 0)
