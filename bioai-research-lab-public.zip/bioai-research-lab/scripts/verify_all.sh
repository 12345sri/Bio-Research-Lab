#!/usr/bin/env bash
# Full verification against the REAL stack. Run from the repository root on a machine with Docker.
# Evidence is written to docs/verification.log. Exits non-zero on the first failure.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .env ] || cp .env.example .env
set -a; . ./.env; set +a
exec > >(tee docs/verification.log) 2>&1
echo "== BioAI verification $(date -u +%FT%TZ)"

echo "== 1. Offline science/security suite and frontend/backend API contract"
python3 scripts/run_science_tests.py
python3 scripts/check_api_contract.py

echo "== 2. Build and start the full stack (migrations + seed + demo run in the backend entrypoint)"
docker compose up -d --build
for i in $(seq 1 120); do
  curl -fsS http://localhost:8000/api/v1/health >/dev/null 2>&1 && curl -fsS http://localhost:3000 >/dev/null 2>&1 && break
  sleep 5; [ "$i" = 120 ] && { docker compose logs --tail=200; echo "ERROR: stack did not become healthy"; exit 1; }
done
if [ "${LOAD_DEMO:-false}" = "true" ]; then
  echo "-- waiting for the demonstration experiments to finish"
  for i in $(seq 1 120); do
    st=$(docker compose exec -T backend python -m app.cli status | tail -1)
    echo "   $st"
    echo "$st" | grep -q "SUCCEEDED=2" && ! echo "$st" | grep -qE "QUEUED|RUNNING" && break
    echo "$st" | grep -q "FAILED" && { docker compose logs backend --tail=100; echo "ERROR: demo experiment failed"; exit 1; }
    sleep 10; [ "$i" = 120 ] && { echo "ERROR: demo did not finish"; exit 1; }
  done
fi
docker compose exec -T backend alembic current
docker compose exec -T backend alembic check

echo "== 3. Backend test suite on real PostgreSQL (unit, integration, API, science, security)"
docker compose exec -T db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -tc "SELECT 1 FROM pg_database WHERE datname='bioai_test'" | grep -q 1 \
  || docker compose exec -T db psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "CREATE DATABASE bioai_test"
TEST_URL="postgresql+psycopg://${POSTGRES_USER}:${POSTGRES_PASSWORD}@db:5432/bioai_test"
docker compose exec -T -e TEST_DATABASE_URL="$TEST_URL" -e REQUIRE_DB=1 backend pytest -q -rs

echo "== 4. XGBoost and SHAP present in the real environment"
docker compose exec -T backend python -c "import xgboost, shap; print('xgboost', xgboost.__version__, 'shap', shap.__version__)"

echo "== 5. End-to-end browser test against the running application"
mkdir -p e2e/fixtures
docker compose exec -T backend python -c "
import io; from app.science.demo_data import biosignal_demo
b=io.StringIO(); biosignal_demo(6).to_csv(b, index=False); print(b.getvalue(), end='')" > e2e/fixtures/demo_rr.csv
docker run --rm --network host -v "$PWD/e2e:/e2e" -w /e2e \
  -e APP_URL=http://localhost:3000 -e DEMO_USER_EMAIL="$DEMO_USER_EMAIL" -e DEMO_USER_PASSWORD="$DEMO_USER_PASSWORD" \
  mcr.microsoft.com/playwright:v1.48.2-jammy sh -c "npm install --no-audit --no-fund && npx playwright test"

echo "== ALL VERIFICATION PASSED"
