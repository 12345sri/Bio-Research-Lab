#!/usr/bin/env python3
"""Static contract check: every frontend API call must match a backend route and HTTP method.

Parses FastAPI decorators in backend/app/api/v1 and api()/post()/patch()/raw()/download()/blobUrl()
calls in frontend/src. Template expressions ${...} are treated as path parameters.
"""
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
routes = set()
for f in (ROOT / "backend/app/api/v1").glob("*.py"):
    src = f.read_text()
    prefix = re.search(r'APIRouter\((?:[^)]*?)prefix="([^"]*)"', src)
    prefix = prefix.group(1) if prefix else ""
    for m in re.finditer(r'@router\.(get|post|patch|put|delete)\(\s*"([^"]+)"', src):
        path = prefix + m.group(2)
        routes.add((m.group(1).upper(), re.sub(r"\{[^}]+\}", "{}", path)))
routes.add(("GET", "/health"))

calls = []
CALL = re.compile(r'\b(api|post|patch|raw|download|blobUrl)(?:<[^>]*>)?\(\s*`([^`]+)`|\b(api|post|patch|raw|download|blobUrl)(?:<[^>]*>)?\(\s*"([^"]+)"')
for f in (ROOT / "frontend/src").rglob("*.ts*"):
    text = f.read_text()
    for i, line in enumerate(text.splitlines(), 1):
        for m in CALL.finditer(line):
            fn, path = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
            if not path.startswith(("/", "${")):
                continue
            method = {"post": "POST", "patch": "PATCH"}.get(fn, "GET")
            if fn == "api" and "method: \"PATCH\"" in line:
                method = "PATCH"
            calls.append((f.relative_to(ROOT), i, method, path))

# Resolve local `base` variables of the form `/projects/${id}/experiments/${eid}`.
base = "/projects/{}/experiments/{}"
errors = 0
checked = 0
for f, line, method, path in calls:
    norm = path.replace("${base}", base)
    norm = norm.split("?")[0]
    norm = re.sub(r"\$\{[^}]+\}", "{}", norm)
    norm = re.sub(r"\{\}\.\{\}$", "{}.{}", norm)
    if norm.startswith("{}"):  # e.g. `${API}/...` inside the client itself
        continue
    checked += 1
    candidates = {(m, p) for m, p in routes if m == method}
    ok = any(re.fullmatch(re.escape(p).replace(r"\{\}", r"[^/]+"), norm.replace("{}", "X")) for _, p in candidates)
    if not ok:
        errors += 1
        print(f"MISMATCH {f}:{line} {method} {path} (normalised {norm})")
print(f"{checked} frontend API calls checked against {len(routes)} backend routes: "
      f"{'ALL MATCH' if not errors else f'{errors} MISMATCH(ES)'}")
sys.exit(1 if errors else 0)
