# Architecture

```
Browser (Next.js)  ──HTTPS──>  FastAPI  ──>  PostgreSQL (metadata, results, audit)
                                  │
                                  ├──>  MinIO / S3 (dataset files, figures, reports; signed URLs)
                                  │
                                  └──>  Redis  ──>  Celery worker (QC, HRV, ML, SHAP, networks, reports)
```

## Services (docker-compose)
| Service | Role |
|---|---|
| frontend | Next.js site and research dashboard |
| backend | REST API, auth, permissions, OpenAPI at `/api/v1/docs` |
| worker | Long-running analyses; API returns a job ID and the client polls |
| db | PostgreSQL 16 |
| redis | Task broker and result backend |
| minio | S3-compatible object storage; files never stored in PostgreSQL |

## Design decisions
- **Science engines are pure functions** in `app/science/*`: input arrays and config in, results plus provenance out. No database or HTTP inside them, so they are testable and reusable by the worker, API and future mobile backend.
- **Every analysis is an experiment row** storing dataset version, config, seed, software versions and result pointers, so re-run, clone and compare are database operations.
- **Datasets are immutable per version.** Edits create a new version; experiments pin a version.
- **API-first** so the future BioAI Participant mobile app uses the same endpoints.
- **Authorization at the project level**, enforced in the service layer, with organization-level roles for Founder and Co-Founder.

## Planned API groups
`/auth /users /projects /datasets /experiments /biosignal /hrv /statistics /models /shap /omics /networks /pathways /validation /reports /publications /teams /copilot`
