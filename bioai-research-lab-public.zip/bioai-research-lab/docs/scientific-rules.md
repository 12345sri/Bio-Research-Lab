# Scientific rules

BioAI Research Lab builds research infrastructure. These rules apply to code, UI copy, reports and the Research Copilot.

## What the platform is not
- A medical diagnostic device
- A disease prediction service for individual patients
- A treatment recommendation system
- A replacement for doctors or professional researchers

## Evidence labels
Every output shown to a user carries exactly one label per claim:

| Label | Meaning |
|---|---|
| DATA | Observed values from the uploaded dataset |
| STATISTICS | Results of a named statistical test, with n, statistic, p, effect size, CI and assumptions |
| MODEL | Machine-learning output |
| EXPLANATION | Model explanation (for example SHAP); describes the model, not biology |
| LITERATURE | Claims backed by a verifiable reference supplied by a user or curated database |
| INTERPRETATION | Reasonable scientific reading of the above |
| HYPOTHESIS | Candidate idea that requires independent validation |

## Language rules
- Correlation is not causation.
- A model feature is not automatically a biomarker.
- A generated hypothesis is not a finding.
- BioSignal baseline module uses "deviation from participant baseline", never "abnormality" or "diagnosis".
- Workplace studies expose only governed aggregate results, never individual physiology to employers.

## Validation rules
- SMOTE and fitted transforms inside training folds only.
- Participant-level splitting for repeated measures.
- Models are never selected on accuracy alone; report ROC-AUC, balanced accuracy, per-class recall and calibration.
- Pathway enrichment uses a stated background and multiple-testing correction.
- External validation means a dataset independent of training and tuning.

## Benchmark against founders' prior work
The first validation reproduces the founders' existing ECG/HRV dissertation and breast cancer
paper workflows. Expected values are recorded in a separate benchmark file and compared against
what the software computes independently, as EXPECTED / ACTUAL / DIFFERENCE / POSSIBLE EXPLANATION.
Expected values are never used inside the analysis code.
