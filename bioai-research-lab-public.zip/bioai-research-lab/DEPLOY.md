# Deploying BioAI Research Lab publicly

The public website is the self-contained version in this repository (`run_local.py`: SQLite, local file
storage, background worker, prebuilt frontend) packaged by the root `Dockerfile`.

## Simplest: Render (free tier, deploys from GitHub)

1. Push this repository to GitHub (the root must contain `Dockerfile` and `render.yaml`).
2. Sign in at https://render.com with GitHub.
3. **New > Blueprint**, pick the repository, click **Apply**. Render reads `render.yaml`, builds the
   Dockerfile, generates `SECRET_KEY` and `PSEUDONYM_SECRET`, and gives you a URL like
   `https://bioai-research-lab.onrender.com`.
4. Open the URL and click **Explore the live demo** (first start builds the demo analyses: about a minute).

Free-tier notes: the service sleeps after about 15 minutes without visitors (the next visit takes roughly a minute
to wake up), and its disk is temporary: accounts and uploads are cleared when the service restarts or redeploys.
The demo project is recreated automatically. For permanent storage, use a paid plan with a persistent disk mounted
at `/data`.

## Any other Docker host (Railway, Fly.io, a VPS)

```bash
docker build -t bioai-research-lab .
docker run -p 8765:8765 -e SECRET_KEY=<long random string> -e PSEUDONYM_SECRET=<long random string> \
  -v bioai-data:/data bioai-research-lab
```
The container listens on `$PORT` (default 8765); health check: `/api/v1/health`.

## Public-mode behaviour (set by the Dockerfile)

- `ENVIRONMENT=production`: password-reset links are never shown on screen (no email is sent), so users are told
  to contact the administrator. Email-verification links are shown on screen (`SHOW_VERIFICATION_LINKS=true`).
- The demo account is read-only for everyone, so the demo stays the same for every visitor.
- `TRUST_PROXY=true`: sign-in rate limits apply per visitor behind the hosting proxy.
- `MAX_UPLOAD_MB=25`.
- Optional features: XGBoost and tree/kernel SHAP are not installed in the image; the site says they are not
  enabled. AI-written copilot answers need `ANTHROPIC_API_KEY`; without it the copilot shows the recorded evidence
  and automated review.
