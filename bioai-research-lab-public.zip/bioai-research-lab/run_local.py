#!/usr/bin/env python3
"""Start BioAI Research Lab locally with one command:

    python3 run_local.py

No Docker, PostgreSQL, Redis, MinIO or internet access is needed at run time (only to install the
Python packages the first time, if they are missing). Data is kept in ./local-data (SQLite database and
uploaded files). A demonstration project with synthetic data is created on first start.

Options: --port 8765  --host 127.0.0.1  --data local-data  --no-browser  --no-demo  --rebuild-frontend
"""
import argparse
import importlib.util
import os
import pathlib
import shutil
import subprocess
import sys
import threading
import webbrowser

ROOT = pathlib.Path(__file__).resolve().parent
REQUIRED = {"numpy": "numpy", "scipy": "scipy", "pandas": "pandas", "sklearn": "scikit-learn",
            "networkx": "networkx", "matplotlib": "matplotlib", "reportlab": "reportlab"}
OPTIONAL = {"xgboost": "xgboost", "shap": "shap"}


def ensure_python_packages() -> None:
    if sys.version_info < (3, 10):
        sys.exit("Python 3.10 or newer is required.")
    missing = [pip for mod, pip in REQUIRED.items() if importlib.util.find_spec(mod) is None]
    if missing:
        print(f"Installing required packages: {' '.join(missing)}")
        cmd = [sys.executable, "-m", "pip", "install", *missing]
        if subprocess.call(cmd) != 0 and subprocess.call(cmd + ["--user"]) != 0:
            sys.exit(f"Could not install {' '.join(missing)}. Install them with:\n"
                     f"  {sys.executable} -m pip install {' '.join(missing)}")
    absent = [pip for mod, pip in OPTIONAL.items() if importlib.util.find_spec(mod) is None]
    if absent:
        print(f"Note: optional packages not installed ({', '.join(absent)}). The app runs and reports those "
              f"models/explanations as 'not run'. To add them: {sys.executable} -m pip install {' '.join(absent)}")


def ensure_frontend(rebuild: bool) -> None:
    dist = ROOT / "frontend" / "dist-local"
    have = all((dist / f).is_file() for f in ("app.js", "app.css", "index.html"))
    if have and not rebuild:
        return
    if not shutil.which("node"):
        if have:
            print("Node.js not found; using the prebuilt frontend.")
            return
        sys.exit("The prebuilt frontend is missing and Node.js is not installed to rebuild it.")
    print("Building the frontend...")
    subprocess.check_call([sys.executable, str(ROOT / "frontend" / "local" / "gen_css.py")])
    subprocess.check_call(["node", str(ROOT / "frontend" / "local" / "build.cjs")])


def main() -> None:
    ap = argparse.ArgumentParser(description="BioAI Research Lab (local mode)")
    # HOST / PORT / BIOAI_DATA_DIR environment variables are used by hosting platforms (see Dockerfile).
    ap.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8765")))
    ap.add_argument("--data", default=os.environ.get("BIOAI_DATA_DIR", str(ROOT / "local-data")))
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--no-demo", action="store_true")
    ap.add_argument("--rebuild-frontend", action="store_true")
    a = ap.parse_args()

    ensure_python_packages()
    ensure_frontend(a.rebuild_frontend)
    os.environ["LOAD_DEMO"] = "false" if a.no_demo else os.environ.get("LOAD_DEMO", "true")
    os.environ.setdefault("FRONTEND_DIST", str(ROOT / "frontend" / "dist-local"))
    sys.path.insert(0, str(ROOT / "backend"))

    from local.server import start

    data_dir = str(pathlib.Path(a.data).resolve())
    httpd = start(a.host, a.port, data_dir)
    url = f"http://{'127.0.0.1' if a.host == '0.0.0.0' else a.host}:{a.port}"
    print(f"\n  BioAI Research Lab is running at {url}\n  Data folder: {data_dir}\n  Stop with Ctrl+C.\n", flush=True)
    if not a.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
